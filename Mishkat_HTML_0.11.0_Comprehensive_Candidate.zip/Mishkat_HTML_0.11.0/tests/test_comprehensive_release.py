import base64, json, tempfile, unittest, threading
from pathlib import Path
from http.server import ThreadingHTTPServer
from urllib.request import Request, urlopen
from urllib.error import HTTPError
from src.db import initialize_database
from src.web_app import MishkatHandler

class ComprehensiveReleaseTests(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory(); self.db=Path(self.tmp.name)/'school.sqlite3'; initialize_database(self.db)
        self.httpd=ThreadingHTTPServer(('127.0.0.1',0),MishkatHandler); self.httpd.daemon_threads=True; self.httpd.db_path=self.db
        self.thread=threading.Thread(target=self.httpd.serve_forever,daemon=True); self.thread.start(); self.base=f'http://127.0.0.1:{self.httpd.server_address[1]}'
    def tearDown(self):
        self.httpd.shutdown(); self.httpd.server_close(); self.thread.join(timeout=2); self.tmp.cleanup()
    def request(self,path,method='GET',body=None,headers=None):
        data=None if body is None else json.dumps(body,ensure_ascii=False).encode('utf-8')
        req=Request(self.base+path,data=data,method=method,headers=headers or {})
        try:
            with urlopen(req,timeout=4) as response:
                raw=response.read()
                return response.status, json.loads(raw.decode('utf-8')) if 'json' in response.headers.get('Content-Type','') else raw.decode('utf-8-sig')
        except HTTPError as e:
            raw=e.read().decode('utf-8')
            return e.code,json.loads(raw)
    def student(self,**overrides):
        data={'first_name':'أحمد','last_name':'بن صالح','student_code':'ST-001','gender':'male','student_category':'child','status':'active'}; data.update(overrides); return data

    def test_association_member_and_finance_crud(self):
        status, member = self.request('/api/association/members','POST',{'first_name':'محمد','last_name':'صالح','role_title':'أمين المال'})
        self.assertEqual(status,201,member)
        status, data = self.request('/api/association/members')
        self.assertEqual(status,200); self.assertEqual(len(data['rows']),1)
        status, txn = self.request('/api/association/transactions','POST',{'transaction_date':'2026-10-13','direction':'income','category':'تبرعات','description':'تبرع تجريبي','amount':1000})
        self.assertEqual(status,201,txn)
        status, report = self.request('/api/reports')
        self.assertEqual(status,200); self.assertEqual(report['income'],1000); self.assertEqual(report['balance'],1000)

    def test_import_preview_and_commit_does_not_overwrite_or_duplicate(self):
        raw='student_code,first_name,last_name,gender\nIMP-001,ليلى,صالح,female\n'.encode()
        b64=base64.b64encode(raw).decode()
        status, preview=self.request('/api/import/preview','POST',{'filename':'list.csv','entity':'students','file_base64':b64})
        self.assertEqual(status,200,preview); self.assertEqual(preview['row_count'],1)
        mapping={k:int(v) for k,v in preview['mapping'].items()}
        status, result=self.request('/api/import/commit','POST',{'filename':'list.csv','entity':'students','file_base64':b64,'mapping':mapping,'confirm':True})
        self.assertEqual(status,200,result); self.assertEqual(result['imported'],1)
        status, result=self.request('/api/import/commit','POST',{'filename':'list.csv','entity':'students','file_base64':b64,'mapping':mapping,'confirm':True})
        self.assertEqual(status,200,result); self.assertEqual(result['imported'],0); self.assertEqual(result['skipped'],1)
        status, students=self.request('/api/students?q=IMP-001')
        self.assertEqual(len(students['students']),1)

    def test_unsupported_legacy_import_format_is_explained(self):
        b64=base64.b64encode(b'fake').decode()
        status, body=self.request('/api/import/preview','POST',{'filename':'old.xls','entity':'students','file_base64':b64})
        self.assertEqual(status,400); self.assertIn('الصيغة القديمة',body['error'])

    def test_bulk_archive_and_delete_are_explicit(self):
        status, student=self.request('/api/students','POST',self.student())
        self.assertEqual(status,201)
        status, body=self.request('/api/delete','POST',{'entity':'students','ids':[student['id']],'mode':'archive','confirm':True,'reason':'test'})
        self.assertEqual(status,200); self.assertEqual(body['processed'],1)
        status, rows=self.request('/api/students?status=archived')
        self.assertEqual(len(rows['students']),1)

    def test_storage_and_reports_endpoints(self):
        self.assertEqual(self.request('/api/storage')[0],200)
        self.assertEqual(self.request('/api/reports')[0],200)
        self.assertEqual(self.request('/api/association/assets')[0],200)

    def test_backup_bundle_contains_database_and_is_restorable(self):
        status, student=self.request('/api/students','POST',self.student())
        status, backup=self.request('/api/backup','POST',{'destination_type':'local'})
        self.assertEqual(status,201,backup)
        bundle=Path(backup['path']); self.assertTrue(bundle.exists()); self.assertTrue(bundle.suffix=='.zip')
        raw=base64.b64encode(bundle.read_bytes()).decode()
        status, restored=self.request('/api/restore','POST',{'file_base64':raw})
        self.assertEqual(status,200,restored)
        status, students=self.request('/api/students?q=ST-001')
        self.assertEqual(status,200); self.assertEqual(len(students['students']),1)

    def test_document_upload_is_saved_locally(self):
        payload={'filename':'minutes.txt','file_base64':base64.b64encode('محضر تجريبي'.encode()).decode(),'title':'محضر تجريبي','document_type':'minutes'}
        status, doc=self.request('/api/documents/upload','POST',payload)
        self.assertEqual(status,201,doc)
        status, rows=self.request('/api/association/documents')
        self.assertEqual(status,200); self.assertEqual(rows['rows'][0]['title'],'محضر تجريبي')

    def test_seating_generator_requires_enrolled_students(self):
        status, body=self.request('/api/seating/generate','POST',{'group_id':1,'columns':4})
        self.assertIn(status,(400,))

    def test_generated_financial_report_is_saved_as_draft(self):
        self.request('/api/association/transactions','POST',{'transaction_date':'2026-10-13','direction':'income','category':'تبرعات','description':'دعم','amount':500})
        status, report=self.request('/api/reports/generate','POST',{'report_type':'financial'})
        self.assertEqual(status,201,report); self.assertIn('500.00',report['body'])
        status, rows=self.request('/api/association/reports')
        self.assertEqual(status,200); self.assertEqual(rows['rows'][0]['report_type'],'financial')

    def test_top_students_and_award_generation(self):
        status, student=self.request('/api/students','POST',self.student())
        payload={'student_id':student['id'],'session_date':'2026-10-13','work_type':'new_memorization','start_surah':1,'start_ayah':1,'end_surah':1,'end_ayah':7,'score':9,'mistake_count':0,'decision':'accepted'}
        self.assertEqual(self.request('/api/memorization','POST',payload)[0],201)
        status, top=self.request('/api/reports/top-students')
        self.assertEqual(status,200); self.assertEqual(top['top_students'][0]['id'],student['id'])
        status, award=self.request('/api/awards/generate','POST',{'student_ids':[student['id']],'award_title':'متفوق','award_date':'2026-10-13'})
        self.assertEqual(status,201); self.assertEqual(award['created'],1)
        status, award2=self.request('/api/awards/generate','POST',{'student_ids':[student['id']],'award_title':'متفوق','award_date':'2026-10-13'})
        self.assertEqual(award2['created'],0); self.assertEqual(award2['skipped'],1)

    def test_seating_generator_persists_enrolled_roster(self):
        _, student=self.request('/api/students','POST',self.student())
        _, teacher=self.request('/api/teachers','POST',{'teacher_code':'T-1','first_name':'معلم','last_name':'تجربة'})
        _, level=self.request('/api/levels','POST',{'name':'مبتدئ'})
        _, group=self.request('/api/groups','POST',{'group_code':'G-1','name':'حلقة اختبار','teacher_id':teacher['id'],'level_id':level['id']})
        self.assertEqual(self.request('/api/enrollments','POST',{'student_id':student['id'],'group_id':group['id'],'start_date':'2026-10-01'})[0],201)
        status, plan=self.request('/api/seating/generate','POST',{'group_id':group['id'],'columns':3,'plan_name':'خطة اختبار'})
        self.assertEqual(status,201,plan); self.assertEqual(plan['students'],1)
        status, stored=self.request('/api/association/seating')
        self.assertEqual(status,200); self.assertEqual(stored['rows'][0]['plan_name'],'خطة اختبار')

    def test_bulk_archive_members_and_protect_financial_ledger(self):
        status, member=self.request('/api/association/members','POST',{'first_name':'علي','last_name':'حسن'})
        self.assertEqual(status,201)
        status, body=self.request('/api/delete','POST',{'entity':'members','ids':[member['id']],'mode':'archive','confirm':True})
        self.assertEqual(status,200); self.assertEqual(body['processed'],1)
        self.request('/api/association/transactions','POST',{'transaction_date':'2026-10-13','direction':'income','category':'دعم','description':'حركة محمية','amount':50})
        status, body=self.request('/api/delete','POST',{'entity':'transactions','ids':[1],'mode':'delete','confirm':True})
        self.assertEqual(status,409); self.assertIn('لا تُحذف',body['error'])

    def test_export_csv_is_utf8_bom_and_downloadable(self):
        self.request('/api/students','POST',self.student())
        import urllib.request
        with urllib.request.urlopen(self.base+'/api/export?entity=students') as response:
            raw=response.read()
            self.assertIn('attachment',response.headers.get('Content-Disposition',''))
            self.assertTrue(raw.startswith(b'\xef\xbb\xbf'))
            self.assertIn('ST-001',raw.decode('utf-8-sig'))

if __name__=='__main__': unittest.main()
