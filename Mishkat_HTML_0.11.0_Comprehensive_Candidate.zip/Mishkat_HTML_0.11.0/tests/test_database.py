import sqlite3
import tempfile
import unittest
from pathlib import Path

from src.db import initialize_database, validate_database, connect


class DatabaseSchemaTests(unittest.TestCase):
    def setUp(self):
        self.temp_dir = tempfile.TemporaryDirectory()
        self.db_path = Path(self.temp_dir.name) / "school.sqlite3"
        initialize_database(self.db_path)

    def tearDown(self):
        self.temp_dir.cleanup()

    def test_database_integrity_and_institution_seed(self):
        self.assertEqual(validate_database(self.db_path), [])
        with connect(self.db_path) as con:
            row = con.execute("SELECT * FROM institution WHERE id=1").fetchone()
            self.assertEqual(row["branch_name"], "شعبة بئر مقدم")
            self.assertEqual(row["supervisor_name"], "")

    def test_student_code_must_be_unique(self):
        with connect(self.db_path) as con:
            con.execute("INSERT INTO students(student_code, first_name, last_name, gender) VALUES ('BM-2026-000001', 'أحمد', 'علي', 'male')")
            with self.assertRaises(sqlite3.IntegrityError):
                con.execute("INSERT INTO students(student_code, first_name, last_name, gender) VALUES ('BM-2026-000001', 'محمد', 'علي', 'male')")

    def test_gender_and_status_constraints(self):
        with connect(self.db_path) as con:
            with self.assertRaises(sqlite3.IntegrityError):
                con.execute("INSERT INTO students(student_code, first_name, last_name, gender) VALUES ('BM-1', 'اسم', 'لقب', 'unknown')")
            with self.assertRaises(sqlite3.IntegrityError):
                con.execute("INSERT INTO students(student_code, first_name, last_name, gender, status) VALUES ('BM-2', 'اسم', 'لقب', 'female', 'unknown')")

    def test_attendance_status_and_duplicate_prevention(self):
        with connect(self.db_path) as con:
            con.execute("INSERT INTO students(student_code, first_name, last_name, gender) VALUES ('BM-1', 'أحمد', 'علي', 'male')")
            student_id = con.execute("SELECT id FROM students WHERE student_code='BM-1'").fetchone()[0]
            con.execute("INSERT INTO groups(group_code, name) VALUES ('G-1', 'حلقة تجريبية')")
            group_id = con.execute("SELECT id FROM groups WHERE group_code='G-1'").fetchone()[0]
            con.execute("INSERT INTO attendance_sessions(group_id, session_date) VALUES (?, '2026-10-12')", (group_id,))
            session_id = con.execute("SELECT id FROM attendance_sessions").fetchone()[0]
            con.execute("INSERT INTO attendance_records(session_id, student_id, status) VALUES (?, ?, 'excused')", (session_id, student_id))
            with self.assertRaises(sqlite3.IntegrityError):
                con.execute("INSERT INTO attendance_records(session_id, student_id, status) VALUES (?, ?, 'present')", (session_id, student_id))
            with self.assertRaises(sqlite3.IntegrityError):
                con.execute("INSERT INTO attendance_records(session_id, student_id, status) VALUES (?, ?, 'unknown')", (session_id, student_id))

    def test_flexible_group_configuration(self):
        with connect(self.db_path) as con:
            con.execute("INSERT INTO groups(group_code, name, target_gender, min_age, max_age) VALUES ('G-1', 'حلقة مرنة', 'mixed', 8, 16)")
            with self.assertRaises(sqlite3.IntegrityError):
                con.execute("INSERT INTO groups(group_code, name, target_gender, min_age, max_age) VALUES ('G-2', 'حلقة غير صحيحة', 'mixed', 18, 10)")

    def test_enrollment_requires_existing_student_and_group(self):
        with connect(self.db_path) as con:
            with self.assertRaises(sqlite3.IntegrityError):
                con.execute("INSERT INTO enrollments(student_id, group_id, start_date) VALUES (999, 999, '2026-10-12')")

    def test_memorization_range_must_not_be_reversed(self):
        with connect(self.db_path) as con:
            con.execute("INSERT OR IGNORE INTO quran_surahs(surah_number, arabic_name, ayah_count) VALUES (1, 'الفاتحة', 7)")
            for ayah in range(1, 8):
                con.execute("INSERT INTO quran_ayahs(surah_number, ayah_number, juz_number, hizb_number, global_ayah_number) VALUES (1, ?, 1, 1, ?)", (ayah, ayah))
            con.execute("INSERT INTO students(student_code, first_name, last_name, gender) VALUES ('BM-1', 'أحمد', 'علي', 'male')")
            student_id = con.execute("SELECT id FROM students").fetchone()[0]
            con.execute("INSERT INTO memorization_sessions(student_id, session_date) VALUES (?, '2026-10-12')", (student_id,))
            session_id = con.execute("SELECT id FROM memorization_sessions").fetchone()[0]
            with self.assertRaises(sqlite3.IntegrityError):
                con.execute("""INSERT INTO memorization_entries
                    (session_id, work_type, start_surah, start_ayah, end_surah, end_ayah)
                    VALUES (?, 'new_memorization', 1, 5, 1, 3)""", (session_id,))
            con.execute("""INSERT INTO memorization_entries
                (session_id, work_type, start_surah, start_ayah, end_surah, end_ayah, status)
                VALUES (?, 'new_memorization', 1, 1, 1, 7, 'completed')""", (session_id,))

    def test_reinitialize_is_idempotent(self):
        initialize_database(self.db_path)
        with connect(self.db_path) as con:
            count = con.execute("SELECT COUNT(*) FROM institution").fetchone()[0]
            self.assertEqual(count, 1)

    def test_schema_has_expected_tables(self):
        expected = {
            "institution", "users", "families", "students", "student_guardians",
            "teachers", "levels", "groups", "academic_periods", "enrollments",
            "attendance_sessions", "attendance_records", "quran_surahs",
            "quran_ayahs", "memorization_sessions", "memorization_entries",
            "memorization_assessments", "scoring_rules", "audit_log", "backup_history"
        }
        with connect(self.db_path) as con:
            found = {row[0] for row in con.execute(
                "SELECT name FROM sqlite_master WHERE type='table'"
            )}
        self.assertTrue(expected.issubset(found), f"Missing: {expected - found}")


if __name__ == "__main__":
    unittest.main()
