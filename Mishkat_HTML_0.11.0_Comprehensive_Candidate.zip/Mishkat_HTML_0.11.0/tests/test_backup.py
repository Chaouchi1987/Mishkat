import tempfile
import unittest
from pathlib import Path

from src.backup import BackupError, create_backup, restore_backup, verify_backup
from src.db import initialize_database
from src.registry import register_student, search_students


class BackupTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.root = Path(self.tmp.name)
        self.db = self.root / 'school.sqlite3'
        initialize_database(self.db)
        register_student(str(self.db), {'first_name': 'مريم', 'last_name': 'علي', 'gender': 'female'})

    def tearDown(self):
        self.tmp.cleanup()

    def test_create_and_verify_backup(self):
        backup = create_backup(self.db, self.root / 'usb' / 'school-backup.sqlite3')
        info = verify_backup(backup)
        self.assertTrue(info['verified'])
        self.assertEqual(info['student_count'], 1)
        self.assertEqual(len(search_students(str(backup), 'مريم')), 1)

    def test_refuses_to_overwrite_backup(self):
        target = self.root / 'backup.sqlite3'
        create_backup(self.db, target)
        with self.assertRaises(BackupError):
            create_backup(self.db, target)

    def test_refuses_same_source_and_destination(self):
        with self.assertRaises(BackupError):
            create_backup(self.db, self.db)

    def test_restore_keeps_safety_backup(self):
        backup = create_backup(self.db, self.root / 'backup.sqlite3')
        register_student(str(self.db), {'first_name': 'يوسف', 'last_name': 'عمر', 'gender': 'male'})
        result = restore_backup(self.db, backup, self.root / 'before-restore.sqlite3')
        self.assertEqual(len(search_students(str(self.db))), 1)
        self.assertTrue(Path(result['safety_backup']).is_file())
        self.assertEqual(verify_backup(result['safety_backup'])['student_count'], 2)


if __name__ == '__main__':
    unittest.main()
