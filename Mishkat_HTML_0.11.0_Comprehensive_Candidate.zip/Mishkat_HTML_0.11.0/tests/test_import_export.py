import io, zipfile, unittest
from src.import_export import read_tabular

class ImportParserTests(unittest.TestCase):
    def test_csv_reads_utf8_bom(self):
        rows=read_tabular('list.csv','\ufeffالاسم,اللقب\nأحمد,صالح\n'.encode('utf-8'))
        self.assertEqual(rows[0],['الاسم','اللقب']); self.assertEqual(rows[1],['أحمد','صالح'])

    def test_xlsx_reads_first_sheet_and_shared_strings(self):
        files={
          'xl/workbook.xml':b'<?xml version="1.0"?><workbook xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships"><sheets><sheet name="Sheet1" sheetId="1" r:id="rId1"/></sheets></workbook>',
          'xl/_rels/workbook.xml.rels':b'<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Target="worksheets/sheet1.xml" Type="worksheet"/></Relationships>',
          'xl/sharedStrings.xml':'<sst xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main"><si><t>الاسم</t></si><si><t>أحمد</t></si></sst>'.encode('utf-8'),
          'xl/worksheets/sheet1.xml':b'<worksheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main"><sheetData><row r="1"><c r="A1" t="s"><v>0</v></c></row><row r="2"><c r="A2" t="s"><v>1</v></c></row></sheetData></worksheet>'}
        buf=io.BytesIO()
        with zipfile.ZipFile(buf,'w') as z:
            for k,v in files.items(): z.writestr(k,v)
        rows=read_tabular('test.xlsx',buf.getvalue())
        self.assertEqual(rows,[['الاسم'],['أحمد']])

    def test_docx_reads_first_table(self):
        document='''<w:document xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main"><w:body><w:tbl><w:tr><w:tc><w:p><w:r><w:t>الاسم</w:t></w:r></w:p></w:tc></w:tr><w:tr><w:tc><w:p><w:r><w:t>ليلى</w:t></w:r></w:p></w:tc></w:tr></w:tbl></w:body></w:document>'''.encode('utf-8')
        buf=io.BytesIO()
        with zipfile.ZipFile(buf,'w') as z: z.writestr('word/document.xml',document)
        self.assertEqual(read_tabular('test.docx',buf.getvalue()),[['الاسم'],['ليلى']])

    def test_legacy_formats_are_not_silently_misread(self):
        with self.assertRaisesRegex(ValueError,'الصيغة القديمة'): read_tabular('old.xls',b'old')

if __name__=='__main__': unittest.main()
