import tempfile
import unittest
from pathlib import Path

from src.db import initialize_database, connect, MIGRATIONS_DIR
from src.registry import register_student, search_students, DuplicateStudentWarning, RegistryError


class PhaseARegressionTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.db = str(Path(self.tmp.name) / 'school.sqlite3')
        initialize_database(self.db)

    def tearDown(self):
        self.tmp.cleanup()

    def add(self, first, last, birth=None, family=None, family_id=None, allow_duplicate=False):
        return register_student(self.db, {'first_name': first, 'last_name': last, 'gender': 'male', 'birth_date': birth}, family or {}, family_id, allow_duplicate=allow_duplicate)

    def test_arabic_search_normalizes_alef_and_taa_marbuta(self):
        self.add('أحمد', 'الإدريسي')
        self.assertEqual(len(search_students(self.db, 'احمد')), 1)
        self.assertEqual(len(search_students(self.db, 'ادريسي')), 1)
        self.add('فاطمة', 'مصطفى')
        self.assertEqual(len(search_students(self.db, 'فاطمه')), 1)
        self.assertEqual(len(search_students(self.db, 'مصطفي')), 1)

    def test_duplicate_warns_but_can_be_confirmed(self):
        self.add('TEST-أحمد', 'TEST-علي', '2010-01-01')
        with self.assertRaises(DuplicateStudentWarning):
            self.add('TEST-أحمد', 'TEST-علي', '2010-01-01')
        confirmed = self.add('TEST-أحمد', 'TEST-علي', '2010-01-01', allow_duplicate=True)
        self.assertTrue(confirmed['id'])

    def test_twins_with_different_birth_dates_are_not_blocked(self):
        self.add('TEST-محمد', 'TEST-علي', '2010-01-01')
        with self.assertRaises(DuplicateStudentWarning):
            self.add('TEST-محمد', 'TEST-علي', '2010-01-01')
        other = self.add('TEST-محمد', 'TEST-علي', '2010-01-02')
        self.assertTrue(other['id'])

    def test_existing_family_rejects_unsaved_guardian_fields(self):
        first = self.add('TEST-سارة', 'TEST-علي', family={'father_first_name':'TEST-أب','father_last_name':'TEST-علي'})
        with self.assertRaises(RegistryError):
            self.add('TEST-مريم', 'TEST-علي', family={'mother_first_name':'TEST-أم'}, family_id=first['family_id'])
        with connect(self.db) as con:
            self.assertEqual(con.execute('SELECT COUNT(*) FROM student_guardians WHERE student_id=(SELECT id FROM students WHERE first_name=? ORDER BY id DESC LIMIT 1)', ('TEST-مريم',)).fetchone()[0], 0)

    def test_migrations_idempotent_and_checksum_recorded(self):
        initialize_database(self.db)
        with connect(self.db) as con:
            rows = con.execute('SELECT version, checksum FROM schema_migrations ORDER BY version').fetchall()
            self.assertGreaterEqual(len(rows), 2)
            self.assertTrue(all(row['checksum'] for row in rows))

    def test_supervisor_name_is_not_hardcoded(self):
        with connect(self.db) as con:
            row = con.execute('SELECT supervisor_name FROM institution WHERE id=1').fetchone()
            self.assertEqual(row[0], '')

    def test_migration_preserves_existing_records(self):
        legacy = str(Path(self.tmp.name) / 'legacy.sqlite3')
        # Build a pre-migrations database from the original schema, then seed a test record.
        from pathlib import Path as P
        import sqlite3
        schema = (P(__file__).resolve().parents[1] / 'database' / 'migrations' / '001_initial.sql').read_text(encoding='utf-8')
        with sqlite3.connect(legacy) as con:
            con.executescript(schema)
            con.execute("INSERT INTO institution(id, official_name, branch_name, supervisor_name) VALUES (1, 'TEST-مؤسسة', 'TEST-فرع', '')")
            con.execute("INSERT INTO students(student_code, first_name, last_name, gender) VALUES ('TEST-0001', 'TEST-أحمد', 'TEST-علي', 'male')")
        initialize_database(legacy)
        with connect(legacy) as con:
            row = con.execute("SELECT student_code, search_key FROM students WHERE student_code='TEST-0001'").fetchone()
            versions = [r[0] for r in con.execute('SELECT version FROM schema_migrations ORDER BY version')]
        self.assertEqual(row['student_code'], 'TEST-0001')
        self.assertEqual(row['search_key'], 'test-احمد test-علي')
        self.assertEqual(versions, [1, 2, 3, 4, 5])

    def test_family_update_and_archive(self):
        from src.registry import update_family, archive_family, list_families
        self.add('TEST-طفل', 'TEST-علي', family={'father_first_name':'TEST-أب'})
        family_id = list_families(self.db)[0]['id']
        update_family(self.db, family_id, {'address':'TEST-عنوان'})
        archive_family(self.db, family_id)
        self.assertEqual(list_families(self.db), [])

    def test_changed_applied_migration_is_rejected(self):
        import shutil
        import tempfile as tempfile_module
        from unittest.mock import patch
        import src.db as db_module
        with tempfile_module.TemporaryDirectory() as migrations_dir:
            dest = Path(migrations_dir)
            for source in sorted(MIGRATIONS_DIR.glob('*.sql')):
                shutil.copy2(source, dest / source.name)
            changed = dest / '002_search_keys.sql'
            changed.write_text(changed.read_text(encoding='utf-8') + "\n-- changed after application\n", encoding='utf-8')
            with patch.object(db_module, 'MIGRATIONS_DIR', dest):
                with self.assertRaisesRegex(RuntimeError, 'بصمة ترحيل مطبّق تغيّرت'):
                    initialize_database(self.db)

    def test_backup_destination_type_is_explicit_and_logged(self):
        from src.backup import create_backup
        target = Path(self.tmp.name) / 'external' / 'backup.sqlite3'
        create_backup(self.db, target, destination_type='usb')
        with connect(self.db) as con:
            row = con.execute("SELECT destination_type, result FROM backup_history ORDER BY id DESC LIMIT 1").fetchone()
        self.assertEqual(row['destination_type'], 'usb')
        self.assertEqual(row['result'], 'verified')


if __name__ == '__main__':
    unittest.main()
