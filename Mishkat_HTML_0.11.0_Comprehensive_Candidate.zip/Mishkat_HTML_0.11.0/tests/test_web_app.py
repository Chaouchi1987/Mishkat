import json
import tempfile
import threading
import unittest
from http.server import ThreadingHTTPServer
from pathlib import Path
from urllib.request import Request, urlopen
from urllib.error import HTTPError
from urllib.parse import quote

from src.db import initialize_database, validate_database
from src.web_app import MishkatHandler


class WebAppTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.db = Path(self.tmp.name) / "school.sqlite3"
        initialize_database(self.db)
        self.httpd = ThreadingHTTPServer(("127.0.0.1", 0), MishkatHandler)
        self.httpd.daemon_threads = True
        self.httpd.db_path = self.db
        self.thread = threading.Thread(target=self.httpd.serve_forever, daemon=True)
        self.thread.start()
        self.base = f"http://127.0.0.1:{self.httpd.server_address[1]}"

    def tearDown(self):
        self.httpd.shutdown()
        self.httpd.server_close()
        self.thread.join(timeout=2)
        self.tmp.cleanup()

    def request(self, path, method="GET", body=None, headers=None):
        data = None if body is None else json.dumps(body, ensure_ascii=False).encode("utf-8")
        req = Request(self.base + path, data=data, method=method, headers=headers or {})
        try:
            with urlopen(req, timeout=3) as response:
                return response.status, json.loads(response.read().decode("utf-8")) if "json" in response.headers.get("Content-Type", "") else response.read().decode("utf-8")
        except HTTPError as e:
            raw = e.read().decode("utf-8")
            return e.code, json.loads(raw)

    def student(self, **overrides):
        data = {"first_name": "أحمد", "last_name": "بن صالح", "student_code": "ST-001", "gender": "male", "student_category": "child", "status": "active"}
        data.update(overrides)
        return data


    def test_quran_surah_reference_is_complete_and_has_no_verse_text(self):
        status, body = self.request("/api/quran/surahs")
        self.assertEqual(status, 200)
        self.assertEqual(len(body["surahs"]), 114)
        self.assertEqual(body["surahs"][0]["arabic_name"], "الفاتحة")
        self.assertEqual(body["surahs"][0]["ayah_count"], 7)
        self.assertEqual(sum(x["ayah_count"] for x in body["surahs"]), 6236)
        self.assertNotIn("text", body["surahs"][0])

    def test_memorization_entry_saved_and_history_returned(self):
        status, student = self.request("/api/students", "POST", self.student())
        self.assertEqual(status, 201)
        payload = {"student_id": student["id"], "session_date": "2026-10-13", "work_type": "new_memorization",
            "start_surah": 1, "start_ayah": 1, "end_surah": 1, "end_ayah": 7,
            "score": 9.5, "mistake_count": 1, "decision": "accepted", "notes": "أداء جيد"}
        status, saved = self.request("/api/memorization", "POST", payload)
        self.assertEqual(status, 201, saved)
        status, history = self.request("/api/memorization?student_id=" + str(student["id"]))
        self.assertEqual(status, 200)
        self.assertEqual(history["summary"]["entries"], 1)
        self.assertEqual(history["entries"][0]["score"], 9.5)
        self.assertEqual(history["entries"][0]["decision"], "accepted")
        self.assertEqual(history["entries"][0]["start_surah_name"], "الفاتحة")

    def test_memorization_rejects_ayah_outside_surah(self):
        status, student = self.request("/api/students", "POST", self.student())
        payload = {"student_id": student["id"], "session_date": "2026-10-13", "work_type": "new_memorization",
            "start_surah": 1, "start_ayah": 1, "end_surah": 1, "end_ayah": 8,
            "score": 8, "mistake_count": 0, "decision": "accepted"}
        status, body = self.request("/api/memorization", "POST", payload)
        self.assertEqual(status, 400)
        self.assertIn("عدد آيات السورة", body["error"])

    def test_memorization_rejects_reversed_range(self):
        status, student = self.request("/api/students", "POST", self.student())
        payload = {"student_id": student["id"], "session_date": "2026-10-13", "work_type": "new_memorization",
            "start_surah": 2, "start_ayah": 20, "end_surah": 1, "end_ayah": 7,
            "score": 8, "mistake_count": 0, "decision": "accepted"}
        status, body = self.request("/api/memorization", "POST", payload)
        self.assertEqual(status, 400)
        self.assertIn("تسبق بدايته", body["error"])

    def test_memorization_rejects_invalid_score_and_decision(self):
        status, student = self.request("/api/students", "POST", self.student())
        base = {"student_id": student["id"], "session_date": "2026-10-13", "work_type": "new_memorization",
            "start_surah": 1, "start_ayah": 1, "end_surah": 1, "end_ayah": 7,
            "score": 11, "mistake_count": 0, "decision": "accepted"}
        status, _ = self.request("/api/memorization", "POST", base)
        self.assertEqual(status, 400)
        base["score"] = 8; base["decision"] = "maybe"
        status, _ = self.request("/api/memorization", "POST", base)
        self.assertEqual(status, 400)

    def test_home_serves_local_arabic_html(self):
        status, html = self.request("/")
        self.assertEqual(status, 200)
        self.assertIn('dir="rtl"', html)
        self.assertIn("مِشكاة", html)

    def test_health_reports_local_database(self):
        status, body = self.request("/api/health")
        self.assertEqual(status, 200)
        self.assertEqual(body["status"], "ok")
        self.assertFalse(body["online_required"])

    def test_create_student_and_dashboard_counts(self):
        status, body = self.request("/api/students", "POST", self.student())
        self.assertEqual(status, 201, body)
        status, dashboard = self.request("/api/dashboard")
        self.assertEqual(status, 200)
        self.assertEqual(dashboard["total_students"], 1)
        self.assertEqual(dashboard["active_students"], 1)
        self.assertEqual(dashboard["children"], 1)

    def test_duplicate_name_requires_confirmation(self):
        self.request("/api/students", "POST", self.student())
        status, body = self.request("/api/students", "POST", self.student(student_code="ST-002"))
        self.assertEqual(status, 409)
        self.assertEqual(body["code"], "duplicate_student")
        status, _ = self.request("/api/students", "POST", self.student(student_code="ST-002"), {"X-Confirm-Duplicate": "yes"})
        self.assertEqual(status, 201)

    def test_duplicate_code_rejected(self):
        self.request("/api/students", "POST", self.student())
        status, body = self.request("/api/students", "POST", self.student(first_name="ليلى", student_code="ST-001"))
        self.assertEqual(status, 409)
        self.assertEqual(body["code"], "duplicate_code")

    def test_arabic_search_normalization(self):
        self.request("/api/students", "POST", self.student())
        status, body = self.request("/api/students?q=" + quote("احمد"))
        self.assertEqual(status, 200)
        self.assertEqual(len(body["students"]), 1)

    def test_bad_input_rejected(self):
        status, body = self.request("/api/students", "POST", {"first_name": "", "last_name": "", "student_code": ""})
        self.assertEqual(status, 400)
        self.assertIn("error", body)

    def test_backup_is_created_and_validated(self):
        status, body = self.request("/api/backup", "POST", {})
        self.assertEqual(status, 201, body)
        backup = Path(body["path"])
        self.assertTrue(backup.exists())
        self.assertEqual(validate_database(self.db), [])
        from src.db import connect
        with connect(self.db) as con:
            row = con.execute("SELECT result,destination_type FROM backup_history ORDER BY id DESC LIMIT 1").fetchone()
        self.assertEqual(row["result"], "verified")
        self.assertEqual(row["destination_type"], "local")

    def test_institution_identity_can_be_configured(self):
        status, original = self.request("/api/institution")
        self.assertEqual(status, 200)
        self.assertEqual(original["branch_name"], "شعبة بئر مقدم")
        status, body = self.request("/api/institution", "POST", {
            "official_name": "جمعية العلماء المسلمين الجزائريين",
            "branch_name": "شعبة بئر مقدم",
            "supervisor_name": "مشرف تجريبي",
            "phone": "0550000000",
            "address": "بئر مقدم"
        })
        self.assertEqual(status, 200, body)
        status, updated = self.request("/api/institution")
        self.assertEqual(updated["supervisor_name"], "مشرف تجريبي")

    def test_create_family_and_link_siblings(self):
        status, family = self.request("/api/families", "POST", {
            "father_first_name": "محمد", "father_last_name": "بن صالح",
            "father_phone": "0550000000", "mother_first_name": "فاطمة",
            "mother_last_name": "بن صالح", "address": "بئر مقدم"
        })
        self.assertEqual(status, 201, family)
        family_id = family["id"]
        status, one = self.request("/api/students", "POST", self.student(student_code="ST-FAM-001", family_id=str(family_id)))
        self.assertEqual(status, 201, one)
        status, two = self.request("/api/students", "POST", self.student(first_name="ليلى", student_code="ST-FAM-002", family_id=str(family_id)))
        self.assertEqual(status, 201, two)
        status, data = self.request("/api/families")
        self.assertEqual(status, 200)
        found = next(f for f in data["families"] if f["id"] == family_id)
        self.assertEqual(found["student_count"], 2)
        self.assertIn("أحمد بن صالح", found["student_names"])
        self.assertIn("ليلى بن صالح", found["student_names"])
        from src.db import connect
        with connect(self.db) as con:
            guardians = con.execute("SELECT COUNT(*) FROM student_guardians WHERE family_id=?", (family_id,)).fetchone()[0]
        self.assertEqual(guardians, 4)

    def test_family_delete_requires_no_linked_students_and_archive_preserves_links(self):
        status, family = self.request("/api/families", "POST", {"father_first_name": "علي", "father_last_name": "صالح"})
        self.assertEqual(status, 201)
        fid = family["id"]
        self.request("/api/students", "POST", self.student(student_code="ST-LINK-1", family_id=str(fid)))
        status, body = self.request(f"/api/families/{fid}", "POST", {"action": "delete", "confirm": True})
        self.assertEqual(status, 409)
        status, body = self.request(f"/api/families/{fid}", "POST", {"action": "archive"})
        self.assertEqual(status, 200)
        status, active = self.request("/api/families")
        self.assertFalse(any(f["id"] == fid for f in active["families"]))
        status, all_rows = self.request("/api/families?all=1")
        archived = next(f for f in all_rows["families"] if f["id"] == fid)
        self.assertEqual(archived["student_count"], 1)
        self.assertEqual(archived["status"], "archived")

    def test_family_form_and_reception_are_in_html(self):
        status, html = self.request("/")
        self.assertEqual(status, 200)
        self.assertIn("واجهة استقبال الجمعية", html)
        self.assertIn("الأسر والأولياء", html)
        self.assertIn("studentFamily", html)
        self.assertIn("بيانات الجمعية والشعبة", html)

    def test_logo_upload_is_local_and_validated(self):
        import base64
        png_bytes = b"\x89PNG\r\n\x1a\n" + b"\x00\x00\x00\x0dIHDR" + b"\x00\x00\x00\x01\x00\x00\x00\x01" + b"\x08\x06\x00\x00\x00"
        logo_data = "data:image/png;base64," + base64.b64encode(png_bytes).decode("ascii")
        status, body = self.request("/api/institution", "POST", {
            "official_name": "جمعية العلماء المسلمين الجزائريين",
            "branch_name": "شعبة بئر مقدم",
            "supervisor_name": "",
            "logo_data": logo_data
        })
        self.assertEqual(status, 200, body)
        with urlopen(self.base + "/api/logo", timeout=3) as response:
            self.assertEqual(response.status, 200)
            self.assertEqual(response.headers.get_content_type(), "image/png")
            self.assertEqual(response.read(), png_bytes)
        status, body = self.request("/api/institution", "POST", {
            "official_name": "جمعية العلماء المسلمين الجزائريين",
            "branch_name": "شعبة بئر مقدم",
            "logo_data": "data:image/svg+xml;base64,PHN2Zz4="
        })
        self.assertEqual(status, 400)


    def test_teacher_level_group_crud_and_validation(self):
        status, teacher = self.request("/api/teachers", "POST", {"teacher_code":"T-001","first_name":"عبد الرحمن","last_name":"صالح","specialty":"تجويد"})
        self.assertEqual(status, 201, teacher)
        tid = teacher["id"]
        status, duplicate = self.request("/api/teachers", "POST", {"teacher_code":"T-001","first_name":"اسم","last_name":"مكرر"})
        self.assertEqual(status, 409)
        status, updated = self.request(f"/api/teachers/{tid}", "POST", {"teacher_code":"T-001","first_name":"عبد الرحمن","last_name":"صالح","specialty":"حفظ"})
        self.assertEqual(status, 200, updated)
        status, level = self.request("/api/levels", "POST", {"name":"المبتدئ","min_age":"6","max_age":"12"})
        self.assertEqual(status, 201, level)
        status, bad_level = self.request("/api/levels", "POST", {"name":"نطاق غير صحيح","min_age":"15","max_age":"10"})
        self.assertEqual(status, 400)
        status, group = self.request("/api/groups", "POST", {"group_code":"G-001","name":"حلقة النور","level_id":str(level["id"]),"teacher_id":str(tid),"target_gender":"mixed","min_age":"6","max_age":"12","schedule_text":"السبت مساءً"})
        self.assertEqual(status, 201, group)
        status, rows = self.request("/api/groups")
        self.assertEqual(status, 200)
        self.assertEqual(rows["groups"][0]["teacher_name"], "عبد الرحمن صالح")
        status, updated_group = self.request(f"/api/groups/{group['id']}", "POST", {"group_code":"G-001","name":"حلقة النور المعدلة","level_id":str(level['id']),"teacher_id":str(tid),"target_gender":"mixed","min_age":"6","max_age":"12","schedule_text":"الثلاثاء"})
        self.assertEqual(status, 200, updated_group)
        status, disabled = self.request(f"/api/groups/{group['id']}", "POST", {"action":"deactivate"})
        self.assertEqual(status, 200)
        status, all_groups = self.request("/api/groups?all=1")
        self.assertFalse(next(g for g in all_groups["groups"] if g["id"] == group["id"])["is_active"])

    def test_student_enrollment_rejects_second_active_and_preserves_history(self):
        status, teacher = self.request("/api/teachers", "POST", {"teacher_code":"T-ENR","first_name":"معلم","last_name":"تجريبي"})
        self.assertEqual(status, 201, teacher)
        status, level = self.request("/api/levels", "POST", {"name":"أساسيات"})
        self.assertEqual(status, 201, level)
        status, group1 = self.request("/api/groups", "POST", {"group_code":"G-ENR1","name":"حلقة أولى","level_id":str(level['id']),"teacher_id":str(teacher['id'])})
        self.assertEqual(status, 201, group1)
        status, group2 = self.request("/api/groups", "POST", {"group_code":"G-ENR2","name":"حلقة ثانية"})
        self.assertEqual(status, 201, group2)
        status, student = self.request("/api/students", "POST", self.student(student_code="ST-ENR"))
        self.assertEqual(status, 201, student)
        status, enrollment = self.request("/api/enrollments", "POST", {"student_id":student['id'],"group_id":group1['id'],"start_date":"2026-10-13"})
        self.assertEqual(status, 201, enrollment)
        status, duplicate = self.request("/api/enrollments", "POST", {"student_id":student['id'],"group_id":group2['id'],"start_date":"2026-10-13"})
        self.assertEqual(status, 409)
        status, ended = self.request("/api/enrollments", "POST", {"action":"withdraw","enrollment_id":enrollment['id']})
        self.assertEqual(status, 200, ended)
        status, next_enrollment = self.request("/api/enrollments", "POST", {"student_id":student['id'],"group_id":group2['id'],"start_date":"2026-10-14"})
        self.assertEqual(status, 201, next_enrollment)
        status, all_enrollments = self.request("/api/enrollments?all=1")
        self.assertEqual(len(all_enrollments['enrollments']), 2)
        self.assertEqual(sum(e['status']=='active' for e in all_enrollments['enrollments']), 1)

    def test_teaching_page_and_api_are_present(self):
        status, html = self.request("/")
        self.assertEqual(status, 200)
        for text in ("إدارة المعلمين والمستويات والحلقات", "تسجيل الطلبة في الحلقات", "teacherForm", "levelForm", "groupForm", "enrollmentForm"):
            self.assertIn(text, html)
        for endpoint in ("/api/teachers", "/api/levels", "/api/groups", "/api/enrollments"):
            status, body = self.request(endpoint)
            self.assertEqual(status, 200, endpoint)
            self.assertIsInstance(body, dict)


    def _attendance_fixture(self):
        status, student = self.request("/api/students", "POST", self.student(student_code="ST-ATT-001"))
        self.assertEqual(status, 201, student)
        status, group = self.request("/api/groups", "POST", {"group_code":"G-ATT-001","name":"حلقة الاختبار","target_gender":"mixed"})
        self.assertEqual(status, 201, group)
        status, enrollment = self.request("/api/enrollments", "POST", {"student_id":student["id"],"group_id":group["id"],"start_date":"2026-10-01"})
        self.assertEqual(status, 201, enrollment)
        return student, group

    def test_attendance_roster_uses_enrollments_at_requested_date(self):
        student, group = self._attendance_fixture()
        status, body = self.request(f"/api/attendance?group_id={group['id']}&date=2026-10-13")
        self.assertEqual(status, 200, body)
        self.assertEqual(len(body["students"]), 1)
        self.assertEqual(body["students"][0]["student_id"], student["id"])
        self.assertIsNone(body["session"])

    def test_attendance_save_and_reopen(self):
        student, group = self._attendance_fixture()
        payload = {"group_id":group["id"],"session_date":"2026-10-13","session_label":"الحصة الصباحية","records":[{"student_id":student["id"],"status":"late","reason":"ازدحام","notes":"اختبار"}]}
        status, saved = self.request("/api/attendance", "POST", payload)
        self.assertEqual(status, 201, saved)
        self.assertEqual(saved["saved_records"], 1)
        status, opened = self.request(f"/api/attendance?group_id={group['id']}&date=2026-10-13")
        self.assertEqual(status, 200)
        self.assertEqual(opened["students"][0]["status"], "late")
        self.assertEqual(opened["students"][0]["reason"], "ازدحام")
        self.assertEqual(opened["session"]["session_label"], "الحصة الصباحية")
        self.assertEqual(opened["history"][0]["marked_count"], 1)
        self.assertEqual(opened["history"][0]["roster_count"], 1)

    def test_attendance_rejects_missing_status_and_non_roster_student(self):
        student, group = self._attendance_fixture()
        status, body = self.request("/api/attendance", "POST", {"group_id":group["id"],"session_date":"2026-10-13","records":[{"student_id":student["id"],"status":""}]})
        self.assertEqual(status, 400)
        self.assertIn("حدد حالة", body["error"])
        status, body = self.request("/api/attendance", "POST", {"group_id":group["id"],"session_date":"2026-10-13","records":[{"student_id":9999,"status":"present"}]})
        self.assertEqual(status, 400)

    def test_attendance_close_requires_complete_roster_and_blocks_edits(self):
        student, group = self._attendance_fixture()
        payload = {"group_id":group["id"],"session_date":"2026-10-13","records":[{"student_id":student["id"],"status":"present"}]}
        status, saved = self.request("/api/attendance", "POST", payload)
        self.assertEqual(status, 201, saved)
        status, closed = self.request("/api/attendance", "POST", {"action":"close","group_id":group["id"],"session_date":"2026-10-13","records":payload["records"]})
        self.assertEqual(status, 200, closed)
        status, body = self.request("/api/attendance", "POST", payload)
        self.assertEqual(status, 409)
        self.assertIn("مغلق", body["error"])

    def test_attendance_duplicate_student_in_payload_rejected(self):
        student, group = self._attendance_fixture()
        rec = {"student_id":student["id"],"status":"present"}
        status, body = self.request("/api/attendance", "POST", {"group_id":group["id"],"session_date":"2026-10-13","records":[rec,rec]})
        self.assertEqual(status, 400)
        self.assertIn("تكرر الطالب", body["error"])

    def test_attendance_page_is_enabled_and_has_statuses(self):
        status, html = self.request("/")
        self.assertEqual(status, 200)
        self.assertIn('id="page-attendance"', html)
        self.assertIn("مغادرة مبكرة", html)
        self.assertIn('data-page="attendance"', html)



if __name__ == "__main__":
    unittest.main()
