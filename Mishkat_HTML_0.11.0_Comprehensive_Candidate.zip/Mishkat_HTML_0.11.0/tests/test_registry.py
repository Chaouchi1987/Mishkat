import tempfile
import unittest
from pathlib import Path

from src.db import initialize_database, validate_database
from src.registry import RegistryError, get_student, register_student, search_students, list_families


class RegistryTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.db = str(Path(self.temp.name) / "school.sqlite3")
        initialize_database(self.db)

    def tearDown(self):
        self.temp.cleanup()

    def test_register_adult_woman_without_family(self):
        result = register_student(self.db, {
            "first_name": "فاطمة", "last_name": "بن صالح", "gender": "female",
            "student_category": "adult", "status": "active"
        })
        saved = get_student(self.db, result["id"])
        self.assertEqual(saved["gender"], "female")
        self.assertEqual(saved["student_category"], "adult")
        self.assertIsNone(saved["family_id"])
        self.assertRegex(result["student_code"], r"^BM-\d{4}-\d{6}$")

    def test_register_child_with_new_family(self):
        result = register_student(self.db, {
            "first_name": "محمد", "last_name": "علي", "gender": "male", "student_category": "child"
        }, {
            "father_first_name": "أحمد", "father_last_name": "علي", "father_phone": "0550000000"
        })
        saved = get_student(self.db, result["id"])
        self.assertIsNotNone(saved["family_id"])
        self.assertEqual(saved["family_code"], "FAM-000001")
        self.assertEqual(saved["father_phone"], "0550000000")

    def test_multiple_siblings_can_share_existing_family(self):
        first = register_student(self.db, {
            "first_name": "أمين", "last_name": "علي", "gender": "male"
        }, {"father_first_name": "أحمد", "father_last_name": "علي"})
        family_id = first["family_id"]
        second = register_student(self.db, {
            "first_name": "مريم", "last_name": "علي", "gender": "female"
        }, {}, family_id)
        self.assertEqual(get_student(self.db, second["id"])["family_id"], family_id)
        self.assertEqual(len(list_families(self.db)), 1)

    def test_search_by_name_code_and_phone(self):
        result = register_student(self.db, {
            "first_name": "يوسف", "last_name": "قاسم", "gender": "male"
        }, {"mother_phone": "0661234567"})
        self.assertEqual(len(search_students(self.db, "يوسف")), 1)
        self.assertEqual(len(search_students(self.db, result["student_code"])), 1)
        self.assertEqual(len(search_students(self.db, "0661234567")), 1)

    def test_required_name(self):
        with self.assertRaises(RegistryError):
            register_student(self.db, {"first_name": "", "last_name": "علي", "gender": "male"})

    def test_invalid_gender(self):
        with self.assertRaises(RegistryError):
            register_student(self.db, {"first_name": "علي", "last_name": "محمد", "gender": "unknown"})

    def test_invalid_and_future_birth_dates(self):
        for value in ("31/12/2010", "2099-01-01"):
            with self.subTest(value=value):
                with self.assertRaises(RegistryError):
                    register_student(self.db, {
                        "first_name": "علي", "last_name": "محمد", "gender": "male", "birth_date": value
                    })

    def test_invalid_family_id(self):
        with self.assertRaises(RegistryError):
            register_student(self.db, {
                "first_name": "علي", "last_name": "محمد", "gender": "male"
            }, {}, 999)

    def test_database_integrity_after_operations(self):
        register_student(self.db, {
            "first_name": "ليلى", "last_name": "عمر", "gender": "female", "student_category": "adult"
        })
        self.assertEqual(validate_database(self.db), [])


if __name__ == "__main__":
    unittest.main()
