from pathlib import Path
import unittest

ROOT = Path(__file__).resolve().parents[1]


class InstallerConfigurationTests(unittest.TestCase):
    def test_installer_includes_built_application(self):
        config = (ROOT / "MishkatSetup.iss").read_text(encoding="utf-8")
        self.assertIn('Source: "dist\\Mishkat\\*"', config)
        self.assertIn('Filename: "{app}\\{#AppExeName}"', config)

    def test_installer_is_per_user_and_does_not_remove_user_data(self):
        config = (ROOT / "MishkatSetup.iss").read_text(encoding="utf-8")
        self.assertIn("PrivilegesRequired=lowest", config)
        self.assertIn("{localappdata}\\Programs\\Mishkat", config)
        self.assertIn("User data lives under %LOCALAPPDATA%\\Mishkat\\data", config)
        self.assertNotIn("{localappdata}\\Mishkat\\data", config.split("[UninstallDelete]")[-1] if "[UninstallDelete]" in config else "")

    def test_ci_builds_installer_artifact(self):
        workflow = (ROOT / ".github" / "workflows" / "build-windows.yml").read_text(encoding="utf-8")
        self.assertIn("Build Arabic Windows installer", workflow)
        self.assertIn("Mishkat-Setup-0.11.0-x64.exe", workflow)
        self.assertIn("actions/upload-artifact@v4", workflow)
        self.assertIn('--add-data "web;web" main.py', workflow)
        self.assertIn("005_association_management.sql", workflow)


if __name__ == "__main__":
    unittest.main()
