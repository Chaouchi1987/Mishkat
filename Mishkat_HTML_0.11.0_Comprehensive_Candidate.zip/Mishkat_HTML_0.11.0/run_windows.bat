@echo off
setlocal
cd /d "%~dp0"
where py >nul 2>nul
if not errorlevel 1 (
  py -3.11 -m src.app
  if not errorlevel 1 goto :eof
)
echo Could not start the source version. Install Python 3.11 x64 with Tcl/Tk or use the packaged Mishkat.exe.
pause
exit /b 1
