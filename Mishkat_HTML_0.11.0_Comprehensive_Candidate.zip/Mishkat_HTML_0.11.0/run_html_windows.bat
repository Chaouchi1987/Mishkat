@echo off
setlocal
chcp 65001 >nul
cd /d "%~dp0"
echo ============================================================
echo   MISHKAT - Local HTML platform
echo   Internet is NOT required for normal use
echo ============================================================
where py >nul 2>nul
if errorlevel 1 (
  echo Python runtime not found. This developer launcher requires Python 3.11+.
  echo The final Windows installer will bundle the runtime.
  pause
  exit /b 1
)
py -3 -c "import sqlite3; print('SQLite ready')" >nul 2>nul
if errorlevel 1 (
  echo A suitable Python runtime could not be started.
  pause
  exit /b 1
)
py -3 -m src.web_app
pause
