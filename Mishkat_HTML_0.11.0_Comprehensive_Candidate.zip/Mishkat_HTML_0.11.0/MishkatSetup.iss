; Inno Setup installer for Mishkat. Built on Windows by build_windows.bat or CI.
#define AppName "Mishkat"
#define AppVersion "0.11.0"
#define AppPublisher "جمعية العلماء المسلمين الجزائريين - شعبة بئر مقدم"
#define AppExeName "Mishkat.exe"

[Setup]
AppId={{C6F9C5C0-1C9B-4D72-9C83-6B09BFB3D7A1}
AppName={#AppName}
AppVersion={#AppVersion}
AppPublisher={#AppPublisher}
DefaultDirName={localappdata}\Programs\Mishkat
DefaultGroupName=Mishkat
DisableProgramGroupPage=yes
PrivilegesRequired=lowest
ArchitecturesAllowed=x64compatible
ArchitecturesInstallIn64BitMode=x64
OutputDir=dist-installer
OutputBaseFilename=Mishkat-Setup-{#AppVersion}-x64
Compression=lzma2/ultra64
SolidCompression=yes
WizardStyle=modern
UninstallDisplayName=Mishkat
CloseApplications=yes
RestartApplications=no

[Languages]
Name: "arabic"; MessagesFile: "compiler:Languages\Arabic.isl"
Name: "english"; MessagesFile: "compiler:Default.isl"

[Tasks]
Name: "desktopicon"; Description: "إنشاء اختصار على سطح المكتب"; GroupDescription: "اختصارات إضافية:"; Flags: unchecked

[Files]
Source: "dist\Mishkat\*"; DestDir: "{app}"; Flags: ignoreversion recursesubdirs createallsubdirs

[Icons]
Name: "{autoprograms}\Mishkat"; Filename: "{app}\{#AppExeName}"; WorkingDir: "{app}"
Name: "{autodesktop}\Mishkat"; Filename: "{app}\{#AppExeName}"; WorkingDir: "{app}"; Tasks: desktopicon

[Run]
Filename: "{app}\{#AppExeName}"; Description: "تشغيل مِشكاة"; Flags: postinstall nowait skipifsilent

; User data lives under %LOCALAPPDATA%\Mishkat\data and is intentionally not removed by uninstall.
