@echo off
setlocal EnableExtensions
cd /d "%~dp0"
title Mishkat - Windows Installer Build

echo ============================================================
echo  MISHKAT - Build Windows installer
 echo  Python and Inno Setup are needed on BUILD computer only
echo ============================================================

where py >nul 2>nul
if errorlevel 1 (
  echo ERROR: Python Launcher was not found. Use GitHub Actions or install Python 3.11 x64.
  goto :error
)
py -3.11 -c "import sys; assert sys.version_info[:2] == (3,11), sys.version" || (echo ERROR: Python 3.11 is required for this reproducible build. & goto :error)
py -3.11 -c "import tkinter; print('Tkinter OK')" || (echo ERROR: Tkinter is missing. Reinstall Python with Tcl/Tk support. & goto :error)

set "ISCC=%ProgramFiles(x86)%\Inno Setup 6\ISCC.exe"
if not exist "%ISCC%" set "ISCC=%ProgramFiles%\Inno Setup 6\ISCC.exe"
if not exist "%ISCC%" (
  echo ERROR: Inno Setup 6 compiler not found.
  echo Install Inno Setup 6 or run the GitHub Actions workflow to build without configuring this PC.
  goto :error
)

if not exist ".buildenv\Scripts\python.exe" py -3.11 -m venv .buildenv
if errorlevel 1 goto :error
".buildenv\Scripts\python.exe" -m pip install --disable-pip-version-check "pyinstaller==6.14.2" "pytest==8.4.1"
if errorlevel 1 goto :error

echo.
echo [1/5] Running regression tests...
".buildenv\Scripts\python.exe" -m pytest -q
if errorlevel 1 goto :error

echo.
echo [2/5] Checking Python syntax...
".buildenv\Scripts\python.exe" -m py_compile main.py src\*.py
if errorlevel 1 goto :error

echo.
echo [3/5] Building application files...
".buildenv\Scripts\python.exe" -m PyInstaller --noconfirm --clean --windowed --onedir --name Mishkat --add-data "database\migrations;database\migrations" --add-data "database\schema.sql;database" --add-data "web;web" main.py
if errorlevel 1 goto :error

 echo.
echo [4/5] Verifying executable and migrations...
if not exist "dist\Mishkat\Mishkat.exe" (echo ERROR: EXE was not created. & goto :error)
if not exist "dist\Mishkat\_internal\database\migrations\001_initial.sql" if not exist "dist\Mishkat\database\migrations\001_initial.sql" (echo ERROR: migration files were not bundled. & goto :error)

echo.
echo [5/5] Creating Setup.exe...
"%ISCC%" /Qp MishkatSetup.iss
if errorlevel 1 goto :error
if not exist "dist-installer\Mishkat-Setup-0.11.0-x64.exe" (echo ERROR: installer was not created. & goto :error)

echo.
echo BUILD SUCCEEDED.
echo Installer: dist-installer\Mishkat-Setup-0.11.0-x64.exe
echo Portable folder: dist\Mishkat\
echo User data is kept under %%LOCALAPPDATA%%\Mishkat\data and is not removed by uninstall.
echo This is a successful build, not proof of runtime certification on every Windows PC.
pause
exit /b 0

:error
echo.
echo BUILD FAILED. No certified installer was produced. Read the error above.
pause
exit /b 1
