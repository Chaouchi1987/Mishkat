# Changelog

## 0.6.0 — HTML local platform W1
- Added Arabic RTL HTML dashboard and student registry page.
- Added local-only HTTP API backed by SQLite using Python standard library.
- Added Arabic-normalized search, student registration, duplicate-name confirmation, and duplicate student-code rejection.
- Added local database backup creation and integrity verification from the interface, with backup history logging.
- Added responsive styling without CDN or remote assets.
- Added integration tests for local HTTP endpoints and student/backup flows.
- Existing Tkinter interface remains available as legacy fallback; Windows packaging for the new HTML entry point is not yet certified.

## 0.5.1 — Windows installer candidate
- Added Inno Setup and GitHub Actions build configuration for the legacy Tkinter application.
- No Windows installer was certified in this version.

## 0.5.0 — Windows candidate
- Added initial Windows packaging scripts and compatibility notes.

## 0.7.0 — HTML W2
- إضافة واجهة استقبال ببيانات جمعية/شعبة/مشرف قابلة للتعديل.
- إضافة رفع الشعار الرسمي وحفظه محليًا مع التحقق من النوع والحجم.
- تفعيل إدارة الأسر والأولياء وربط الإخوة بالأسرة نفسها.
- إضافة اختبارات API للأسرة والروابط والأرشفة والشعار.

## 0.8.0 — HTML W3
- إضافة واجهة إدارة المعلمين والمعلمات مع إنشاء وتعديل وتفعيل/تعطيل السجلات.
- إضافة إدارة المستويات التعليمية مع التحقق من نطاق الأعمار.
- إضافة إدارة الحلقات وربطها بمستوى ومعلم اختياريين، والتحقق من المراجع ونطاق الأعمار.
- إضافة تسجيل الطلبة النشطين في الحلقات وإنهاء التسجيل دون حذف التاريخ.
- منع وجود أكثر من تسجيل نشط للطالب في الوقت نفسه عبر واجهة API.
- إضافة اختبارات تكامل لمسارات المعلمين والمستويات والحلقات والتسجيل.
- لم يُبنَ مُثبّت Windows ولم يُختبر التشغيل المرئي على Windows في هذه المرحلة.

## 0.9.0 — HTML W4
- تفعيل شاشة الحضور وربطها بالحلقة والتاريخ.
- إضافة حالات حاضر/غائب/بعذر/متأخر/مغادرة مبكرة مع الأسباب والملاحظات.
- إضافة حفظ وتحديث سجل الحضور، سجل آخر 30 حصة، وإغلاق السجل بعد اكتمال الحالات.
- منع التعديل بعد إغلاق سجل الحضور والتحقق من صحة قائمة الطلبة وتواريخ التسجيل.
- إضافة اختبارات تكامل للحضور، الحفظ وإعادة القراءة، منع السجلات غير الصالحة، والإغلاق.
- لا تزال المتابعة القرآنية ومُثبّت Windows النهائي خارج نطاق هذه المرحلة.


## 0.10.0 — HTML W5
- تفعيل شاشة الحفظ الجديد والمراجعة القريبة والمراجعة التراكمية.
- إضافة مرجع محلي لأسماء السور وأعداد آياتها (114 سورة، مجموع 6236 آية وفق العد المعتمد في المرجع المضمّن)، دون تخزين أو توليد نص الآيات.
- إضافة التحقق الخادمي من أرقام السور والآيات وترتيب المقطع، والدرجة من 0 إلى 10، وعدد الأخطاء، وقرار المعلم.
- إضافة سجل تاريخي لكل طالب مع ملخص عدد السجلات ومتوسط الدرجة وقرارات المعلم.
- إضافة ترحيل قاعدة بيانات رقم 004 وجداول منفصلة لسجلات المتابعة القرآنية، مع تسجيل العمليات في سجل التدقيق.
- اجتازت الحزمة 62 اختبارًا آليًا واختبارين فرعيين؛ لم يُختبر العرض المرئي على Windows بعد.


## 0.11.0 — Comprehensive local association release candidate
- Added generic association records for members, committees, committee membership, meetings/minutes, suggestions, annual plans, activities/trips/support, financial transactions, assets and asset events, documents, awards, seating plans, and literary/financial/annual reports.
- Added CSV/XLSX/DOCX-table import preview and column mapping, safe non-overwriting import, CSV export, student/family bulk archive/delete guardrails, and generated draft reports.
- Added local document storage, membership-card/meeting print layouts, seating-plan generator, and selectable local/USB/external backup destination.
- Backup bundles include SQLite plus local assets/documents and restore validates the bundle before creating a safety backup.
- Switched Windows entrypoint to the local HTML app and updated packaging metadata/workflow to 0.11.0; Windows installer remains unbuilt and unverified in this environment.
