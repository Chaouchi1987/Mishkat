-- Association administration, finance, committees, assets, meetings, annual plans and documents.
CREATE TABLE IF NOT EXISTS association_members (
 id INTEGER PRIMARY KEY, member_code TEXT UNIQUE, first_name TEXT NOT NULL, last_name TEXT NOT NULL,
 birth_date TEXT, phone TEXT, email TEXT, address TEXT, membership_type TEXT NOT NULL DEFAULT 'member',
 role_title TEXT, biography TEXT, joined_date TEXT, status TEXT NOT NULL DEFAULT 'active' CHECK(status IN ('active','inactive','archived')),
 notes TEXT, created_at TEXT NOT NULL DEFAULT (datetime('now')), updated_at TEXT NOT NULL DEFAULT (datetime('now'))
);
CREATE TABLE IF NOT EXISTS committees (
 id INTEGER PRIMARY KEY, name TEXT NOT NULL UNIQUE, purpose TEXT, manager_member_id INTEGER REFERENCES association_members(id) ON DELETE SET NULL,
 start_date TEXT, end_date TEXT, status TEXT NOT NULL DEFAULT 'active' CHECK(status IN ('active','inactive','archived')),
 notes TEXT, created_at TEXT NOT NULL DEFAULT (datetime('now'))
);
CREATE TABLE IF NOT EXISTS committee_members (
 id INTEGER PRIMARY KEY, committee_id INTEGER NOT NULL REFERENCES committees(id) ON DELETE CASCADE,
 member_id INTEGER NOT NULL REFERENCES association_members(id) ON DELETE RESTRICT, position TEXT, start_date TEXT, end_date TEXT,
 UNIQUE(committee_id,member_id)
);
CREATE TABLE IF NOT EXISTS association_meetings (
 id INTEGER PRIMARY KEY, meeting_code TEXT UNIQUE, title TEXT NOT NULL, meeting_type TEXT NOT NULL DEFAULT 'ordinary',
 meeting_date TEXT NOT NULL, start_time TEXT, location TEXT, chairperson TEXT, secretary TEXT, agenda TEXT,
 decisions TEXT, minutes TEXT, attendance_names TEXT, status TEXT NOT NULL DEFAULT 'planned' CHECK(status IN ('planned','held','cancelled')),
 created_at TEXT NOT NULL DEFAULT (datetime('now'))
);
CREATE TABLE IF NOT EXISTS association_suggestions (
 id INTEGER PRIMARY KEY, title TEXT NOT NULL, description TEXT, submitted_by TEXT, submitted_date TEXT,
 status TEXT NOT NULL DEFAULT 'new' CHECK(status IN ('new','under_review','accepted','rejected','implemented')),
 decision_notes TEXT, created_at TEXT NOT NULL DEFAULT (datetime('now'))
);
CREATE TABLE IF NOT EXISTS annual_plan_items (
 id INTEGER PRIMARY KEY, title TEXT NOT NULL, category TEXT NOT NULL DEFAULT 'activity', description TEXT,
 planned_start TEXT, planned_end TEXT, responsible_committee_id INTEGER REFERENCES committees(id) ON DELETE SET NULL,
 budget_estimate REAL NOT NULL DEFAULT 0 CHECK(budget_estimate>=0), progress INTEGER NOT NULL DEFAULT 0 CHECK(progress BETWEEN 0 AND 100),
 status TEXT NOT NULL DEFAULT 'planned' CHECK(status IN ('planned','in_progress','completed','delayed','cancelled')),
 actual_notes TEXT, created_at TEXT NOT NULL DEFAULT (datetime('now'))
);
CREATE TABLE IF NOT EXISTS association_activities (
 id INTEGER PRIMARY KEY, title TEXT NOT NULL, activity_type TEXT NOT NULL DEFAULT 'activity', activity_date TEXT,
 location TEXT, participants_count INTEGER, description TEXT, outcomes TEXT, support_details TEXT,
 estimated_cost REAL NOT NULL DEFAULT 0 CHECK(estimated_cost>=0), actual_cost REAL NOT NULL DEFAULT 0 CHECK(actual_cost>=0),
 status TEXT NOT NULL DEFAULT 'planned' CHECK(status IN ('planned','completed','cancelled')),
 created_at TEXT NOT NULL DEFAULT (datetime('now'))
);
CREATE TABLE IF NOT EXISTS association_transactions (
 id INTEGER PRIMARY KEY, transaction_code TEXT UNIQUE, transaction_date TEXT NOT NULL,
 direction TEXT NOT NULL CHECK(direction IN ('income','expense')), category TEXT NOT NULL, description TEXT NOT NULL,
 amount REAL NOT NULL CHECK(amount>0), payment_method TEXT, counterparty TEXT, reference_no TEXT,
 committee_id INTEGER REFERENCES committees(id) ON DELETE SET NULL, entered_by TEXT, notes TEXT,
 created_at TEXT NOT NULL DEFAULT (datetime('now'))
);
CREATE INDEX IF NOT EXISTS idx_assoc_transactions_date ON association_transactions(transaction_date,direction);
CREATE TABLE IF NOT EXISTS association_assets (
 id INTEGER PRIMARY KEY, asset_code TEXT UNIQUE, name TEXT NOT NULL, category TEXT NOT NULL,
 quantity REAL NOT NULL DEFAULT 1 CHECK(quantity>=0), unit TEXT NOT NULL DEFAULT 'قطعة', condition_status TEXT NOT NULL DEFAULT 'good' CHECK(condition_status IN ('new','good','needs_repair','damaged','disposed')),
 acquisition_date TEXT, acquisition_cost REAL NOT NULL DEFAULT 0 CHECK(acquisition_cost>=0), location TEXT,
 custodian TEXT, serial_number TEXT, last_inventory_date TEXT, notes TEXT, status TEXT NOT NULL DEFAULT 'active' CHECK(status IN ('active','loaned','disposed','archived')),
 created_at TEXT NOT NULL DEFAULT (datetime('now'))
);
CREATE TABLE IF NOT EXISTS association_documents (
 id INTEGER PRIMARY KEY, title TEXT NOT NULL, document_type TEXT NOT NULL, document_date TEXT,
 reference_no TEXT, file_name TEXT, relative_path TEXT, summary TEXT, related_entity TEXT, related_id INTEGER,
 created_at TEXT NOT NULL DEFAULT (datetime('now'))
);
CREATE TABLE IF NOT EXISTS student_awards (
 id INTEGER PRIMARY KEY, student_id INTEGER NOT NULL REFERENCES students(id) ON DELETE RESTRICT,
 award_title TEXT NOT NULL, award_date TEXT NOT NULL, award_type TEXT NOT NULL DEFAULT 'excellence',
 rank_text TEXT, reason TEXT, value_text TEXT, presented_by TEXT, notes TEXT,
 created_at TEXT NOT NULL DEFAULT (datetime('now'))
);
CREATE TABLE IF NOT EXISTS seating_plans (
 id INTEGER PRIMARY KEY, group_id INTEGER NOT NULL REFERENCES groups(id) ON DELETE RESTRICT,
 plan_name TEXT NOT NULL, seating_json TEXT NOT NULL, created_at TEXT NOT NULL DEFAULT (datetime('now'))
);
CREATE TABLE IF NOT EXISTS deletion_batches (
 id INTEGER PRIMARY KEY, entity_type TEXT NOT NULL, record_ids TEXT NOT NULL, reason TEXT, created_at TEXT NOT NULL DEFAULT (datetime('now'))
);
CREATE TABLE IF NOT EXISTS association_reports (
 id INTEGER PRIMARY KEY, report_type TEXT NOT NULL CHECK(report_type IN ('literary','financial','activities','annual','general')),
 title TEXT NOT NULL, period_start TEXT, period_end TEXT, summary TEXT, body TEXT NOT NULL,
 prepared_by TEXT, approved_by TEXT, status TEXT NOT NULL DEFAULT 'draft' CHECK(status IN ('draft','review','approved','archived')),
 created_at TEXT NOT NULL DEFAULT (datetime('now'))
);
CREATE TABLE IF NOT EXISTS association_asset_events (
 id INTEGER PRIMARY KEY, asset_id INTEGER NOT NULL REFERENCES association_assets(id) ON DELETE RESTRICT,
 event_date TEXT NOT NULL, event_type TEXT NOT NULL CHECK(event_type IN ('inventory','maintenance','loan','return','transfer','disposal','purchase')),
 quantity REAL NOT NULL DEFAULT 0 CHECK(quantity>=0), details TEXT, handled_by TEXT, cost REAL NOT NULL DEFAULT 0 CHECK(cost>=0),
 created_at TEXT NOT NULL DEFAULT (datetime('now'))
);
CREATE INDEX IF NOT EXISTS idx_asset_events_asset_date ON association_asset_events(asset_id,event_date);
