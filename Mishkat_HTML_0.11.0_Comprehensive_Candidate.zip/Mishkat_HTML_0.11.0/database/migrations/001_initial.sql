PRAGMA foreign_keys = ON;

CREATE TABLE IF NOT EXISTS institution (
    id INTEGER PRIMARY KEY CHECK (id = 1),
    official_name TEXT NOT NULL,
    branch_name TEXT NOT NULL,
    supervisor_name TEXT NOT NULL,
    address TEXT,
    phone TEXT,
    logo_relative_path TEXT,
    created_at TEXT NOT NULL DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS users (
    id INTEGER PRIMARY KEY,
    username TEXT NOT NULL UNIQUE COLLATE NOCASE,
    password_hash TEXT,
    display_name TEXT NOT NULL,
    role TEXT NOT NULL CHECK (role IN ('admin', 'teacher', 'registrar', 'viewer')),
    is_active INTEGER NOT NULL DEFAULT 1 CHECK (is_active IN (0, 1)),
    created_at TEXT NOT NULL DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS families (
    id INTEGER PRIMARY KEY,
    family_code TEXT NOT NULL UNIQUE,
    father_first_name TEXT,
    father_last_name TEXT,
    father_phone TEXT,
    mother_first_name TEXT,
    mother_last_name TEXT,
    mother_phone TEXT,
    address TEXT,
    created_at TEXT NOT NULL DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS students (
    id INTEGER PRIMARY KEY,
    student_code TEXT NOT NULL UNIQUE,
    first_name TEXT NOT NULL,
    last_name TEXT NOT NULL,
    birth_date TEXT,
    gender TEXT NOT NULL CHECK (gender IN ('male', 'female')),
    family_id INTEGER REFERENCES families(id) ON UPDATE CASCADE ON DELETE SET NULL,
    photo_relative_path TEXT,
    student_category TEXT NOT NULL DEFAULT 'child'
        CHECK (student_category IN ('child', 'adult')),
    status TEXT NOT NULL DEFAULT 'active'
        CHECK (status IN ('active', 'paused', 'withdrawn', 'completed', 'archived')),
    notes TEXT,
    created_at TEXT NOT NULL DEFAULT (datetime('now')),
    updated_at TEXT NOT NULL DEFAULT (datetime('now')),
    CHECK (birth_date IS NULL OR (
        length(birth_date) = 10 AND
        birth_date GLOB '[0-9][0-9][0-9][0-9]-[0-9][0-9]-[0-9][0-9]'
    ))
);

CREATE INDEX IF NOT EXISTS idx_students_name ON students(last_name, first_name);
CREATE INDEX IF NOT EXISTS idx_students_family ON students(family_id);
CREATE INDEX IF NOT EXISTS idx_students_status ON students(status);

CREATE TABLE IF NOT EXISTS student_guardians (
    id INTEGER PRIMARY KEY,
    student_id INTEGER NOT NULL REFERENCES students(id) ON DELETE CASCADE,
    family_id INTEGER NOT NULL REFERENCES families(id) ON DELETE CASCADE,
    relationship TEXT NOT NULL CHECK (relationship IN ('father', 'mother', 'guardian', 'other')),
    is_primary_contact INTEGER NOT NULL DEFAULT 0 CHECK (is_primary_contact IN (0, 1)),
    created_at TEXT NOT NULL DEFAULT (datetime('now')),
    UNIQUE(student_id, family_id, relationship)
);

CREATE TABLE IF NOT EXISTS teachers (
    id INTEGER PRIMARY KEY,
    teacher_code TEXT NOT NULL UNIQUE,
    first_name TEXT NOT NULL,
    last_name TEXT NOT NULL,
    phone TEXT,
    specialty TEXT,
    is_active INTEGER NOT NULL DEFAULT 1 CHECK (is_active IN (0, 1)),
    notes TEXT,
    created_at TEXT NOT NULL DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS levels (
    id INTEGER PRIMARY KEY,
    name TEXT NOT NULL UNIQUE,
    description TEXT,
    min_age INTEGER CHECK (min_age IS NULL OR min_age >= 0),
    max_age INTEGER CHECK (max_age IS NULL OR max_age >= 0),
    is_active INTEGER NOT NULL DEFAULT 1 CHECK (is_active IN (0, 1)),
    CHECK (min_age IS NULL OR max_age IS NULL OR min_age <= max_age)
);

CREATE TABLE IF NOT EXISTS groups (
    id INTEGER PRIMARY KEY,
    group_code TEXT NOT NULL UNIQUE,
    name TEXT NOT NULL,
    level_id INTEGER REFERENCES levels(id) ON DELETE SET NULL,
    teacher_id INTEGER REFERENCES teachers(id) ON DELETE SET NULL,
    target_gender TEXT NOT NULL DEFAULT 'mixed'
        CHECK (target_gender IN ('male', 'female', 'mixed')),
    min_age INTEGER CHECK (min_age IS NULL OR min_age >= 0),
    max_age INTEGER CHECK (max_age IS NULL OR max_age >= 0),
    schedule_text TEXT,
    is_active INTEGER NOT NULL DEFAULT 1 CHECK (is_active IN (0, 1)),
    CHECK (min_age IS NULL OR max_age IS NULL OR min_age <= max_age)
);

CREATE TABLE IF NOT EXISTS academic_periods (
    id INTEGER PRIMARY KEY,
    name TEXT NOT NULL UNIQUE,
    start_date TEXT NOT NULL,
    end_date TEXT,
    is_active INTEGER NOT NULL DEFAULT 1 CHECK (is_active IN (0, 1)),
    CHECK (end_date IS NULL OR end_date >= start_date)
);

CREATE TABLE IF NOT EXISTS enrollments (
    id INTEGER PRIMARY KEY,
    student_id INTEGER NOT NULL REFERENCES students(id) ON DELETE RESTRICT,
    group_id INTEGER NOT NULL REFERENCES groups(id) ON DELETE RESTRICT,
    academic_period_id INTEGER REFERENCES academic_periods(id) ON DELETE SET NULL,
    start_date TEXT NOT NULL,
    end_date TEXT,
    status TEXT NOT NULL DEFAULT 'active'
        CHECK (status IN ('active', 'transferred', 'completed', 'withdrawn')),
    notes TEXT,
    CHECK (end_date IS NULL OR end_date >= start_date)
);

CREATE UNIQUE INDEX IF NOT EXISTS uq_active_enrollment_per_student_group
ON enrollments(student_id, group_id, academic_period_id)
WHERE status = 'active';

CREATE TABLE IF NOT EXISTS attendance_sessions (
    id INTEGER PRIMARY KEY,
    group_id INTEGER NOT NULL REFERENCES groups(id) ON DELETE RESTRICT,
    teacher_id INTEGER REFERENCES teachers(id) ON DELETE SET NULL,
    session_date TEXT NOT NULL,
    session_label TEXT,
    is_closed INTEGER NOT NULL DEFAULT 0 CHECK (is_closed IN (0, 1)),
    notes TEXT,
    created_at TEXT NOT NULL DEFAULT (datetime('now')),
    CHECK (length(session_date) = 10 AND
        session_date GLOB '[0-9][0-9][0-9][0-9]-[0-9][0-9]-[0-9][0-9]')
);

CREATE INDEX IF NOT EXISTS idx_attendance_sessions_date
ON attendance_sessions(session_date, group_id);

CREATE TABLE IF NOT EXISTS attendance_records (
    id INTEGER PRIMARY KEY,
    session_id INTEGER NOT NULL REFERENCES attendance_sessions(id) ON DELETE CASCADE,
    student_id INTEGER NOT NULL REFERENCES students(id) ON DELETE RESTRICT,
    status TEXT NOT NULL CHECK (status IN ('present', 'absent', 'excused', 'late', 'left_early')),
    reason TEXT,
    notes TEXT,
    marked_by INTEGER REFERENCES users(id) ON DELETE SET NULL,
    created_at TEXT NOT NULL DEFAULT (datetime('now')),
    updated_at TEXT NOT NULL DEFAULT (datetime('now')),
    UNIQUE(session_id, student_id)
);

CREATE INDEX IF NOT EXISTS idx_attendance_records_student
ON attendance_records(student_id, session_id);

CREATE TABLE IF NOT EXISTS quran_surahs (
    surah_number INTEGER PRIMARY KEY CHECK (surah_number BETWEEN 1 AND 114),
    arabic_name TEXT NOT NULL,
    ayah_count INTEGER NOT NULL CHECK (ayah_count > 0),
    revelation_order INTEGER
);

CREATE TABLE IF NOT EXISTS quran_ayahs (
    surah_number INTEGER NOT NULL REFERENCES quran_surahs(surah_number) ON DELETE RESTRICT,
    ayah_number INTEGER NOT NULL CHECK (ayah_number > 0),
    juz_number INTEGER NOT NULL CHECK (juz_number BETWEEN 1 AND 30),
    hizb_number INTEGER NOT NULL CHECK (hizb_number BETWEEN 1 AND 60),
    rub_number INTEGER CHECK (rub_number IS NULL OR rub_number BETWEEN 1 AND 240),
    global_ayah_number INTEGER UNIQUE CHECK (global_ayah_number IS NULL OR global_ayah_number BETWEEN 1 AND 6236),
    PRIMARY KEY (surah_number, ayah_number)
);

CREATE TABLE IF NOT EXISTS memorization_sessions (
    id INTEGER PRIMARY KEY,
    student_id INTEGER NOT NULL REFERENCES students(id) ON DELETE RESTRICT,
    teacher_id INTEGER REFERENCES teachers(id) ON DELETE SET NULL,
    group_id INTEGER REFERENCES groups(id) ON DELETE SET NULL,
    session_date TEXT NOT NULL,
    notes TEXT,
    created_at TEXT NOT NULL DEFAULT (datetime('now')),
    CHECK (length(session_date) = 10 AND
        session_date GLOB '[0-9][0-9][0-9][0-9]-[0-9][0-9]-[0-9][0-9]')
);

CREATE TABLE IF NOT EXISTS scoring_rules (
    id INTEGER PRIMARY KEY,
    name TEXT NOT NULL,
    level_id INTEGER REFERENCES levels(id) ON DELETE CASCADE,
    work_type TEXT NOT NULL CHECK (work_type IN ('new_memorization', 'recent_revision', 'cumulative_revision', 'test')),
    min_score REAL NOT NULL DEFAULT 0,
    max_score REAL NOT NULL DEFAULT 10,
    default_points REAL NOT NULL DEFAULT 0,
    is_active INTEGER NOT NULL DEFAULT 1 CHECK (is_active IN (0, 1)),
    created_at TEXT NOT NULL DEFAULT (datetime('now')),
    CHECK (min_score <= max_score),
    CHECK (default_points >= 0)
);

CREATE TABLE IF NOT EXISTS memorization_entries (
    id INTEGER PRIMARY KEY,
    session_id INTEGER NOT NULL REFERENCES memorization_sessions(id) ON DELETE CASCADE,
    work_type TEXT NOT NULL CHECK (work_type IN ('new_memorization', 'recent_revision', 'cumulative_revision', 'test')),
    start_surah INTEGER NOT NULL,
    start_ayah INTEGER NOT NULL,
    end_surah INTEGER NOT NULL,
    end_ayah INTEGER NOT NULL,
    status TEXT NOT NULL DEFAULT 'pending'
        CHECK (status IN ('pending', 'in_progress', 'completed', 'deferred', 'retry_required', 'approved')),
    score REAL,
    points REAL NOT NULL DEFAULT 0 CHECK (points >= 0),
    notes TEXT,
    scoring_rule_id INTEGER REFERENCES scoring_rules(id) ON DELETE SET NULL,
    created_at TEXT NOT NULL DEFAULT (datetime('now')),
    FOREIGN KEY (start_surah, start_ayah)
        REFERENCES quran_ayahs(surah_number, ayah_number) DEFERRABLE INITIALLY DEFERRED,
    FOREIGN KEY (end_surah, end_ayah)
        REFERENCES quran_ayahs(surah_number, ayah_number) DEFERRABLE INITIALLY DEFERRED,
    CHECK (end_surah > start_surah OR
        (end_surah = start_surah AND end_ayah >= start_ayah)),
    CHECK (score IS NULL OR score >= 0)
);

CREATE INDEX IF NOT EXISTS idx_memorization_sessions_student_date
ON memorization_sessions(student_id, session_date);

CREATE INDEX IF NOT EXISTS idx_memorization_entries_session
ON memorization_entries(session_id, work_type, status);

CREATE TABLE IF NOT EXISTS memorization_assessments (
    id INTEGER PRIMARY KEY,
    entry_id INTEGER NOT NULL UNIQUE REFERENCES memorization_entries(id) ON DELETE CASCADE,
    score REAL NOT NULL CHECK (score >= 0),
    mistake_count INTEGER NOT NULL DEFAULT 0 CHECK (mistake_count >= 0),
    assessment_label TEXT,
    decision TEXT NOT NULL CHECK (decision IN ('accepted', 'retry', 'deferred')),
    assessed_by INTEGER REFERENCES users(id) ON DELETE SET NULL,
    assessed_at TEXT NOT NULL DEFAULT (datetime('now')),
    notes TEXT
);

CREATE TABLE IF NOT EXISTS audit_log (
    id INTEGER PRIMARY KEY,
    user_id INTEGER REFERENCES users(id) ON DELETE SET NULL,
    action TEXT NOT NULL,
    entity_type TEXT NOT NULL,
    entity_id TEXT,
    details TEXT,
    occurred_at TEXT NOT NULL DEFAULT (datetime('now'))
);

CREATE INDEX IF NOT EXISTS idx_audit_log_time ON audit_log(occurred_at);

CREATE TABLE IF NOT EXISTS backup_history (
    id INTEGER PRIMARY KEY,
    destination_type TEXT NOT NULL CHECK (destination_type IN ('local', 'usb', 'external_drive')),
    destination_path TEXT NOT NULL,
    created_at TEXT NOT NULL DEFAULT (datetime('now')),
    size_bytes INTEGER CHECK (size_bytes IS NULL OR size_bytes >= 0),
    result TEXT NOT NULL CHECK (result IN ('started', 'success', 'failed', 'verified')),
    details TEXT
);
