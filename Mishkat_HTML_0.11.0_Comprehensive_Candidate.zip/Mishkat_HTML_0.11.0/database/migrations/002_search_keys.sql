ALTER TABLE students ADD COLUMN search_key TEXT NOT NULL DEFAULT '';
ALTER TABLE families ADD COLUMN search_key TEXT NOT NULL DEFAULT '';
CREATE INDEX IF NOT EXISTS idx_students_search_key ON students(search_key);
CREATE INDEX IF NOT EXISTS idx_families_search_key ON families(search_key);
