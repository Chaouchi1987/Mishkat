-- W5: verified surah/ayah counts and recitation records. No Quran verse text is stored.
CREATE TABLE IF NOT EXISTS quran_learning_sessions (
    id INTEGER PRIMARY KEY,
    student_id INTEGER NOT NULL REFERENCES students(id) ON DELETE RESTRICT,
    teacher_id INTEGER REFERENCES teachers(id) ON DELETE SET NULL,
    group_id INTEGER REFERENCES groups(id) ON DELETE SET NULL,
    session_date TEXT NOT NULL CHECK (length(session_date)=10 AND session_date GLOB '[0-9][0-9][0-9][0-9]-[0-9][0-9]-[0-9][0-9]'),
    notes TEXT,
    created_at TEXT NOT NULL DEFAULT (datetime('now')),
    UNIQUE(student_id, session_date)
);
CREATE TABLE IF NOT EXISTS quran_learning_entries (
    id INTEGER PRIMARY KEY,
    session_id INTEGER NOT NULL REFERENCES quran_learning_sessions(id) ON DELETE CASCADE,
    work_type TEXT NOT NULL CHECK (work_type IN ('new_memorization','recent_revision','cumulative_revision')),
    start_surah INTEGER NOT NULL REFERENCES quran_surahs(surah_number) ON DELETE RESTRICT,
    start_ayah INTEGER NOT NULL CHECK (start_ayah > 0),
    end_surah INTEGER NOT NULL REFERENCES quran_surahs(surah_number) ON DELETE RESTRICT,
    end_ayah INTEGER NOT NULL CHECK (end_ayah > 0),
    score REAL NOT NULL CHECK (score >= 0 AND score <= 10),
    mistake_count INTEGER NOT NULL DEFAULT 0 CHECK (mistake_count >= 0),
    decision TEXT NOT NULL CHECK (decision IN ('accepted','retry','deferred')),
    notes TEXT,
    created_at TEXT NOT NULL DEFAULT (datetime('now')),
    CHECK (end_surah > start_surah OR (end_surah = start_surah AND end_ayah >= start_ayah))
);
CREATE INDEX IF NOT EXISTS idx_quran_learning_student_date ON quran_learning_sessions(student_id, session_date);
CREATE INDEX IF NOT EXISTS idx_quran_learning_entry_session ON quran_learning_entries(session_id, work_type);
