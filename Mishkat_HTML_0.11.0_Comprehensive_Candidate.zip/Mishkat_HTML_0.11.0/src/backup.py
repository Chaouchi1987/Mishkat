"""Verified SQLite backup/restore helpers with explicit destination classification."""
from pathlib import Path
import sqlite3
from contextlib import closing

from .db import connect


class BackupError(RuntimeError):
    pass


def _check_database(path):
    path = Path(path).expanduser().resolve()
    if not path.is_file():
        raise BackupError("ملف قاعدة البيانات غير موجود.")
    try:
        with closing(sqlite3.connect(str(path))) as con:
            integrity = con.execute("PRAGMA integrity_check").fetchone()[0]
            foreign_keys = con.execute("PRAGMA foreign_key_check").fetchall()
            if integrity != "ok" or foreign_keys:
                raise BackupError("قاعدة البيانات غير سليمة أو تحتوي على مراجع غير صحيحة.")
    except sqlite3.DatabaseError as exc:
        raise BackupError("تعذر قراءة قاعدة البيانات أو أنها تالفة.") from exc
    return path


def _log_history(db_path, destination_type, destination_path, result, details, size_bytes=None):
    try:
        with connect(db_path) as con:
            exists = con.execute("SELECT 1 FROM sqlite_master WHERE type='table' AND name='backup_history'").fetchone()
            if not exists:
                return False
            con.execute("""INSERT INTO backup_history(destination_type, destination_path, size_bytes, result, details)
                VALUES (?, ?, ?, ?, ?)""", (destination_type, str(destination_path), size_bytes, result, details))
            return True
    except (sqlite3.DatabaseError, OSError):
        # History logging must not invalidate a verified backup or hide restore failure.
        return False


def create_backup(db_path, destination_path, destination_type="local"):
    source_path = Path(db_path).expanduser().resolve()
    destination = Path(destination_path).expanduser().resolve()
    if destination_type not in ("local", "usb", "external_drive"):
        raise BackupError("نوع وجهة النسخ الاحتياطي غير صحيح.")
    if source_path == destination:
        raise BackupError("لا يمكن أن يكون مسار النسخة الاحتياطية هو ملف البيانات الأصلي.")
    if not source_path.is_file():
        raise BackupError("ملف قاعدة البيانات الأصلي غير موجود.")
    if destination.exists():
        raise BackupError("ملف النسخة الاحتياطية موجود مسبقًا؛ اختر اسمًا آخر لتجنب استبداله.")
    try:
        destination.parent.mkdir(parents=True, exist_ok=True)
        with closing(sqlite3.connect(str(source_path))) as source, closing(sqlite3.connect(str(destination))) as target:
            source.backup(target)
        _check_database(destination)
        size = destination.stat().st_size
        _log_history(source_path, destination_type, destination, "verified", "اجتازت النسخة integrity_check وforeign_key_check.", size)
        return destination
    except Exception as exc:
        try:
            destination.unlink(missing_ok=True)
        except OSError:
            pass
        _log_history(source_path, destination_type, destination, "failed", "فشل إنشاء النسخة أو التحقق منها.")
        if isinstance(exc, BackupError):
            raise
        raise BackupError("فشل إنشاء النسخة الاحتياطية أو التحقق منها.") from exc


def verify_backup(backup_path):
    path = _check_database(backup_path)
    try:
        with closing(sqlite3.connect(str(path))) as con:
            tables = con.execute("SELECT COUNT(*) FROM sqlite_master WHERE type='table'").fetchone()[0]
            required = {row[0] for row in con.execute("SELECT name FROM sqlite_master WHERE type='table'")}
            if not {"students", "families", "institution"}.issubset(required):
                raise BackupError("الملف سليم كـSQLite لكنه لا يحتوي مخطط مدرسة مِشكاة المتوقع.")
            students = con.execute("SELECT COUNT(*) FROM students").fetchone()[0]
    except sqlite3.DatabaseError as exc:
        raise BackupError("الملف لا يبدو نسخة صالحة من قاعدة بيانات المدرسة.") from exc
    return {"path": str(path), "size_bytes": path.stat().st_size,
            "table_count": tables, "student_count": students, "verified": True}


def restore_backup(db_path, backup_path, safety_backup_path, destination_type="local"):
    current = Path(db_path).expanduser().resolve()
    backup = Path(backup_path).expanduser().resolve()
    safety = Path(safety_backup_path).expanduser().resolve()
    if backup == current or safety in (current, backup):
        _log_history(current, destination_type, backup, "failed", "رُفضت الاستعادة لأن مسارات الملفات تتعارض.")
        raise BackupError("يجب أن تكون قاعدة البيانات والنسخة الاحتياطية ونسخة الأمان ثلاثة ملفات مختلفة.")
    try:
        backup = _check_database(backup)
        verify_backup(backup)
    except Exception as exc:
        _log_history(current, destination_type, backup, "failed", "رُفضت الاستعادة لأن النسخة غير صالحة.")
        if isinstance(exc, BackupError):
            raise
        raise BackupError("تعذر التحقق من النسخة المراد استعادتها.") from exc
    try:
        if current.exists():
            create_backup(current, safety, destination_type=destination_type)
        else:
            current.parent.mkdir(parents=True, exist_ok=True)
        with closing(sqlite3.connect(str(backup))) as source, closing(sqlite3.connect(str(current))) as target:
            source.backup(target)
        _check_database(current)
        verify_backup(current)
    except Exception as exc:
        _log_history(current, destination_type, backup, "failed", "فشلت الاستعادة؛ لم تُحذف نسخة الأمان إن وُجدت.")
        if isinstance(exc, BackupError):
            raise
        raise BackupError("تعذرت استعادة النسخة؛ احتفظ بنسخة الأمان ولا تحذفها.") from exc
    _log_history(current, destination_type, backup, "success", "تمت الاستعادة والتحقق من سلامة قاعدة البيانات.", backup.stat().st_size)
    return {"restored_from": str(backup), "database": str(current),
            "safety_backup": str(safety) if safety.exists() else None}
