"""SQLite connection, versioned migrations, and database integrity helpers."""
from __future__ import annotations

import argparse
import hashlib
import sqlite3
from pathlib import Path
from typing import List, Union

ROOT = Path(__file__).resolve().parents[1]
MIGRATIONS_DIR = ROOT / "database" / "migrations"


class ClosingConnection(sqlite3.Connection):
    def __exit__(self, exc_type, exc_value, traceback):
        try:
            return super().__exit__(exc_type, exc_value, traceback)
        finally:
            self.close()


def connect(db_path: Union[str, Path]) -> sqlite3.Connection:
    path = Path(db_path).expanduser().resolve()
    path.parent.mkdir(parents=True, exist_ok=True)
    connection = sqlite3.connect(str(path), factory=ClosingConnection)
    connection.row_factory = sqlite3.Row
    connection.execute("PRAGMA foreign_keys = ON")
    connection.execute("PRAGMA busy_timeout = 5000")
    connection.execute("PRAGMA journal_mode = WAL")
    return connection


def default_database_path() -> Path:
    """Return per-user writable storage, outside the installed program directory."""
    import os
    if os.name == "nt":
        base = Path(os.environ.get("LOCALAPPDATA") or Path.home() / "AppData" / "Local")
    else:
        base = Path(os.environ.get("XDG_DATA_HOME") or Path.home() / ".local" / "share")
    return base / "Mishkat" / "data" / "school.sqlite3"


def _migration_files():
    return sorted(MIGRATIONS_DIR.glob("[0-9][0-9][0-9]_*.sql"))


def _table_names(con):
    return {row[0] for row in con.execute("SELECT name FROM sqlite_master WHERE type='table'")}


def _apply_migrations(con):
    files = _migration_files()
    if not files:
        raise RuntimeError("لا توجد ملفات ترحيل قاعدة البيانات.")
    existing_tables = _table_names(con)
    has_migrations = "schema_migrations" in existing_tables
    if not has_migrations:
        con.execute("CREATE TABLE schema_migrations (version INTEGER PRIMARY KEY, applied_at TEXT NOT NULL DEFAULT (datetime('now')), checksum TEXT NOT NULL)")
        # Adopt a pre-migrations database only when its core schema is recognisable.
        if existing_tables:
            required = {"institution", "students", "families", "student_guardians", "backup_history"}
            if not required.issubset(existing_tables):
                raise RuntimeError("قاعدة موجودة ببنية غير معروفة؛ أُوقف الترحيل لحماية البيانات.")
            # Compare existing table columns against the original schema before adopting it.
            expected = sqlite3.connect(":memory:")
            try:
                expected.executescript(files[0].read_text(encoding="utf-8"))
                expected_tables = {r[0] for r in expected.execute("SELECT name FROM sqlite_master WHERE type='table'")}
                for table in expected_tables:
                    if table not in existing_tables:
                        raise RuntimeError("قاعدة موجودة ينقصها الجدول {}؛ أُوقف الترحيل لحماية البيانات.".format(table))
                    expected_cols = [r[1] for r in expected.execute("PRAGMA table_info({})".format(table))]
                    actual_cols = [r[1] for r in con.execute("PRAGMA table_info({})".format(table))]
                    if expected_cols != actual_cols:
                        raise RuntimeError("بنية الجدول {} لا تطابق المخطط الأساسي؛ أُوقف الترحيل دون تغيير بياناته.".format(table))
            finally:
                expected.close()
            first = files[0]
            digest = hashlib.sha256(first.read_bytes()).hexdigest()
            con.execute("INSERT INTO schema_migrations(version, checksum) VALUES (?, ?)", (int(first.name[:3]), digest))
            con.commit()
    applied = {row["version"]: row["checksum"] for row in con.execute("SELECT version, checksum FROM schema_migrations")}
    for file in files:
        version = int(file.name[:3])
        checksum = hashlib.sha256(file.read_bytes()).hexdigest()
        if version in applied:
            if applied[version] != checksum:
                raise RuntimeError("بصمة ترحيل مطبّق تغيّرت: {}. لا يمكن المتابعة تلقائيًا.".format(file.name))
            continue
        # Refuse gaps so migrations are applied in order.
        if applied and version != max(applied) + 1:
            raise RuntimeError("تسلسل ترحيلات قاعدة البيانات غير متصل عند {}.".format(file.name))
        con.commit()
        con.execute("BEGIN IMMEDIATE")
        try:
            # Execute statements individually so DDL remains inside this transaction.
            statement = ""
            for line in file.read_text(encoding="utf-8").splitlines():
                stripped = line.strip()
                if not stripped or stripped.startswith("--"):
                    continue
                statement += line + "\n"
                if sqlite3.complete_statement(statement):
                    con.execute(statement)
                    statement = ""
            if statement.strip():
                con.execute(statement)
            con.execute("INSERT INTO schema_migrations(version, checksum) VALUES (?, ?)", (version, checksum))
            con.commit()
            applied[version] = checksum
        except Exception:
            con.rollback()
            raise


def initialize_database(db_path: Union[str, Path]) -> None:
    with connect(db_path) as con:
        _apply_migrations(con)
        # Fresh installations get institution identity, but supervisor details are configurable.
        con.execute("""INSERT OR IGNORE INTO institution
            (id, official_name, branch_name, supervisor_name)
            VALUES (1, ?, ?, ?)""", ("جمعية العلماء المسلمين الجزائريين", "شعبة بئر مقدم", ""))
        # Seed only canonical surah names and verse counts; no Quran verse text or guessed juz/hizb metadata.
        surahs = [
            (1,"الفاتحة",7),(2,"البقرة",286),(3,"آل عمران",200),(4,"النساء",176),(5,"المائدة",120),(6,"الأنعام",165),(7,"الأعراف",206),(8,"الأنفال",75),(9,"التوبة",129),(10,"يونس",109),(11,"هود",123),(12,"يوسف",111),(13,"الرعد",43),(14,"إبراهيم",52),(15,"الحجر",99),(16,"النحل",128),(17,"الإسراء",111),(18,"الكهف",110),(19,"مريم",98),(20,"طه",135),(21,"الأنبياء",112),(22,"الحج",78),(23,"المؤمنون",118),(24,"النور",64),(25,"الفرقان",77),(26,"الشعراء",227),(27,"النمل",93),(28,"القصص",88),(29,"العنكبوت",69),(30,"الروم",60),(31,"لقمان",34),(32,"السجدة",30),(33,"الأحزاب",73),(34,"سبأ",54),(35,"فاطر",45),(36,"يس",83),(37,"الصافات",182),(38,"ص",88),(39,"الزمر",75),(40,"غافر",85),(41,"فصلت",54),(42,"الشورى",53),(43,"الزخرف",89),(44,"الدخان",59),(45,"الجاثية",37),(46,"الأحقاف",35),(47,"محمد",38),(48,"الفتح",29),(49,"الحجرات",18),(50,"ق",45),(51,"الذاريات",60),(52,"الطور",49),(53,"النجم",62),(54,"القمر",55),(55,"الرحمن",78),(56,"الواقعة",96),(57,"الحديد",29),(58,"المجادلة",22),(59,"الحشر",24),(60,"الممتحنة",13),(61,"الصف",14),(62,"الجمعة",11),(63,"المنافقون",11),(64,"التغابن",18),(65,"الطلاق",12),(66,"التحريم",12),(67,"الملك",30),(68,"القلم",52),(69,"الحاقة",52),(70,"المعارج",44),(71,"نوح",28),(72,"الجن",28),(73,"المزمل",20),(74,"المدثر",56),(75,"القيامة",40),(76,"الإنسان",31),(77,"المرسلات",50),(78,"النبأ",40),(79,"النازعات",46),(80,"عبس",42),(81,"التكوير",29),(82,"الانفطار",19),(83,"المطففين",36),(84,"الانشقاق",25),(85,"البروج",22),(86,"الطارق",17),(87,"الأعلى",19),(88,"الغاشية",26),(89,"الفجر",30),(90,"البلد",20),(91,"الشمس",15),(92,"الليل",21),(93,"الضحى",11),(94,"الشرح",8),(95,"التين",8),(96,"العلق",19),(97,"القدر",5),(98,"البينة",8),(99,"الزلزلة",8),(100,"العاديات",11),(101,"القارعة",11),(102,"التكاثر",8),(103,"العصر",3),(104,"الهمزة",9),(105,"الفيل",5),(106,"قريش",4),(107,"الماعون",7),(108,"الكوثر",3),(109,"الكافرون",6),(110,"النصر",3),(111,"المسد",5),(112,"الإخلاص",4),(113,"الفلق",5),(114,"الناس",6)
        ]
        con.executemany("INSERT OR IGNORE INTO quran_surahs(surah_number,arabic_name,ayah_count) VALUES(?,?,?)", surahs)
        # Backfill search keys after both initial adoption and future student inserts.
        from .registry import normalize_search
        for row in con.execute("SELECT id, first_name, last_name FROM students").fetchall():
            key = normalize_search("{} {}".format(row["first_name"], row["last_name"]))
            con.execute("UPDATE students SET search_key=? WHERE id=?", (key, row["id"]))
        for row in con.execute("SELECT id, father_first_name, father_last_name, mother_first_name, mother_last_name FROM families").fetchall():
            names = " ".join(filter(None, (row["father_first_name"], row["father_last_name"], row["mother_first_name"], row["mother_last_name"])))
            con.execute("UPDATE families SET search_key=? WHERE id=?", (normalize_search(names), row["id"]))


def validate_database(db_path: Union[str, Path]) -> List[str]:
    issues: List[str] = []
    with connect(db_path) as con:
        integrity = con.execute("PRAGMA integrity_check").fetchone()[0]
        if integrity != "ok":
            issues.append("integrity_check: {}".format(integrity))
        foreign_key_errors = con.execute("PRAGMA foreign_key_check").fetchall()
        if foreign_key_errors:
            issues.append("foreign_key_check: {} error(s)".format(len(foreign_key_errors)))
        if con.execute("SELECT 1 FROM institution WHERE id=1").fetchone() is None:
            issues.append("institution seed row is missing")
        if con.execute("SELECT 1 FROM sqlite_master WHERE type='table' AND name='schema_migrations'").fetchone() is None:
            issues.append("schema_migrations table is missing")
    return issues


def main() -> None:
    parser = argparse.ArgumentParser(description="Initialize the local Quran school database.")
    parser.add_argument("--db", required=True, help="Path to the SQLite database file")
    parser.add_argument("--init", action="store_true", help="Initialize or migrate schema")
    parser.add_argument("--check", action="store_true", help="Run SQLite integrity checks")
    args = parser.parse_args()
    if args.init:
        initialize_database(args.db)
        print("Schema initialized: {}".format(Path(args.db).resolve()))
    if args.check:
        issues = validate_database(args.db)
        if issues:
            for issue in issues:
                print("FAIL: {}".format(issue))
            raise SystemExit(1)
        print("Database integrity and foreign-key checks passed.")
    if not args.init and not args.check:
        parser.error("Specify --init and/or --check")


if __name__ == "__main__":
    main()
