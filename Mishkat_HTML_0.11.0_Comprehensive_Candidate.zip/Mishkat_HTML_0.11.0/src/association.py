"""Whitelisted CRUD/report helpers for association administration."""
from __future__ import annotations
from datetime import date

RESOURCES = {
 'members': ('association_members', ['member_code','first_name','last_name','birth_date','phone','email','address','membership_type','role_title','biography','joined_date','status','notes'], ['first_name','last_name']),
 'committees': ('committees', ['name','purpose','manager_member_id','start_date','end_date','status','notes'], ['name']),
 'meetings': ('association_meetings', ['meeting_code','title','meeting_type','meeting_date','start_time','location','chairperson','secretary','agenda','decisions','minutes','attendance_names','status'], ['title','meeting_date']),
 'suggestions': ('association_suggestions', ['title','description','submitted_by','submitted_date','status','decision_notes'], ['title']),
 'annual_plan': ('annual_plan_items', ['title','category','description','planned_start','planned_end','responsible_committee_id','budget_estimate','progress','status','actual_notes'], ['title']),
 'activities': ('association_activities', ['title','activity_type','activity_date','location','participants_count','description','outcomes','support_details','estimated_cost','actual_cost','status'], ['title']),
 'transactions': ('association_transactions', ['transaction_code','transaction_date','direction','category','description','amount','payment_method','counterparty','reference_no','committee_id','entered_by','notes'], ['transaction_date','direction','category','description','amount']),
 'assets': ('association_assets', ['asset_code','name','category','quantity','unit','condition_status','acquisition_date','acquisition_cost','location','custodian','serial_number','last_inventory_date','notes','status'], ['name','category']),
 'documents': ('association_documents', ['title','document_type','document_date','reference_no','file_name','summary','related_entity','related_id'], ['title','document_type']),
 'awards': ('student_awards', ['student_id','award_title','award_date','award_type','rank_text','reason','value_text','presented_by','notes'], ['student_id','award_title','award_date']),
 'seating': ('seating_plans', ['group_id','plan_name','seating_json'], ['group_id','plan_name','seating_json']),
 'committee_links': ('committee_members', ['committee_id','member_id','position','start_date','end_date'], ['committee_id','member_id']),
 'asset_events': ('association_asset_events', ['asset_id','event_date','event_type','quantity','details','handled_by','cost'], ['asset_id','event_date','event_type']),
 'reports': ('association_reports', ['report_type','title','period_start','period_end','summary','body','prepared_by','approved_by','status'], ['report_type','title','body']),
}
NUMERIC = {'manager_member_id','responsible_committee_id','committee_id','participants_count','progress','student_id','group_id','related_id','member_id','asset_id'}
AMOUNT = {'budget_estimate','estimated_cost','actual_cost','amount','acquisition_cost','quantity'}

def normalize_payload(resource, payload):
    if resource not in RESOURCES: raise ValueError('نوع السجل غير معروف.')
    _, fields, required = RESOURCES[resource]
    result={}
    for key in fields:
        value=payload.get(key)
        if isinstance(value,str): value=value.strip()
        if value == '': value=None
        if key in NUMERIC and value is not None:
            try: value=int(value)
            except (TypeError,ValueError): raise ValueError('الحقل '+key+' يجب أن يكون عددًا صحيحًا.')
        if key in AMOUNT and value is not None:
            try: value=float(value)
            except (TypeError,ValueError): raise ValueError('الحقل '+key+' يجب أن يكون رقمًا.')
            if value < 0 or (key=='amount' and value==0): raise ValueError('القيمة المالية أو الكمية غير صالحة.')
        result[key]=value
    defaults={
      'members':{'membership_type':'member','status':'active'}, 'committees':{'status':'active'},
      'meetings':{'meeting_type':'ordinary','status':'planned'}, 'suggestions':{'status':'new'},
      'annual_plan':{'category':'activity','budget_estimate':0,'progress':0,'status':'planned'},
      'activities':{'activity_type':'activity','estimated_cost':0,'actual_cost':0,'status':'planned'},
      'transactions':{}, 'assets':{'quantity':1,'unit':'قطعة','condition_status':'good','acquisition_cost':0,'status':'active'},
      'documents':{}, 'awards':{'award_type':'excellence'}, 'seating':{}, 'committee_links':{}, 'asset_events':{'quantity':0,'cost':0}, 'reports':{'status':'draft'}
    }
    for key,value in defaults.get(resource,{}).items():
        if result.get(key) is None: result[key]=value
    for key in required:
        if result.get(key) is None: raise ValueError('الحقل الإلزامي مفقود: '+key)
    if resource=='transactions' and result.get('direction') not in ('income','expense'): raise ValueError('نوع الحركة المالية يجب أن يكون دخلًا أو مصروفًا.')
    if resource=='reports' and result.get('report_type') not in ('literary','financial','activities','annual','general'): raise ValueError('نوع التقرير غير صحيح.')
    if resource=='asset_events' and result.get('event_type') not in ('inventory','maintenance','loan','return','transfer','disposal','purchase'): raise ValueError('نوع حركة العتاد غير صحيح.')
    if resource=='meetings' and result.get('status') not in (None,'planned','held','cancelled'): raise ValueError('حالة الاجتماع غير صحيحة.')
    return result

def reports(con):
    def one(sql, args=()): return con.execute(sql,args).fetchone()[0]
    this_year=str(date.today().year)
    income=one("SELECT COALESCE(SUM(amount),0) FROM association_transactions WHERE direction='income'")
    expenses=one("SELECT COALESCE(SUM(amount),0) FROM association_transactions WHERE direction='expense'")
    return {
      'students': one("SELECT COUNT(*) FROM students WHERE status='active'"),
      'families': one("SELECT COUNT(*) FROM families WHERE status='active'"),
      'teachers': one("SELECT COUNT(*) FROM teachers WHERE is_active=1"),
      'members': one("SELECT COUNT(*) FROM association_members WHERE status='active'"),
      'meetings_this_year': one("SELECT COUNT(*) FROM association_meetings WHERE substr(meeting_date,1,4)=?",(this_year,)),
      'planned_activities': one("SELECT COUNT(*) FROM association_activities WHERE status='planned'"),
      'assets_active': one("SELECT COUNT(*) FROM association_assets WHERE status='active'"),
      'income': income, 'expenses': expenses, 'balance': income-expenses,
      'income_by_category': [dict(r) for r in con.execute("SELECT category,SUM(amount) amount FROM association_transactions WHERE direction='income' GROUP BY category ORDER BY category")],
      'expenses_by_category': [dict(r) for r in con.execute("SELECT category,SUM(amount) amount FROM association_transactions WHERE direction='expense' GROUP BY category ORDER BY category")],
      'annual_plan': [dict(r) for r in con.execute("SELECT id,title,category,planned_start,planned_end,progress,status,budget_estimate FROM annual_plan_items ORDER BY planned_start,id")],
    }
