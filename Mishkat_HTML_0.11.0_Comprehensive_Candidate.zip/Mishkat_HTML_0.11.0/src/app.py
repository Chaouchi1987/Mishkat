"""Arabic desktop UI for Quran school student registration (Tkinter)."""
import os
import sys
import tkinter as tk
from tkinter import ttk, messagebox
from pathlib import Path

from .db import initialize_database, default_database_path
from .registry import RegistryError, DuplicateStudentWarning, list_families, register_student, search_students, get_student, update_student, archive_student, update_family, archive_family
from .backup import create_backup, verify_backup, restore_backup, BackupError

APP_NAME = "نظام تسيير المدرسة القرآنية"


def data_directory():
    """Use a per-user data folder, never the program installation directory by default."""
    path = default_database_path().parent
    path.mkdir(parents=True, exist_ok=True)
    return path


class QuranSchoolApp(tk.Tk):
    def __init__(self, db_path):
        super().__init__()
        self.db_path = str(db_path)
        self.title(APP_NAME)
        self.geometry("1180x760")
        self.minsize(940, 640)
        self.configure(bg="#f4f6f8")
        self.option_add("*Font", ("Tahoma", 10))
        self._build_ui()
        self.refresh_families()
        self.refresh_students()

    def _build_ui(self):
        style = ttk.Style(self)
        try:
            style.theme_use("clam")
        except tk.TclError:
            pass
        style.configure("Header.TLabel", font=("Tahoma", 16, "bold"), foreground="#173c32")
        style.configure("Section.TLabelframe.Label", font=("Tahoma", 11, "bold"))
        header = tk.Frame(self, bg="#173c32", padx=18, pady=14)
        header.pack(fill="x")
        tk.Label(header, text=APP_NAME, bg="#173c32", fg="white",
                 font=("Tahoma", 17, "bold"), anchor="e").pack(fill="x")
        tk.Label(header, text="جمعية العلماء المسلمين الجزائريين — شعبة بئر مقدم",
                 bg="#173c32", fg="#e1eee8", font=("Tahoma", 10), anchor="e").pack(fill="x", pady=(5, 0))

        self.tabs = ttk.Notebook(self)
        self.tabs.pack(fill="both", expand=True, padx=12, pady=12)
        self.register_tab = ttk.Frame(self.tabs, padding=12)
        self.directory_tab = ttk.Frame(self.tabs, padding=12)
        self.tabs.add(self.register_tab, text="تسجيل طالب / طالبة")
        self.tabs.add(self.directory_tab, text="قائمة الطلبة والبحث")
        self._build_registration_tab()
        self._build_directory_tab()
        self.status_var = tk.StringVar(value="البيانات محفوظة محليًا على هذا الحاسوب.")
        ttk.Label(self, textvariable=self.status_var, anchor="e", padding=(12, 6)).pack(fill="x")
        tools = ttk.Frame(self)
        tools.pack(fill="x", padx=12, pady=(0, 8))
        ttk.Button(tools, text="نسخة احتياطية", command=self.make_backup).pack(side="right", padx=4)
        ttk.Button(tools, text="فحص نسخة", command=self.check_backup).pack(side="right", padx=4)
        ttk.Button(tools, text="استعادة نسخة", command=self.restore_backup).pack(side="right", padx=4)

    def _build_registration_tab(self):
        tab = self.register_tab
        tab.columnconfigure(0, weight=1)
        tab.columnconfigure(1, weight=1)
        student_box = ttk.LabelFrame(tab, text="بيانات الطالب أو الطالبة", padding=12, style="Section.TLabelframe")
        student_box.grid(row=0, column=0, sticky="nsew", padx=(0, 6), pady=4)
        family_box = ttk.LabelFrame(tab, text="بيانات الأسرة / ولي الأمر", padding=12, style="Section.TLabelframe")
        family_box.grid(row=0, column=1, sticky="nsew", padx=(6, 0), pady=4)
        self.fields = {}
        self._entry(student_box, "first_name", "الاسم *", 0)
        self._entry(student_box, "last_name", "اللقب *", 1)
        self._entry(student_box, "birth_date", "تاريخ الميلاد (YYYY-MM-DD)", 2)
        ttk.Label(student_box, text="الجنس *", anchor="e").grid(row=3, column=0, sticky="ew", pady=5)
        self.fields["gender"] = tk.StringVar(value="male")
        gender_frame = ttk.Frame(student_box)
        gender_frame.grid(row=3, column=1, sticky="ew", pady=5)
        ttk.Radiobutton(gender_frame, text="ذكر", variable=self.fields["gender"], value="male").pack(side="right", padx=5)
        ttk.Radiobutton(gender_frame, text="أنثى", variable=self.fields["gender"], value="female").pack(side="right", padx=5)
        ttk.Label(student_box, text="الفئة", anchor="e").grid(row=4, column=0, sticky="ew", pady=5)
        self.fields["student_category"] = tk.StringVar(value="child")
        ttk.Combobox(student_box, textvariable=self.fields["student_category"], state="readonly",
                     values=("child", "adult"), justify="right").grid(row=4, column=1, sticky="ew", pady=5)
        ttk.Label(student_box, text="الحالة", anchor="e").grid(row=5, column=0, sticky="ew", pady=5)
        self.fields["status"] = tk.StringVar(value="active")
        ttk.Combobox(student_box, textvariable=self.fields["status"], state="readonly",
                     values=("active", "paused", "withdrawn", "completed", "archived"),
                     justify="right").grid(row=5, column=1, sticky="ew", pady=5)
        self._entry(student_box, "notes", "ملاحظات", 6)

        self._entry(family_box, "father_first_name", "اسم الأب", 0)
        self._entry(family_box, "father_last_name", "لقب الأب", 1)
        self._entry(family_box, "father_phone", "هاتف الأب", 2)
        self._entry(family_box, "mother_first_name", "اسم الأم", 3)
        self._entry(family_box, "mother_last_name", "لقب الأم", 4)
        self._entry(family_box, "mother_phone", "هاتف الأم", 5)
        self._entry(family_box, "address", "العنوان", 6)
        ttk.Label(family_box, text="أو اربط الطالب بأسرة مسجلة مسبقًا", anchor="e").grid(row=7, column=0, columnspan=2, sticky="ew", pady=(12, 4))
        self.family_choice = tk.StringVar(value="أسرة جديدة / دون ربط")
        self.family_combo = ttk.Combobox(family_box, textvariable=self.family_choice, state="readonly", justify="right")
        self.family_combo.grid(row=8, column=0, columnspan=2, sticky="ew", pady=4)
        ttk.Button(family_box, text="تعديل / أرشفة الأسرة المحددة", command=self.edit_selected_family).grid(row=9, column=0, columnspan=2, sticky="ew", pady=5)
        student_box.columnconfigure(1, weight=1)
        family_box.columnconfigure(1, weight=1)

        buttons = ttk.Frame(tab)
        buttons.grid(row=1, column=0, columnspan=2, sticky="ew", pady=12)
        ttk.Button(buttons, text="حفظ التسجيل", command=self.save_student).pack(side="right", padx=4)
        ttk.Button(buttons, text="تفريغ الحقول", command=self.clear_form).pack(side="right", padx=4)
        ttk.Label(tab, text="* الحقول الإلزامية. يمكن تسجيل النساء البالغات دون بيانات أسرة أو ولي أمر.",
                  foreground="#4d5c57", anchor="e").grid(row=2, column=0, columnspan=2, sticky="ew")

    def _entry(self, parent, key, label, row):
        ttk.Label(parent, text=label, anchor="e").grid(row=row, column=0, sticky="ew", padx=(0, 8), pady=5)
        var = tk.StringVar()
        self.fields[key] = var
        ttk.Entry(parent, textvariable=var, justify="right").grid(row=row, column=1, sticky="ew", pady=5)

    def _build_directory_tab(self):
        tab = self.directory_tab
        top = ttk.Frame(tab)
        top.pack(fill="x", pady=(0, 10))
        self.search_var = tk.StringVar()
        ttk.Label(top, text="بحث بالاسم أو اللقب أو الرقم أو الهاتف:").pack(side="right", padx=6)
        entry = ttk.Entry(top, textvariable=self.search_var, justify="right", width=34)
        entry.pack(side="right", padx=6)
        entry.bind("<Return>", lambda _event: self.refresh_students())
        ttk.Button(top, text="بحث", command=self.refresh_students).pack(side="right", padx=4)
        ttk.Button(top, text="عرض الكل", command=self.show_all_students).pack(side="right", padx=4)
        ttk.Button(top, text="تعديل المحدد", command=self.edit_selected_student).pack(side="left", padx=4)
        ttk.Button(top, text="أرشفة المحدد", command=self.archive_selected_student).pack(side="left", padx=4)
        columns = ("code", "name", "gender", "category", "family", "phone", "status")
        self.tree = ttk.Treeview(tab, columns=columns, show="headings", height=20)
        headings = {"code": "رقم الطالب", "name": "الاسم واللقب", "gender": "الجنس",
                    "category": "الفئة", "family": "رقم الأسرة", "phone": "الهاتف", "status": "الحالة"}
        widths = {"code": 130, "name": 210, "gender": 70, "category": 80, "family": 110, "phone": 130, "status": 90}
        for col in columns:
            self.tree.heading(col, text=headings[col], anchor="center")
            self.tree.column(col, width=widths[col], anchor="center")
        self.tree.pack(fill="both", expand=True)
        self.tree.tag_configure("even", background="#f0f5f2")

    def refresh_families(self):
        self.families = list_families(self.db_path)
        self.family_map = {"أسرة جديدة / دون ربط": None}
        values = ["أسرة جديدة / دون ربط"]
        for family in self.families:
            names = " ".join(filter(None, [family.get("father_first_name"), family.get("father_last_name")]))
            if not names:
                names = " ".join(filter(None, [family.get("mother_first_name"), family.get("mother_last_name")]))
            label = "{} | {}".format(family["family_code"], names or "دون اسم")
            values.append(label)
            self.family_map[label] = family["id"]
        self.family_combo["values"] = values
        if self.family_choice.get() not in values:
            self.family_choice.set(values[0])

    def edit_selected_family(self):
        family_id = self.family_map.get(self.family_choice.get())
        if family_id is None:
            messagebox.showwarning("اختيار الأسرة", "اختر أسرة مسجلة من القائمة أولًا.", parent=self)
            return
        record = next((item for item in self.families if item["id"] == family_id), None)
        if not record:
            messagebox.showerror("الأسرة غير موجودة", "تعذر العثور على الأسرة المحددة.", parent=self)
            self.refresh_families()
            return
        dialog = tk.Toplevel(self)
        dialog.title("تعديل بيانات الأسرة")
        dialog.transient(self)
        dialog.grab_set()
        dialog.geometry("500x450")
        dialog.columnconfigure(1, weight=1)
        fields = {}
        keys = (("father_first_name", "اسم الأب"), ("father_last_name", "لقب الأب"), ("father_phone", "هاتف الأب"),
                ("mother_first_name", "اسم الأم"), ("mother_last_name", "لقب الأم"), ("mother_phone", "هاتف الأم"), ("address", "العنوان"))
        for index, (key, label) in enumerate(keys):
            ttk.Label(dialog, text=label, anchor="e").grid(row=index, column=0, padx=8, pady=5, sticky="ew")
            variable = tk.StringVar(value=record.get(key) or "")
            fields[key] = variable
            ttk.Entry(dialog, textvariable=variable, justify="right").grid(row=index, column=1, padx=8, pady=5, sticky="ew")
        def save_family():
            try:
                update_family(self.db_path, family_id, {key: var.get() for key, var in fields.items()})
            except Exception as exc:
                messagebox.showerror("تعذر التعديل", str(exc), parent=dialog)
                return
            dialog.destroy()
            self.refresh_families()
            messagebox.showinfo("تم التعديل", "تم حفظ بيانات الأسرة.", parent=self)
        def archive_family_action():
            if not messagebox.askyesno("تأكيد الأرشفة", "ستُخفى الأسرة من قائمة الربط الجديدة مع الحفاظ على سجلاتها. متابعة؟", parent=dialog):
                return
            try:
                archive_family(self.db_path, family_id)
            except Exception as exc:
                messagebox.showerror("تعذر الأرشفة", str(exc), parent=dialog)
                return
            dialog.destroy()
            self.refresh_families()
            messagebox.showinfo("الأرشفة", "تمت أرشفة الأسرة دون حذف بياناتها.", parent=self)
        actions = ttk.Frame(dialog)
        actions.grid(row=7, column=0, columnspan=2, pady=12)
        ttk.Button(actions, text="حفظ التعديلات", command=save_family).pack(side="right", padx=4)
        ttk.Button(actions, text="أرشفة الأسرة", command=archive_family_action).pack(side="right", padx=4)

    def save_student(self):
        student = {key: var.get() for key, var in self.fields.items()
                   if key in ("first_name", "last_name", "birth_date", "gender", "student_category", "status", "notes")}
        family = {key: var.get() for key, var in self.fields.items()
                  if key in ("father_first_name", "father_last_name", "father_phone", "mother_first_name", "mother_last_name", "mother_phone", "address")}
        selected_family_id = self.family_map.get(self.family_choice.get())
        try:
            result = register_student(self.db_path, student, family, selected_family_id)
        except DuplicateStudentWarning as exc:
            proceed = messagebox.askyesno("احتمال تكرار", str(exc) + "\n\nهل تريد المتابعة رغم التشابه؟", parent=self)
            if not proceed:
                return
            try:
                result = register_student(self.db_path, student, family, selected_family_id, allow_duplicate=True)
            except RegistryError as retry_exc:
                messagebox.showwarning("تحقق من البيانات", str(retry_exc), parent=self)
                return
        except RegistryError as exc:
            messagebox.showwarning("تحقق من البيانات", str(exc), parent=self)
            return
        except Exception as exc:
            messagebox.showerror("تعذر الحفظ", "لم يتم حفظ التسجيل. التفاصيل: {}".format(exc), parent=self)
            return
        messagebox.showinfo("تم التسجيل", "تم حفظ الطالب بنجاح.\nرقم الطالب: {}".format(result["student_code"]), parent=self)
        self.status_var.set("تم حفظ {} في قاعدة البيانات المحلية.".format(result["student_code"]))
        self.clear_form(keep_status=True)
        self.refresh_families()
        self.refresh_students()
        self.tabs.select(self.directory_tab)

    def make_backup(self):
        from tkinter import filedialog, simpledialog
        folder = filedialog.askdirectory(title="اختر مجلد حفظ النسخة الاحتياطية", parent=self)
        if not folder:
            return
        destination_type = simpledialog.askstring("نوع الوجهة", "اكتب نوع الوجهة: local أو usb أو external_drive", initialvalue="local", parent=self)
        if destination_type is None:
            return
        destination_type = destination_type.strip().lower()
        if destination_type not in ("local", "usb", "external_drive"):
            messagebox.showwarning("نوع غير صحيح", "القيم المقبولة: local أو usb أو external_drive.", parent=self)
            return
        from datetime import datetime
        target = Path(folder) / ("mishkat-backup-{}.sqlite3".format(datetime.now().strftime("%Y%m%d-%H%M%S")))
        try:
            create_backup(self.db_path, target, destination_type=destination_type)
            messagebox.showinfo("النسخ الاحتياطي", "تم إنشاء نسخة والتحقق من سلامتها:\n{}".format(target), parent=self)
        except BackupError as exc:
            messagebox.showerror("فشل النسخ الاحتياطي", str(exc), parent=self)

    def check_backup(self):
        from tkinter import filedialog
        chosen = filedialog.askopenfilename(title="اختر نسخة لفحصها", filetypes=(("SQLite", "*.sqlite3 *.db *.sqlite"), ("كل الملفات", "*.*")), parent=self)
        if not chosen:
            return
        try:
            info = verify_backup(chosen)
            messagebox.showinfo("فحص النسخة", "النسخة سليمة.\nعدد الجداول: {}\nعدد الطلبة: {}\nالحجم: {} بايت".format(info["table_count"], info["student_count"], info["size_bytes"]), parent=self)
        except BackupError as exc:
            messagebox.showerror("نسخة غير صالحة", str(exc), parent=self)

    def restore_backup(self):
        from tkinter import filedialog
        chosen = filedialog.askopenfilename(title="اختر نسخة مِشكاة لاستعادتها", filetypes=(("SQLite", "*.sqlite3 *.db *.sqlite"), ("كل الملفات", "*.*")), parent=self)
        if not chosen:
            return
        try:
            info = verify_backup(chosen)
        except BackupError as exc:
            messagebox.showerror("نسخة غير صالحة", str(exc), parent=self)
            return
        warning = "ستُستبدل البيانات الحالية بمحتوى النسخة المختارة. سيُنشأ ملف أمان بجانب قاعدة البيانات الحالية.\nعدد الطلبة في النسخة: {}\n\nتابع فقط إذا كنت متأكدًا.".format(info["student_count"])
        if not messagebox.askyesno("تأكيد الاستعادة — 1 من 2", warning, icon="warning", parent=self):
            return
        if not messagebox.askyesno("تأكيد الاستعادة — 2 من 2", "تأكيد نهائي لاستبدال البيانات الحالية؟", icon="warning", parent=self):
            return
        from datetime import datetime
        current = Path(self.db_path)
        safety = current.with_name("safety-before-restore-{}.sqlite3".format(datetime.now().strftime("%Y%m%d-%H%M%S")))
        try:
            restore_backup(self.db_path, chosen, safety)
            messagebox.showinfo("تمت الاستعادة", "اكتملت الاستعادة. نسخة الأمان: {}\nأعد تشغيل البرنامج إذا ظهرت بيانات قديمة في الواجهة.".format(safety), parent=self)
            self.refresh_families()
            self.refresh_students()
        except BackupError as exc:
            messagebox.showerror("فشلت الاستعادة", str(exc), parent=self)

    def clear_form(self, keep_status=False):
        for key, var in self.fields.items():
            if key in ("gender", "student_category", "status"):
                continue
            var.set("")
        self.fields["gender"].set("male")
        self.fields["student_category"].set("child")
        self.fields["status"].set("active")
        if hasattr(self, "family_choice"):
            self.family_choice.set("أسرة جديدة / دون ربط")
        if not keep_status:
            self.status_var.set("أُفرغت الحقول؛ لم تُحذف أي بيانات محفوظة.")

    def refresh_students(self):
        if not hasattr(self, "tree"):
            return
        for item in self.tree.get_children():
            self.tree.delete(item)
        for index, row in enumerate(search_students(self.db_path, self.search_var.get())):
            gender = "ذكر" if row["gender"] == "male" else "أنثى"
            category = "طفل" if row["student_category"] == "child" else "بالغ"
            status_names = {"active": "نشط", "paused": "مجمّد", "withdrawn": "منسحب", "completed": "أتمّ", "archived": "مؤرشف"}
            name = "{} {}".format(row["first_name"], row["last_name"])
            phone = row.get("father_phone") or row.get("mother_phone") or "—"
            self.tree.insert("", "end", iid=str(row["id"]), values=(row["student_code"], name, gender, category,
                                                   row.get("family_code") or "—", phone,
                                                   status_names.get(row["status"], row["status"])),
                             tags=("even" if index % 2 == 0 else "",))
        self.status_var.set("عدد النتائج المعروضة: {} (الحد الأقصى 500).".format(len(self.tree.get_children())))

    def _selected_student_id(self):
        selected = self.tree.selection()
        if not selected:
            messagebox.showwarning("لم يتم التحديد", "اختر طالبًا من القائمة أولًا.", parent=self)
            return None
        return int(selected[0])

    def archive_selected_student(self):
        student_id = self._selected_student_id()
        if student_id is None:
            return
        if not messagebox.askyesno("تأكيد الأرشفة", "سيتم تغيير حالة الطالب إلى مؤرشف دون حذف سجلاته. هل تريد المتابعة؟", parent=self):
            return
        try:
            archive_student(self.db_path, student_id)
            self.refresh_students()
            messagebox.showinfo("الأرشفة", "تمت أرشفة السجل دون حذفه.", parent=self)
        except Exception as exc:
            messagebox.showerror("تعذر الأرشفة", str(exc), parent=self)

    def edit_selected_student(self):
        student_id = self._selected_student_id()
        if student_id is None:
            return
        record = get_student(self.db_path, student_id)
        if not record:
            messagebox.showerror("السجل غير موجود", "تعذر العثور على الطالب المحدد.", parent=self)
            self.refresh_students()
            return
        dialog = tk.Toplevel(self)
        dialog.title("تعديل بيانات الطالب")
        dialog.transient(self)
        dialog.grab_set()
        dialog.geometry("470x430")
        dialog.columnconfigure(1, weight=1)
        fields = {}
        definitions = (("first_name", "الاسم"), ("last_name", "اللقب"), ("birth_date", "تاريخ الميلاد"), ("notes", "ملاحظات"))
        for row_index, (key, label) in enumerate(definitions):
            ttk.Label(dialog, text=label, anchor="e").grid(row=row_index, column=0, padx=8, pady=6, sticky="ew")
            variable = tk.StringVar(value=record.get(key) or "")
            fields[key] = variable
            ttk.Entry(dialog, textvariable=variable, justify="right").grid(row=row_index, column=1, padx=8, pady=6, sticky="ew")
        for row_index, (key, label, options) in enumerate((
            ("gender", "الجنس", (("ذكر", "male"), ("أنثى", "female"))),
            ("student_category", "الفئة", (("طفل", "child"), ("بالغ", "adult"))),
            ("status", "الحالة", (("نشط", "active"), ("مجمّد", "paused"), ("منسحب", "withdrawn"), ("متخرج", "completed"), ("مؤرشف", "archived"))),
        ), start=len(definitions)):
            ttk.Label(dialog, text=label, anchor="e").grid(row=row_index, column=0, padx=8, pady=6, sticky="ew")
            variable = tk.StringVar(value=record.get(key) or options[0][1])
            fields[key] = variable
            ttk.Combobox(dialog, textvariable=variable, state="readonly", values=tuple(value for _, value in options), justify="right").grid(row=row_index, column=1, padx=8, pady=6, sticky="ew")
        def save_changes():
            try:
                update_student(self.db_path, student_id, {key: var.get() for key, var in fields.items()})
            except Exception as exc:
                messagebox.showerror("تعذر التعديل", str(exc), parent=dialog)
                return
            dialog.destroy()
            self.refresh_students()
            messagebox.showinfo("تم التعديل", "تم حفظ التغييرات.", parent=self)
        ttk.Button(dialog, text="حفظ التعديلات", command=save_changes).grid(row=7, column=0, columnspan=2, padx=8, pady=12)

    def show_all_students(self):
        self.search_var.set("")
        self.refresh_students()


def main():
    db_path = default_database_path()
    initialize_database(str(db_path))
    app = QuranSchoolApp(db_path)
    app.mainloop()


if __name__ == "__main__":
    main()
