"""Local-only HTML application backed by SQLite; uses Python standard library."""
from __future__ import annotations

import json
import base64
import binascii
import os
import shutil
import socket
import sys
import threading
import webbrowser
from datetime import datetime, timedelta
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import parse_qs, urlparse
import csv, io, tempfile, sqlite3, zipfile, html as html_lib, random
import xml.etree.ElementTree as ET
from .import_export import read_tabular, table_to_csv, MAX_IMPORT_BYTES
from .association import RESOURCES, normalize_payload, reports

from .db import default_database_path, initialize_database, connect, validate_database
from .registry import normalize_search

ROOT = Path(__file__).resolve().parents[1]
HTML_PATH = ROOT / "web" / "index.html"
MAX_BODY = 140 * 1024 * 1024
STATUSES = {"active", "paused", "withdrawn", "completed", "archived"}
CATEGORIES = {"child", "adult"}
GENDERS = {"male", "female"}


def _json_bytes(obj):
    return json.dumps(obj, ensure_ascii=False).encode("utf-8")


def _student_dict(row):
    return {k: row[k] for k in row.keys()}


class MishkatHandler(BaseHTTPRequestHandler):
    server_version = "MishkatLocal/0.11.0"

    def log_message(self, fmt, *args):
        # Local school app: keep terminal logs concise and avoid logging submitted personal data.
        print("[Mishkat] " + (fmt % args))

    def _send(self, status, payload, content_type="application/json; charset=utf-8"):
        raw = payload if isinstance(payload, bytes) else _json_bytes(payload)
        self.send_response(status)
        self.send_header("Content-Type", content_type)
        self.send_header("Content-Length", str(len(raw)))
        self.send_header("X-Content-Type-Options", "nosniff")
        self.send_header("Cache-Control", "no-store")
        self.send_header("Content-Security-Policy", "default-src 'self'; script-src 'self' 'unsafe-inline'; style-src 'self' 'unsafe-inline'; img-src 'self' data:; connect-src 'self'; object-src 'none'; base-uri 'none'; frame-ancestors 'none'")
        self.end_headers()
        self.wfile.write(raw)

    def _error(self, status, message, **extra):
        self._send(status, {"error": message, **extra})

    def _body(self):
        try:
            length = int(self.headers.get("Content-Length", "0"))
        except ValueError:
            raise ValueError("طول الطلب غير صالح.")
        if length < 0 or length > MAX_BODY:
            raise ValueError("حجم البيانات أكبر من الحد المسموح.")
        raw = self.rfile.read(length)
        if not raw:
            return {}
        try:
            data = json.loads(raw.decode("utf-8"))
        except (UnicodeDecodeError, json.JSONDecodeError):
            raise ValueError("صيغة البيانات غير صحيحة.")
        if not isinstance(data, dict):
            raise ValueError("يجب إرسال كائن بيانات صالح.")
        return data

    def do_GET(self):
        parsed = urlparse(self.path)
        if parsed.path == "/":
            try:
                html = HTML_PATH.read_bytes()
            except OSError:
                return self._error(500, "ملف الواجهة غير موجود.")
            return self._send(200, html, "text/html; charset=utf-8")
        if parsed.path == "/api/health":
            return self._send(200, {"status": "ok", "storage": str(self.server.db_path), "online_required": False})
        if parsed.path == "/api/institution":
            with connect(self.server.db_path) as con:
                row = con.execute("SELECT id,official_name,branch_name,supervisor_name,address,phone,logo_relative_path FROM institution WHERE id=1").fetchone()
            return self._send(200, dict(row) if row else {})
        if parsed.path == "/api/logo":
            with connect(self.server.db_path) as con:
                row = con.execute("SELECT logo_relative_path FROM institution WHERE id=1").fetchone()
            if not row or not row["logo_relative_path"]:
                return self._error(404, "لم يُضف ملف شعار بعد.")
            logo_path = (self.server.db_path.parent / row["logo_relative_path"]).resolve()
            assets_root = (self.server.db_path.parent / "assets").resolve()
            if assets_root not in logo_path.parents or not logo_path.is_file():
                return self._error(404, "ملف الشعار غير موجود.")
            suffix = logo_path.suffix.lower()
            mime = {".png":"image/png", ".jpg":"image/jpeg", ".jpeg":"image/jpeg", ".webp":"image/webp"}.get(suffix, "application/octet-stream")
            return self._send(200, logo_path.read_bytes(), mime)
        if parsed.path == "/api/dashboard":
            with connect(self.server.db_path) as con:
                total = con.execute("SELECT COUNT(*) FROM students").fetchone()[0]
                active = con.execute("SELECT COUNT(*) FROM students WHERE status='active'").fetchone()[0]
                children = con.execute("SELECT COUNT(*) FROM students WHERE student_category='child'").fetchone()[0]
                adults = con.execute("SELECT COUNT(*) FROM students WHERE student_category='adult'").fetchone()[0]
                families = con.execute("SELECT COUNT(*) FROM families WHERE status='active'").fetchone()[0]
                recent = con.execute("SELECT id,student_code,first_name,last_name,birth_date,gender,student_category,status,created_at FROM students ORDER BY id DESC LIMIT 8").fetchall()
            return self._send(200, {"total_students": total, "active_students": active, "children": children, "adults": adults, "total_families": families, "recent_students": [_student_dict(r) for r in recent]})
        if parsed.path == "/api/families":
            params = parse_qs(parsed.query)
            q = params.get("q", [""])[0].strip()
            include_archived = params.get("all", [""])[0] == "1"
            with connect(self.server.db_path) as con:
                sql = """SELECT f.id,f.family_code,f.father_first_name,f.father_last_name,f.father_phone,
                    f.mother_first_name,f.mother_last_name,f.mother_phone,f.address,f.status,
                    COUNT(DISTINCT s.id) AS student_count,
                    GROUP_CONCAT(DISTINCT TRIM(s.first_name || ' ' || s.last_name)) AS student_names
                    FROM families f LEFT JOIN students s ON s.family_id=f.id WHERE 1=1"""
                args = []
                if not include_archived:
                    sql += " AND f.status='active'"
                if q:
                    key = normalize_search(q)
                    like = "%" + key + "%"
                    sql += " AND (f.search_key LIKE ? OR f.family_code LIKE ? OR f.father_phone LIKE ? OR f.mother_phone LIKE ? OR f.address LIKE ?)"
                    args.extend([like, "%"+q+"%", "%"+q+"%", "%"+q+"%", "%"+q+"%"])
                sql += " GROUP BY f.id ORDER BY f.id DESC LIMIT 1000"
                rows = con.execute(sql, args).fetchall()
            return self._send(200, {"families": [_student_dict(r) for r in rows]})
        if parsed.path == "/api/teachers":
            params = parse_qs(parsed.query)
            include_inactive = params.get("all", [""])[0] == "1"
            with connect(self.server.db_path) as con:
                sql = "SELECT id,teacher_code,first_name,last_name,phone,specialty,is_active,notes,created_at FROM teachers"
                if not include_inactive:
                    sql += " WHERE is_active=1"
                sql += " ORDER BY last_name,first_name,id DESC LIMIT 1000"
                rows = con.execute(sql).fetchall()
            return self._send(200, {"teachers": [_student_dict(r) for r in rows]})
        if parsed.path == "/api/levels":
            params = parse_qs(parsed.query)
            include_inactive = params.get("all", [""])[0] == "1"
            with connect(self.server.db_path) as con:
                sql = "SELECT id,name,description,min_age,max_age,is_active FROM levels"
                if not include_inactive:
                    sql += " WHERE is_active=1"
                sql += " ORDER BY name LIMIT 1000"
                rows = con.execute(sql).fetchall()
            return self._send(200, {"levels": [_student_dict(r) for r in rows]})
        if parsed.path == "/api/groups":
            params = parse_qs(parsed.query)
            include_inactive = params.get("all", [""])[0] == "1"
            with connect(self.server.db_path) as con:
                sql = """SELECT g.id,g.group_code,g.name,g.level_id,g.teacher_id,g.target_gender,g.min_age,g.max_age,g.schedule_text,g.is_active,
                    l.name AS level_name,t.first_name || ' ' || t.last_name AS teacher_name,
                    (SELECT COUNT(*) FROM enrollments e WHERE e.group_id=g.id AND e.status='active') AS student_count
                    FROM groups g LEFT JOIN levels l ON l.id=g.level_id LEFT JOIN teachers t ON t.id=g.teacher_id"""
                if not include_inactive:
                    sql += " WHERE g.is_active=1"
                sql += " ORDER BY g.name,g.id DESC LIMIT 1000"
                rows = con.execute(sql).fetchall()
            return self._send(200, {"groups": [_student_dict(r) for r in rows]})
        if parsed.path == "/api/enrollments":
            params = parse_qs(parsed.query)
            include_inactive = params.get("all", [""])[0] == "1"
            with connect(self.server.db_path) as con:
                sql = """SELECT e.id,e.student_id,e.group_id,e.academic_period_id,e.start_date,e.end_date,e.status,e.notes,
                    s.student_code,s.first_name || ' ' || s.last_name AS student_name,g.group_code,g.name AS group_name,
                    l.name AS level_name,t.first_name || ' ' || t.last_name AS teacher_name
                    FROM enrollments e JOIN students s ON s.id=e.student_id JOIN groups g ON g.id=e.group_id
                    LEFT JOIN levels l ON l.id=g.level_id LEFT JOIN teachers t ON t.id=g.teacher_id"""
                if not include_inactive:
                    sql += " WHERE e.status='active'"
                sql += " ORDER BY e.id DESC LIMIT 2000"
                rows = con.execute(sql).fetchall()
            return self._send(200, {"enrollments": [_student_dict(r) for r in rows]})
        if parsed.path == "/api/attendance":
            params = parse_qs(parsed.query)
            try:
                group_id = int(params.get("group_id", ["0"])[0])
                session_date = str(params.get("date", [datetime.now().date().isoformat()])[0]).strip()
                datetime.strptime(session_date, "%Y-%m-%d")
            except (TypeError, ValueError):
                return self._error(400, "اختر حلقة وتاريخًا صحيحين.")
            with connect(self.server.db_path) as con:
                group = con.execute("""SELECT g.id,g.group_code,g.name,g.teacher_id,g.is_active,
                    t.first_name || ' ' || t.last_name AS teacher_name
                    FROM groups g LEFT JOIN teachers t ON t.id=g.teacher_id WHERE g.id=?""", (group_id,)).fetchone()
                if not group:
                    return self._error(404, "الحلقة غير موجودة.")
                session = con.execute("SELECT * FROM attendance_sessions WHERE group_id=? AND session_date=?", (group_id, session_date)).fetchone()
                roster = con.execute("""SELECT s.id AS student_id,s.student_code,s.first_name,s.last_name,
                    ar.status,ar.reason,ar.notes AS attendance_notes
                    FROM enrollments e JOIN students s ON s.id=e.student_id
                    LEFT JOIN attendance_records ar ON ar.student_id=s.id AND ar.session_id=?
                    WHERE e.group_id=? AND e.start_date<=? AND (e.end_date IS NULL OR e.end_date>=?)
                    AND s.status IN ('active','paused','withdrawn','completed','archived')
                    ORDER BY s.last_name,s.first_name,s.id""", (session["id"] if session else -1, group_id, session_date, session_date)).fetchall()
                history = con.execute("""SELECT a.id,a.session_date,a.session_label,a.is_closed,
                    (SELECT COUNT(*) FROM attendance_records r WHERE r.session_id=a.id) AS marked_count,
                    (SELECT COUNT(DISTINCT e.student_id) FROM enrollments e
                     WHERE e.group_id=a.group_id AND e.start_date<=a.session_date
                       AND (e.end_date IS NULL OR e.end_date>=a.session_date)) AS roster_count
                    FROM attendance_sessions a WHERE a.group_id=?
                    ORDER BY a.session_date DESC,a.id DESC LIMIT 30""", (group_id,)).fetchall()
            return self._send(200, {"group": _student_dict(group), "date": session_date,
                "session": _student_dict(session) if session else None,
                "students": [_student_dict(r) for r in roster], "history": [_student_dict(r) for r in history]})
        if parsed.path == "/api/students":
            params = parse_qs(parsed.query)
            q = params.get("q", [""])[0].strip()
            status = params.get("status", [""])[0]
            if status and status not in STATUSES:
                return self._error(400, "قيمة الحالة غير صحيحة.")
            with connect(self.server.db_path) as con:
                sql = "SELECT s.id,s.student_code,s.first_name,s.last_name,s.birth_date,s.gender,s.student_category,s.status,s.notes,s.created_at,s.updated_at,s.family_id,f.family_code FROM students s LEFT JOIN families f ON f.id=s.family_id WHERE 1=1"
                args = []
                if q:
                    key = normalize_search(q)
                    like = "%" + key + "%"
                    sql += " AND (s.search_key LIKE ? OR s.student_code LIKE ? OR s.first_name LIKE ? OR s.last_name LIKE ? OR f.search_key LIKE ?)"
                    args.extend([like, "%" + q + "%", "%" + q + "%", "%" + q + "%", like])
                if status:
                    sql += " AND s.status=?"
                    args.append(status)
                sql += " ORDER BY s.last_name, s.first_name, s.id DESC LIMIT 1000"
                rows = con.execute(sql, args).fetchall()
            return self._send(200, {"students": [_student_dict(r) for r in rows]})
        if parsed.path == "/api/quran/surahs":
            with connect(self.server.db_path) as con:
                rows = con.execute("SELECT surah_number,arabic_name,ayah_count FROM quran_surahs ORDER BY surah_number").fetchall()
            return self._send(200, {"surahs": [_student_dict(r) for r in rows]})
        if parsed.path == "/api/memorization":
            params = parse_qs(parsed.query)
            try: student_id = int(params.get("student_id", ["0"])[0])
            except (ValueError, TypeError): return self._error(400, "معرّف الطالب غير صالح.")
            with connect(self.server.db_path) as con:
                student = con.execute("SELECT id,student_code,first_name,last_name FROM students WHERE id=?", (student_id,)).fetchone()
                if not student: return self._error(404, "الطالب غير موجود.")
                rows = con.execute("""SELECT e.id,e.work_type,e.start_surah,e.start_ayah,e.end_surah,e.end_ayah,e.score,e.mistake_count,e.decision,e.notes,
                    ss.session_date,ss.notes AS session_notes,t.first_name || ' ' || t.last_name AS teacher_name,g.name AS group_name,
                    a.arabic_name AS start_surah_name,b.arabic_name AS end_surah_name
                    FROM quran_learning_entries e JOIN quran_learning_sessions ss ON ss.id=e.session_id
                    JOIN quran_surahs a ON a.surah_number=e.start_surah JOIN quran_surahs b ON b.surah_number=e.end_surah
                    LEFT JOIN teachers t ON t.id=ss.teacher_id LEFT JOIN groups g ON g.id=ss.group_id
                    WHERE ss.student_id=? ORDER BY ss.session_date DESC,e.id DESC LIMIT 500""", (student_id,)).fetchall()
                summary = con.execute("""SELECT COUNT(*) AS entries,COALESCE(AVG(score),0) AS average_score,
                    SUM(CASE WHEN decision='accepted' THEN 1 ELSE 0 END) AS accepted,
                    SUM(CASE WHEN decision='retry' THEN 1 ELSE 0 END) AS retry_count,
                    SUM(CASE WHEN decision='deferred' THEN 1 ELSE 0 END) AS deferred_count
                    FROM quran_learning_entries e JOIN quran_learning_sessions ss ON ss.id=e.session_id WHERE ss.student_id=?""", (student_id,)).fetchone()
            return self._send(200, {"student": _student_dict(student), "entries": [_student_dict(r) for r in rows], "summary": _student_dict(summary)})
        if parsed.path == "/api/association":
            with connect(self.server.db_path) as con:
                return self._send(200, {"reports": reports(con)})
        if parsed.path.startswith("/api/documents/") and parsed.path.endswith("/file"):
            try: document_id=int(parsed.path.split('/')[-2])
            except ValueError: return self._error(400,"معرّف الوثيقة غير صحيح.")
            with connect(self.server.db_path) as con: row=con.execute("SELECT file_name,relative_path FROM association_documents WHERE id=?",(document_id,)).fetchone()
            if not row or not row['relative_path']: return self._error(404,"لا يوجد ملف مرفق بهذه الوثيقة.")
            target=(self.server.db_path.parent/row['relative_path']).resolve(); root=(self.server.db_path.parent/'documents').resolve()
            if root not in target.parents or not target.is_file(): return self._error(404,"ملف الوثيقة غير موجود.")
            mime={'.pdf':'application/pdf','.docx':'application/vnd.openxmlformats-officedocument.wordprocessingml.document','.xlsx':'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet','.csv':'text/csv; charset=utf-8','.txt':'text/plain; charset=utf-8','.png':'image/png','.jpg':'image/jpeg','.jpeg':'image/jpeg'}.get(target.suffix.lower(),'application/octet-stream')
            raw=target.read_bytes(); self.send_response(200); self.send_header('Content-Type',mime); self.send_header('Content-Disposition',"attachment; filename*=UTF-8''"+__import__('urllib.parse').parse.quote(row['file_name'] or target.name)); self.send_header('Content-Length',str(len(raw))); self.send_header('X-Content-Type-Options','nosniff'); self.end_headers(); self.wfile.write(raw); return
        if parsed.path == "/api/storage":
            roots=[]
            if os.name == "nt":
                import ctypes
                bitmask=ctypes.windll.kernel32.GetLogicalDrives()
                for i in range(26):
                    if bitmask & (1 << i):
                        root=chr(65+i)+":\\"
                        dtype=ctypes.windll.kernel32.GetDriveTypeW(root)
                        roots.append({"path":root,"type":"removable" if dtype==2 else "fixed" if dtype==3 else "network" if dtype==4 else "other"})
            else:
                for root in (Path("/media"),Path("/mnt"),Path("/run/media")):
                    if root.exists():
                        for child in root.iterdir():
                            if child.is_dir(): roots.append({"path":str(child),"type":"external_candidate"})
            return self._send(200,{"drives":roots,"default_backup":str(self.server.db_path.parent / "backups")})
        if parsed.path.startswith("/api/association/"):
            resource=parsed.path.removeprefix("/api/association/").strip("/")
            if resource not in RESOURCES: return self._error(404,"نوع السجل غير معروف.")
            table,fields,_=RESOURCES[resource]
            with connect(self.server.db_path) as con:
                rows=con.execute("SELECT * FROM "+table+" ORDER BY id DESC LIMIT 3000").fetchall()
            return self._send(200,{"resource":resource,"fields":fields,"rows":[_student_dict(r) for r in rows]})
        if parsed.path == "/api/reports/top-students":
            params=parse_qs(parsed.query); limit=max(1,min(50,int(params.get('limit',['10'])[0] or 10)))
            with connect(self.server.db_path) as con:
                rows=con.execute("""SELECT s.id,s.student_code,s.first_name,s.last_name,COUNT(e.id) AS entries,ROUND(AVG(e.score),2) AS average_score,
                    SUM(CASE WHEN e.decision='accepted' THEN 1 ELSE 0 END) AS accepted_count
                    FROM students s JOIN quran_learning_sessions ss ON ss.student_id=s.id JOIN quran_learning_entries e ON e.session_id=ss.id
                    WHERE s.status='active' GROUP BY s.id HAVING COUNT(e.id)>0 ORDER BY average_score DESC,accepted_count DESC,entries DESC,s.last_name LIMIT ?""",(limit,)).fetchall()
            return self._send(200,{'top_students':[_student_dict(r) for r in rows]})
        if parsed.path == "/api/reports":
            with connect(self.server.db_path) as con:
                data=reports(con)
                data["attendance_summary"]=[dict(r) for r in con.execute("SELECT status,COUNT(*) AS count FROM attendance_records GROUP BY status")]
                data["memorization_summary"]=[dict(r) for r in con.execute("SELECT work_type,decision,COUNT(*) AS count,ROUND(AVG(score),2) AS average_score FROM quran_learning_entries GROUP BY work_type,decision")]
            return self._send(200,data)
        if parsed.path == "/api/export":
            params=parse_qs(parsed.query); entity=params.get("entity",["students"])[0]
            queries={
              "students":("SELECT student_code,first_name,last_name,birth_date,gender,student_category,status,family_id,notes FROM students ORDER BY id",["student_code","first_name","last_name","birth_date","gender","student_category","status","family_id","notes"]),
              "families":("SELECT family_code,father_first_name,father_last_name,father_phone,mother_first_name,mother_last_name,mother_phone,address,status FROM families ORDER BY id",["family_code","father_first_name","father_last_name","father_phone","mother_first_name","mother_last_name","mother_phone","address","status"]),
              "members":("SELECT member_code,first_name,last_name,phone,email,membership_type,role_title,status FROM association_members ORDER BY id",["member_code","first_name","last_name","phone","email","membership_type","role_title","status"]),
              "transactions":("SELECT transaction_date,direction,category,description,amount,payment_method,counterparty,reference_no FROM association_transactions ORDER BY transaction_date,id",["transaction_date","direction","category","description","amount","payment_method","counterparty","reference_no"]),
              "assets":("SELECT asset_code,name,category,quantity,unit,condition_status,acquisition_date,acquisition_cost,location,custodian,status FROM association_assets ORDER BY id",["asset_code","name","category","quantity","unit","condition_status","acquisition_date","acquisition_cost","location","custodian","status"]),
            }
            if entity in queries:
                sql,headers=queries[entity]
                with connect(self.server.db_path) as con: rows=[dict(r) for r in con.execute(sql).fetchall()]
            elif entity in RESOURCES:
                table,headers,_=RESOURCES[entity]
                with connect(self.server.db_path) as con: rows=[dict(r) for r in con.execute("SELECT "+','.join(headers)+" FROM "+table+" ORDER BY id").fetchall()]
            else: return self._error(400,"نوع التصدير غير معروف.")
            raw=table_to_csv(headers,rows)
            self.send_response(200); self.send_header("Content-Type","text/csv; charset=utf-8")
            self.send_header("Content-Disposition",f'attachment; filename="mishkat_{entity}.csv"')
            self.send_header("Content-Length",str(len(raw))); self.send_header("X-Content-Type-Options","nosniff")
            self.send_header("Cache-Control","no-store"); self.end_headers(); self.wfile.write(raw); return
        return self._error(404, "المسار المطلوب غير موجود.")

    def _group_values(self, data, row=None):
        """Validate a group payload; return DB values or an explicit error tuple."""
        def val(key, default=""):
            return data.get(key, (row[key] if row is not None else default))
        code = str(val("group_code")).strip(); name = str(val("name")).strip()
        gender = str(val("target_gender", "mixed")).strip()
        try:
            level_id = int(val("level_id")) if str(val("level_id") or "").strip() else None
            teacher_id = int(val("teacher_id")) if str(val("teacher_id") or "").strip() else None
            min_age = int(val("min_age")) if str(val("min_age") or "").strip() else None
            max_age = int(val("max_age")) if str(val("max_age") or "").strip() else None
        except (TypeError, ValueError): return ("ERROR", 400, "معرّفات المستوى والمعلم والأعمار يجب أن تكون أرقامًا صحيحة.")
        schedule = str(val("schedule_text")).strip() or None
        active = 1 if val("is_active", 1) in (1, True, "1", "true") else 0
        if not code or not name or len(code)>40 or len(name)>100: return ("ERROR", 400, "رمز الحلقة واسمها إلزاميان وبطول مناسب.")
        if gender not in ("male", "female", "mixed"): return ("ERROR", 400, "فئة الحلقة غير صحيحة.")
        if any(x is not None and x<0 for x in (min_age,max_age)) or (min_age is not None and max_age is not None and min_age>max_age): return ("ERROR", 400, "نطاق أعمار الحلقة غير صحيح.")
        # Foreign key existence and active status are checked explicitly for useful errors.
        with connect(self.server.db_path) as con:
            if level_id is not None and not con.execute("SELECT 1 FROM levels WHERE id=? AND is_active=1", (level_id,)).fetchone(): return ("ERROR", 400, "المستوى المحدد غير موجود أو غير نشط.")
            if teacher_id is not None and not con.execute("SELECT 1 FROM teachers WHERE id=? AND is_active=1", (teacher_id,)).fetchone(): return ("ERROR", 400, "المعلم المحدد غير موجود أو غير نشط.")
        return (code,name,level_id,teacher_id,gender,min_age,max_age,schedule,active)

    def do_POST(self):
        parsed = urlparse(self.path)
        if parsed.path == "/api/shutdown":
            threading.Thread(target=self.server.shutdown, daemon=True).start()
            return self._send(200,{"message":"تم طلب إيقاف مِشكاة محليًا."})
        if parsed.path == "/api/reports/generate":
            try: data=self._body()
            except ValueError as exc: return self._error(400,str(exc))
            report_type=str(data.get('report_type','general')); title=str(data.get('title','')).strip()
            if report_type not in ('literary','financial','activities','annual','general'): return self._error(400,'نوع التقرير غير صحيح.')
            start=str(data.get('period_start','')).strip() or None; end=str(data.get('period_end','')).strip() or None
            with connect(self.server.db_path) as con:
                institution=con.execute('SELECT official_name,branch_name,supervisor_name FROM institution WHERE id=1').fetchone()
                if report_type=='financial':
                    income=con.execute("SELECT COALESCE(SUM(amount),0) FROM association_transactions WHERE direction='income' AND (? IS NULL OR transaction_date>=?) AND (? IS NULL OR transaction_date<=?)",(start,start,end,end)).fetchone()[0]
                    expenses=con.execute("SELECT COALESCE(SUM(amount),0) FROM association_transactions WHERE direction='expense' AND (? IS NULL OR transaction_date>=?) AND (? IS NULL OR transaction_date<=?)",(start,start,end,end)).fetchone()[0]
                    tx=con.execute("SELECT transaction_date,direction,category,description,amount FROM association_transactions WHERE (? IS NULL OR transaction_date>=?) AND (? IS NULL OR transaction_date<=?) ORDER BY transaction_date,id",(start,start,end,end)).fetchall()
                    body='التقرير المالي للجمعية\nالفترة: '+str(start or 'بداية السجلات')+' إلى '+str(end or 'اليوم')+'\nإجمالي الإيرادات: '+format(income,'.2f')+' دج\nإجمالي المصروفات: '+format(expenses,'.2f')+' دج\nالرصيد الصافي: '+format(income-expenses,'.2f')+' دج\n\nتفاصيل الحركات:\n'+'\n'.join(f"{r['transaction_date']} | {r['direction']} | {r['category']} | {r['description']} | {r['amount']} دج" for r in tx)
                elif report_type=='literary':
                    meetings=con.execute("SELECT meeting_date,title,status FROM association_meetings WHERE (? IS NULL OR meeting_date>=?) AND (? IS NULL OR meeting_date<=?) ORDER BY meeting_date",(start,start,end,end)).fetchall()
                    activities=con.execute("SELECT activity_date,title,activity_type,status,description FROM association_activities WHERE (? IS NULL OR activity_date>=?) AND (? IS NULL OR activity_date<=?) ORDER BY activity_date",(start,start,end,end)).fetchall()
                    members=con.execute("SELECT COUNT(*) FROM association_members WHERE status='active'").fetchone()[0]
                    body='التقرير الأدبي للجمعية\n'+str(institution['official_name'])+' — '+str(institution['branch_name'])+'\nالفترة: '+str(start or 'بداية السجلات')+' إلى '+str(end or 'اليوم')+'\nالأعضاء النشطون: '+str(members)+'\n\nالاجتماعات:\n'+'\n'.join(f"{r['meeting_date']} | {r['title']} | {r['status']}" for r in meetings)+'\n\nالأنشطة:\n'+'\n'.join(f"{r['activity_date'] or 'دون تاريخ'} | {r['title']} | {r['activity_type']} | {r['status']} | {r['description'] or ''}" for r in activities)
                elif report_type=='annual':
                    plans=con.execute("SELECT title,category,planned_start,planned_end,progress,status,budget_estimate,actual_notes FROM annual_plan_items ORDER BY planned_start,id").fetchall()
                    body='متابعة البرنامج السنوي\n'+'\n'.join(f"{r['title']} | {r['category']} | {r['planned_start'] or ''} - {r['planned_end'] or ''} | {r['progress']}% | {r['status']} | ميزانية {r['budget_estimate']} دج | {r['actual_notes'] or ''}" for r in plans)
                else:
                    body='تقرير الجمعية\n'+str(institution['official_name'])+' — '+str(institution['branch_name'])+'\nالفترة: '+str(start or 'بداية السجلات')+' إلى '+str(end or 'اليوم')+'\nعدد الاجتماعات: '+str(con.execute('SELECT COUNT(*) FROM association_meetings').fetchone()[0])+'\nعدد الأنشطة: '+str(con.execute('SELECT COUNT(*) FROM association_activities').fetchone()[0])+'\nعدد عناصر الخطة السنوية: '+str(con.execute('SELECT COUNT(*) FROM annual_plan_items').fetchone()[0])
                final_title=title or {'financial':'التقرير المالي','literary':'التقرير الأدبي','annual':'متابعة البرنامج السنوي','activities':'تقرير النشاطات','general':'تقرير عام'}[report_type]
                cur=con.execute("INSERT INTO association_reports(report_type,title,period_start,period_end,summary,body,prepared_by,status) VALUES(?,?,?,?,?,?,?,'draft')",(report_type,final_title,start,end,body[:500],body,str(institution['supervisor_name'] or '') or None)); con.commit()
            return self._send(201,{'id':cur.lastrowid,'title':final_title,'body':body,'message':'تم إنشاء مسودة التقرير وحفظها؛ راجعها واعتمدها قبل استعمالها رسميًا.'})
        if parsed.path == "/api/awards/generate":
            try: data=self._body(); ids=sorted(set(int(x) for x in data.get('student_ids',[]))); award_date=str(data.get('award_date',datetime.now().date().isoformat())); title=str(data.get('award_title','شهادة تفوق')).strip()
            except (ValueError,TypeError): return self._error(400,'قائمة الطلبة أو التاريخ غير صحيح.')
            if not ids or len(ids)>50 or not title: return self._error(400,'حدد طالبًا واحدًا على الأقل وعنوانًا للجائزة.')
            try: datetime.strptime(award_date,'%Y-%m-%d')
            except ValueError: return self._error(400,'تاريخ الجائزة غير صحيح.')
            created=0; skipped=0
            with connect(self.server.db_path) as con:
                con.execute('BEGIN IMMEDIATE')
                for rank,sid in enumerate(ids,1):
                    student=con.execute("SELECT id FROM students WHERE id=? AND status='active'",(sid,)).fetchone()
                    if not student: skipped+=1; continue
                    exists=con.execute('SELECT 1 FROM student_awards WHERE student_id=? AND award_title=? AND award_date=?',(sid,title,award_date)).fetchone()
                    if exists: skipped+=1; continue
                    con.execute("INSERT INTO student_awards(student_id,award_title,award_date,award_type,rank_text,reason,presented_by) VALUES(?,?,?,'excellence',?,?,?)",(sid,title,award_date,str(rank), 'التميز في الحفظ والتسميع','إدارة الجمعية'))
                    created+=1
                con.commit()
            return self._send(201,{'created':created,'skipped':skipped,'message':'تم تسجيل الجوائز للطلبة المحددين دون تكرار الجوائز القائمة.'})
        if parsed.path == "/api/seating/generate":
            try: data=self._body(); group_id=int(data.get('group_id',0)); columns=int(data.get('columns',4))
            except (ValueError,TypeError): return self._error(400,'اختر الحلقة وعدد أعمدة صالحًا.')
            if not 2<=columns<=8: return self._error(400,'عدد الأعمدة يجب أن يكون بين 2 و8.')
            plan_name=str(data.get('plan_name','')).strip() or ('مخطط جلوس '+datetime.now().date().isoformat())
            with connect(self.server.db_path) as con:
                group=con.execute('SELECT id,name FROM groups WHERE id=? AND is_active=1',(group_id,)).fetchone()
                if not group: return self._error(400,'الحلقة غير موجودة أو غير نشطة.')
                rows=con.execute("SELECT s.id,s.student_code,s.first_name,s.last_name FROM enrollments e JOIN students s ON s.id=e.student_id WHERE e.group_id=? AND e.status='active' AND e.start_date<=? AND (e.end_date IS NULL OR e.end_date>=?) AND s.status='active' ORDER BY s.last_name,s.first_name",(group_id,datetime.now().date().isoformat(),datetime.now().date().isoformat())).fetchall()
                if not rows: return self._error(400,'لا يوجد طلبة نشطون مسجلون في هذه الحلقة.')
                roster=[dict(r) for r in rows]; random.SystemRandom().shuffle(roster)
                seating=[{'seat':i+1,'row':(i//columns)+1,'column':(i%columns)+1,'student_id':r['id'],'student_code':r['student_code'],'name':r['first_name']+' '+r['last_name']} for i,r in enumerate(roster)]
                cur=con.execute('INSERT INTO seating_plans(group_id,plan_name,seating_json) VALUES(?,?,?)',(group_id,plan_name,json.dumps({'columns':columns,'seats':seating},ensure_ascii=False)))
                con.commit()
            return self._send(201,{'id':cur.lastrowid,'plan_name':plan_name,'group_name':group['name'],'columns':columns,'students':len(seating),'seating':seating,'message':'تم إنشاء مخطط جلوس وحفظه محليًا.'})
        if parsed.path == "/api/documents/upload":
            try: data=self._body(); raw=base64.b64decode(data.get('file_base64',''),validate=True)
            except Exception: return self._error(400,'تعذر قراءة الملف المرفق.')
            filename=Path(str(data.get('filename','document'))).name
            ext=Path(filename).suffix.lower()
            if ext not in ('.pdf','.docx','.xlsx','.csv','.txt','.png','.jpg','.jpeg'):
                return self._error(400,'الصيغ المسموحة: PDF وDOCX وXLSX وCSV وTXT وPNG وJPG.')
            if not raw or len(raw)>10*1024*1024: return self._error(400,'الملف فارغ أو يتجاوز 10 ميغابايت.')
            folder=self.server.db_path.parent/'documents'; folder.mkdir(parents=True,exist_ok=True)
            safe_name=datetime.now().strftime('%Y%m%d_%H%M%S_%f')+'_'+filename
            target=folder/safe_name
            try: target.write_bytes(raw)
            except OSError: return self._error(500,'تعذر حفظ الملف في مجلد وثائق الجمعية.')
            title=str(data.get('title','')).strip() or Path(filename).stem; doc_type=str(data.get('document_type','general')).strip() or 'general'
            with connect(self.server.db_path) as con:
                cur=con.execute('INSERT INTO association_documents(title,document_type,document_date,reference_no,file_name,relative_path,summary,related_entity) VALUES(?,?,?,?,?,?,?,?)',(title,doc_type,str(data.get('document_date','')).strip() or None,str(data.get('reference_no','')).strip() or None,filename,str(Path('documents')/safe_name),str(data.get('summary','')).strip() or None,str(data.get('related_entity','')).strip() or None)); con.commit()
            return self._send(201,{'id':cur.lastrowid,'message':'تم حفظ الوثيقة محليًا وتسجيل بياناتها.','filename':filename})
        if parsed.path.startswith("/api/association/"):
            parts=parsed.path.removeprefix("/api/association/").strip("/").split("/")
            resource=parts[0]
            if resource not in RESOURCES: return self._error(404,"نوع السجل غير معروف.")
            try: data=self._body()
            except ValueError as exc: return self._error(400,str(exc))
            table,fields,required=RESOURCES[resource]
            entity_id=None
            if len(parts)>1:
                try: entity_id=int(parts[1])
                except ValueError: return self._error(400,"معرّف السجل غير صحيح.")
            with connect(self.server.db_path) as con:
                if data.get("action") in ("delete","archive"):
                    if not entity_id: return self._error(400,"حدد سجلًا واحدًا للحذف أو الأرشفة.")
                    row=con.execute("SELECT * FROM "+table+" WHERE id=?",(entity_id,)).fetchone()
                    if not row: return self._error(404,"السجل غير موجود.")
                    archiveable={'members','committees','assets','reports'}
                    if data.get("action")=="archive":
                        if resource not in archiveable: return self._error(400,"هذه الوحدة لا تدعم الأرشفة؛ يمكن حذف السجل فقط إذا لم تكن له علاقات تمنع ذلك.")
                        con.execute("UPDATE "+table+" SET status='archived' WHERE id=?",(entity_id,)); con.commit()
                        return self._send(200,{"message":"تمت أرشفة السجل مع الاحتفاظ به."})
                    if resource in ('transactions','asset_events'):
                        return self._error(409,"حُفظت الحركات المالية وسجلات العتاد التاريخية للتدقيق ولا تُحذف من الواجهة.")
                    try: con.execute("DELETE FROM "+table+" WHERE id=?",(entity_id,)); con.commit()
                    except sqlite3.IntegrityError: return self._error(409,"لا يمكن حذف السجل لوجود سجلات مرتبطة به؛ استخدم الأرشفة.")
                    return self._send(200,{"message":"تم حذف السجل."})
                try: values=normalize_payload(resource,data)
                except ValueError as exc: return self._error(400,str(exc))
                if resource=='transactions':
                    values['transaction_code']=values.get('transaction_code') or 'FIN-'+datetime.now().strftime('%Y%m%d%H%M%S%f')
                if resource=='members': values['member_code']=values.get('member_code') or 'MEM-'+datetime.now().strftime('%Y%m%d%H%M%S%f')
                if resource=='assets': values['asset_code']=values.get('asset_code') or 'AST-'+datetime.now().strftime('%Y%m%d%H%M%S%f')
                if resource=='meetings': values['meeting_code']=values.get('meeting_code') or 'MTG-'+datetime.now().strftime('%Y%m%d%H%M%S%f')
                cols=list(values)
                try:
                    if entity_id:
                        if not con.execute("SELECT 1 FROM "+table+" WHERE id=?",(entity_id,)).fetchone(): return self._error(404,"السجل غير موجود.")
                        con.execute("UPDATE "+table+" SET "+','.join(k+'=?' for k in cols)+" WHERE id=?",[values[k] for k in cols]+[entity_id]); con.commit()
                        return self._send(200,{"id":entity_id,"message":"تم تحديث السجل."})
                    cur=con.execute("INSERT INTO "+table+" ("+','.join(cols)+") VALUES ("+','.join('?' for _ in cols)+")",[values[k] for k in cols]); con.commit()
                    return self._send(201,{"id":cur.lastrowid,"message":"تم حفظ السجل."})
                except sqlite3.IntegrityError: return self._error(409,"تعذر الحفظ بسبب رمز مكرر أو علاقة غير صالحة.")
        if parsed.path in ("/api/import/preview","/api/import/commit"):
            try: data=self._body()
            except ValueError as exc: return self._error(400,str(exc))
            filename=str(data.get('filename','')); entity=str(data.get('entity','students')); encoded=data.get('file_base64','')
            if entity not in ('students','families','members','transactions','assets'): return self._error(400,'الاستيراد متاح حاليًا للطلبة والأسر والأعضاء والحركات المالية والعتاد.')
            try:
                raw=base64.b64decode(encoded,validate=True)
                matrix=read_tabular(filename,raw)
            except (ValueError,binascii.Error,UnicodeDecodeError,zipfile.BadZipFile,KeyError,ET.ParseError) as exc:
                return self._error(400,str(exc) or 'تعذر قراءة الملف.')
            if not matrix or len(matrix)<2: return self._error(400,'الملف فارغ أو لا يحتوي على صف عناوين وصف بيانات على الأقل.')
            headers=[str(x).strip() or ('عمود '+str(i+1)) for i,x in enumerate(matrix[0])]
            rows=[[str(x).strip() for x in row] for row in matrix[1:] if any(str(x).strip() for x in row)]
            if len(rows)>50000: return self._error(400,'الملف يحتوي أكثر من 50000 صف؛ قسّمه إلى ملفات أصغر.')
            allowed={'students':['student_code','first_name','last_name','birth_date','gender','student_category','status','family_id','notes'],
             'families':['family_code','father_first_name','father_last_name','father_phone','mother_first_name','mother_last_name','mother_phone','address'],
             'members':RESOURCES['members'][1], 'transactions':RESOURCES['transactions'][1], 'assets':RESOURCES['assets'][1]}[entity]
            def norm(x): return ''.join(ch for ch in str(x).lower().replace('أ','ا').replace('إ','ا').replace('آ','ا').replace('ى','ي') if ch.isalnum())
            aliases={'student_code':['studentcode','code','رقمالتسجيل','رمزالطالب','رقمالطالب','معرف'], 'first_name':['firstname','الاسم','الاسمالاول','الاسم الشخصي'], 'last_name':['lastname','surname','اللقب','العائلة'], 'birth_date':['birthdate','dateofbirth','تاريخالميلاد','الميلاد'], 'gender':['gender','الجنس','النوع'], 'student_category':['category','الفئة','طفلراشد'], 'phone':['phone','telephone','الهاتف','الهاتفالنقال'], 'father_first_name':['اسم الاب','الاب','fatherfirstname','اسمالاب'], 'father_last_name':['لقبالاب','fatherlastname'], 'mother_first_name':['اسمالام','motherfirstname'], 'mother_last_name':['لقبالام','motherlastname'], 'family_code':['familycode','رمزالاسرة','كودالاسرة'], 'transaction_date':['date','transactiondate','التاريخ','تاريخالعملية'], 'direction':['direction','النوع','دخلومصروف','نوعالحركة'], 'category':['category','الصنف','الفئة'], 'description':['description','الوصف','البيان'], 'amount':['amount','المبلغ','القيمة'], 'name':['name','الاسم','اسم'], 'asset_code':['assetcode','رمزالعتاد']}
            mapping=data.get('mapping') or {}
            if not mapping:
                mapping={}
                for field in allowed:
                    opts=[norm(field)]+[norm(a) for a in aliases.get(field,[])]
                    idx=next((i for i,h in enumerate(headers) if norm(h) in opts),None)
                    if idx is not None: mapping[field]=idx
            if parsed.path.endswith('/preview'):
                dup=[]
                with connect(self.server.db_path) as con:
                    for i,row in enumerate(rows[:1000],start=2):
                        def getv(field):
                            try: ix=int(mapping[field]); return row[ix].strip() if field in mapping and 0<=ix<len(row) else ''
                            except (ValueError,TypeError,KeyError): return ''
                        reason=None; vals=[]
                        if entity=='students':
                            code,first,last=getv('student_code'),getv('first_name'),getv('last_name'); vals=[code,first,last]
                            if code and con.execute('SELECT 1 FROM students WHERE student_code=?',(code,)).fetchone(): reason='رمز الطالب موجود مسبقًا'
                            elif first and last and con.execute('SELECT 1 FROM students WHERE search_key=?',(normalize_search(first+' '+last),)).fetchone(): reason='اسم مشابه موجود'
                        elif entity=='families':
                            code=getv('family_code'); name=' '.join(getv(k) for k in ('father_first_name','father_last_name','mother_first_name','mother_last_name')).strip(); vals=[code,name]
                            if code and con.execute('SELECT 1 FROM families WHERE family_code=?',(code,)).fetchone(): reason='رمز الأسرة موجود مسبقًا'
                            elif name and con.execute('SELECT 1 FROM families WHERE search_key=?',(normalize_search(name),)).fetchone(): reason='أسرة بأسماء مشابهة موجودة'
                        elif entity=='members':
                            code,first,last=getv('member_code'),getv('first_name'),getv('last_name'); vals=[code,first,last]
                            if code and con.execute('SELECT 1 FROM association_members WHERE member_code=?',(code,)).fetchone(): reason='رمز العضو موجود مسبقًا'
                            elif first and last and con.execute('SELECT 1 FROM association_members WHERE first_name=? AND last_name=?',(first,last)).fetchone(): reason='عضو بالاسم نفسه موجود'
                        elif entity=='transactions':
                            code,dateval,direction,amount,desc=getv('transaction_code'),getv('transaction_date'),getv('direction'),getv('amount'),getv('description'); vals=[code,dateval,direction,amount,desc]
                            if code and con.execute('SELECT 1 FROM association_transactions WHERE transaction_code=?',(code,)).fetchone(): reason='رمز الحركة المالية موجود'
                            elif dateval and amount and desc and con.execute('SELECT 1 FROM association_transactions WHERE transaction_date=? AND amount=? AND description=?',(dateval,amount,desc)).fetchone(): reason='حركة مشابهة موجودة؛ راجعها يدويًا'
                        elif entity=='assets':
                            code,name,serial=getv('asset_code'),getv('name'),getv('serial_number'); vals=[code,name,serial]
                            if code and con.execute('SELECT 1 FROM association_assets WHERE asset_code=?',(code,)).fetchone(): reason='رمز العتاد موجود'
                            elif name and con.execute('SELECT 1 FROM association_assets WHERE name=? AND COALESCE(serial_number,'')=COALESCE(?,'')',(name,serial)).fetchone(): reason='عتاد مشابه موجود'
                        if reason: dup.append({'row':i,'reason':reason,'values':vals})
                return self._send(200,{'entity':entity,'filename':filename,'headers':headers,'fields':allowed,'mapping':mapping,'row_count':len(rows),'preview':rows[:20],'duplicate_warnings':dup,'message':'المعاينة لا تحفظ أي بيانات.'})
            if not data.get('confirm'): return self._error(400,'أكد الاستيراد بعد مراجعة المعاينة.')
            imported=skipped=0; errors=[]
            with connect(self.server.db_path) as con:
                con.execute('BEGIN IMMEDIATE')
                for i,row in enumerate(rows, start=2):
                    values={}
                    for field,idx in mapping.items():
                        try: idx=int(idx); values[field]=row[idx].strip() if 0<=idx<len(row) else ''
                        except (ValueError,TypeError): values[field]=''
                        if field.endswith('_date') and values.get(field):
                            raw_date=values[field]
                            if raw_date.replace('.','',1).isdigit():
                                try:
                                    serial=float(raw_date)
                                    if 1 <= serial <= 100000: values[field]=(datetime(1899,12,30)+timedelta(days=serial)).date().isoformat()
                                except (ValueError,OverflowError): pass
                            elif '/' in raw_date:
                                for fmt in ('%d/%m/%Y','%Y/%m/%d'):
                                    try: values[field]=datetime.strptime(raw_date,fmt).date().isoformat(); break
                                    except ValueError: pass
                    try:
                        if entity=='students':
                            first=values.get('first_name','').strip(); last=values.get('last_name','').strip(); code=values.get('student_code','').strip(); gender=values.get('gender','').strip().lower()
                            gender={'ذكر':'male','انثى':'female','أنثى':'female','male':'male','female':'female','m':'male','f':'female'}.get(gender,gender)
                            if not first or not last or not code or gender not in ('male','female'): raise ValueError('الاسم واللقب ورمز الطالب والجنس حقول إلزامية')
                            if con.execute('SELECT 1 FROM students WHERE student_code=?',(code,)).fetchone() or con.execute('SELECT 1 FROM students WHERE search_key=?',(normalize_search(first+' '+last),)).fetchone(): skipped+=1; continue
                            birth=values.get('birth_date') or None
                            if birth and '/' in birth:
                                try: birth=datetime.strptime(birth,'%d/%m/%Y').date().isoformat()
                                except ValueError: pass
                            if birth: datetime.strptime(birth,'%Y-%m-%d')
                            category={'بالغ':'adult','راشد':'adult','adult':'adult','طفل':'child','child':'child'}.get(values.get('student_category','child').lower(),'child')
                            status=values.get('status') or 'active'
                            if status not in STATUSES-{'archived'}: status='active'
                            family_id=int(values['family_id']) if values.get('family_id','').isdigit() else None
                            if family_id and not con.execute("SELECT 1 FROM families WHERE id=? AND status='active'",(family_id,)).fetchone(): family_id=None
                            cur=con.execute('INSERT INTO students(student_code,first_name,last_name,birth_date,gender,student_category,status,family_id,notes,search_key) VALUES(?,?,?,?,?,?,?,?,?,?)',(code,first,last,birth,gender,category,status,family_id,values.get('notes') or None,normalize_search(first+' '+last)))
                            if family_id:
                                fam=con.execute('SELECT * FROM families WHERE id=?',(family_id,)).fetchone()
                                for rel,firstkey,lastkey,phonekey in [('father','father_first_name','father_last_name','father_phone'),('mother','mother_first_name','mother_last_name','mother_phone')]:
                                    if fam[firstkey] or fam[lastkey] or fam[phonekey]: con.execute('INSERT OR IGNORE INTO student_guardians(student_id,family_id,relationship,is_primary_contact) VALUES(?,?,?,?)',(cur.lastrowid,family_id,rel,1 if rel=='father' else 0))
                        elif entity=='families':
                            f={k:(values.get(k) or '').strip() or None for k in ['father_first_name','father_last_name','father_phone','mother_first_name','mother_last_name','mother_phone','address']}
                            if not any(f[k] for k in ('father_first_name','father_last_name','mother_first_name','mother_last_name')): raise ValueError('بيانات الأب أو الأم غير موجودة')
                            name=' '.join(f[k] or '' for k in ('father_first_name','father_last_name','mother_first_name','mother_last_name'))
                            if (values.get('family_code') and con.execute('SELECT 1 FROM families WHERE family_code=?',(values['family_code'],)).fetchone()) or con.execute('SELECT 1 FROM families WHERE search_key=?',(normalize_search(name),)).fetchone(): skipped+=1; continue
                            fid=values.get('family_code') or ('FAM-'+datetime.now().strftime('%Y%m%d%H%M%S%f')+str(i))
                            con.execute("INSERT INTO families(family_code,father_first_name,father_last_name,father_phone,mother_first_name,mother_last_name,mother_phone,address,search_key,status) VALUES(?,?,?,?,?,?,?,?,?,'active')",(fid,f['father_first_name'],f['father_last_name'],f['father_phone'],f['mother_first_name'],f['mother_last_name'],f['mother_phone'],f['address'],normalize_search(name)))
                        else:
                            payload=normalize_payload(entity,values); table,fields,_=RESOURCES[entity]
                            if entity=='members':
                                if (payload.get('member_code') and con.execute('SELECT 1 FROM association_members WHERE member_code=?',(payload['member_code'],)).fetchone()) or con.execute('SELECT 1 FROM association_members WHERE first_name=? AND last_name=?',(payload['first_name'],payload['last_name'])).fetchone(): skipped+=1; continue
                                payload['member_code']=payload.get('member_code') or 'MEM-IMPORT-'+datetime.now().strftime('%Y%m%d%H%M%S%f')+str(i)
                            if entity=='assets':
                                if (payload.get('asset_code') and con.execute('SELECT 1 FROM association_assets WHERE asset_code=?',(payload['asset_code'],)).fetchone()) or con.execute('SELECT 1 FROM association_assets WHERE name=? AND COALESCE(serial_number,'')=COALESCE(?,'')',(payload['name'],payload.get('serial_number'))).fetchone(): skipped+=1; continue
                                payload['asset_code']=payload.get('asset_code') or 'AST-IMPORT-'+datetime.now().strftime('%Y%m%d%H%M%S%f')+str(i)
                            if entity=='transactions':
                                if (payload.get('transaction_code') and con.execute('SELECT 1 FROM association_transactions WHERE transaction_code=?',(payload['transaction_code'],)).fetchone()) or con.execute('SELECT 1 FROM association_transactions WHERE transaction_date=? AND direction=? AND amount=? AND description=?',(payload['transaction_date'],payload['direction'],payload['amount'],payload['description'])).fetchone(): skipped+=1; continue
                                payload['transaction_code']=payload.get('transaction_code') or 'FIN-IMPORT-'+datetime.now().strftime('%Y%m%d%H%M%S%f')+str(i)
                            cols=list(payload); con.execute('INSERT INTO '+table+' ('+','.join(cols)+') VALUES ('+','.join('?' for _ in cols)+')',[payload[k] for k in cols])
                        imported+=1
                    except Exception as exc:
                        if len(errors)<100: errors.append({'row':i,'error':str(exc)[:180]})
                con.commit()
            return self._send(200,{'message':'اكتمل الاستيراد دون استبدال أي سجل قائم.','imported':imported,'skipped':skipped,'errors':errors,'error_count':len(errors)})
        if parsed.path == "/api/delete":
            try: data=self._body()
            except ValueError as exc: return self._error(400,str(exc))
            entity=data.get('entity'); ids=data.get('ids'); mode=data.get('mode','archive')
            valid_entities={'students','families',*RESOURCES.keys()}
            if entity not in valid_entities or not isinstance(ids,list) or not ids or len(ids)>500 or not data.get('confirm'): return self._error(400,'حدد سجلات صحيحة وأكد عملية الحذف أو الأرشفة.')
            if entity in ('transactions','asset_events') and mode=='delete': return self._error(409,'الحركات المالية وسجلات العتاد التاريخية لا تُحذف؛ استخدم حركة تصحيحية أو ملاحظة متابعة.')
            archiveable={'students','families','members','committees','assets','reports'}
            if mode=='archive' and entity not in archiveable: return self._error(400,'الأرشفة غير متاحة لهذه الوحدة؛ استخدم الحذف الفردي/الجماعي بعد مراجعة العلاقات.')
            try: ids=sorted(set(int(x) for x in ids))
            except (ValueError,TypeError): return self._error(400,'معرّفات السجلات غير صحيحة.')
            if mode not in ('archive','delete'): return self._error(400,'نوع العملية غير صحيح.')
            done=blocked=0; details=[]
            with connect(self.server.db_path) as con:
                con.execute('BEGIN IMMEDIATE')
                for rid in ids:
                    try:
                        if entity=='students':
                            row=con.execute('SELECT id,status FROM students WHERE id=?',(rid,)).fetchone()
                            if not row: blocked+=1; continue
                            if mode=='archive': con.execute("UPDATE students SET status='archived',updated_at=datetime('now') WHERE id=?",(rid,)); done+=1
                            else:
                                deps=con.execute('SELECT (SELECT COUNT(*) FROM enrollments WHERE student_id=?)+(SELECT COUNT(*) FROM attendance_records WHERE student_id=?)+(SELECT COUNT(*) FROM quran_learning_sessions WHERE student_id=?)',(rid,rid,rid)).fetchone()[0]
                                if deps: blocked+=1; details.append({'id':rid,'reason':'للطالب سجلات تاريخية مرتبطة؛ استخدم الأرشفة.'}); continue
                                con.execute('DELETE FROM students WHERE id=?',(rid,)); done+=1
                        elif entity=='families':
                            row=con.execute('SELECT id FROM families WHERE id=?',(rid,)).fetchone()
                            if not row: blocked+=1; continue
                            linked=con.execute('SELECT COUNT(*) FROM students WHERE family_id=?',(rid,)).fetchone()[0]
                            if mode=='delete' and linked: blocked+=1; details.append({'id':rid,'reason':'الأسرة مرتبطة بطلبة.'}); continue
                            if mode=='archive': con.execute("UPDATE families SET status='archived' WHERE id=?",(rid,)); done+=1
                            else: con.execute('DELETE FROM families WHERE id=?',(rid,)); done+=1
                        else:
                            table,fields,_=RESOURCES[entity]
                            if not con.execute('SELECT 1 FROM '+table+' WHERE id=?',(rid,)).fetchone(): blocked+=1; continue
                            if mode=='archive': con.execute("UPDATE "+table+" SET status='archived' WHERE id=?",(rid,)); done+=1
                            else:
                                if entity in ('transactions','asset_events'): blocked+=1; details.append({'id':rid,'reason':'سجل تاريخي محمي.'}); continue
                                con.execute('DELETE FROM '+table+' WHERE id=?',(rid,)); done+=1
                    except sqlite3.IntegrityError: blocked+=1; details.append({'id':rid,'reason':'توجد سجلات مرتبطة.'})
                con.execute('INSERT INTO deletion_batches(entity_type,record_ids,reason) VALUES(?,?,?)',(entity,json.dumps(ids),str(data.get('reason',''))[:300])); con.commit()
            return self._send(200,{'message':'اكتملت العملية مع الاحتفاظ بسجلها.','processed':done,'blocked':blocked,'details':details})
        if parsed.path == "/api/restore":
            try: data=self._body(); raw=base64.b64decode(data.get('file_base64',''),validate=True)
            except Exception: return self._error(400,'ملف النسخة الاحتياطية غير صالح.')
            if len(raw)>100*1024*1024: return self._error(400,'حجم النسخة المضغوطة يتجاوز 100 ميغابايت.')
            backup_dir=self.server.db_path.parent/'backups'; backup_dir.mkdir(parents=True,exist_ok=True)
            stamp=datetime.now().strftime('%Y%m%d%H%M%S%f'); tmp=backup_dir/('restore_check_'+stamp+'.sqlite3'); stage=backup_dir/('restore_stage_'+stamp)
            try:
                bundle_assets=[]
                if zipfile.is_zipfile(io.BytesIO(raw)):
                    stage.mkdir(parents=True,exist_ok=False)
                    with zipfile.ZipFile(io.BytesIO(raw)) as archive:
                        infos=archive.infolist()
                        if sum(x.file_size for x in infos)>250*1024*1024: return self._error(400,'محتوى الحزمة يتجاوز 250 ميغابايت بعد فك الضغط.')
                        allowed=[]
                        for info in infos:
                            name=Path(info.filename.replace('\\','/'))
                            if name.is_absolute() or '..' in name.parts or (name.parts and ':' in name.parts[0]): return self._error(400,'مسار ملف غير آمن داخل الحزمة.')
                            if info.filename=='school.sqlite3' or (name.parts and name.parts[0] in ('assets','documents')):
                                allowed.append(info)
                        dbinfo=next((x for x in allowed if x.filename=='school.sqlite3'),None)
                        if dbinfo is None: return self._error(400,'الحزمة لا تحتوي على school.sqlite3.')
                        for info in allowed:
                            target_path=stage/info.filename; target_path.parent.mkdir(parents=True,exist_ok=True)
                            with archive.open(info) as src, target_path.open('wb') as dst: shutil.copyfileobj(src,dst)
                        shutil.copy2(stage/'school.sqlite3',tmp)
                        bundle_assets=[x for x in ('assets','documents') if (stage/x).exists()]
                else: tmp.write_bytes(raw)
                test=sqlite3.connect(str(tmp)); check=test.execute('PRAGMA integrity_check').fetchone()[0]
                tables={r[0] for r in test.execute("SELECT name FROM sqlite_master WHERE type='table'")}; fks=test.execute('PRAGMA foreign_key_check').fetchall(); test.close()
                if check!='ok' or fks or not {'students','families','institution'}.issubset(tables): return self._error(400,'النسخة غير سليمة أو لا تخص قاعدة مِشكاة؛ لم يتم الاستبدال.')
                safety=backup_dir/('before_restore_'+datetime.now().strftime('%Y%m%d_%H%M%S')+'.sqlite3')
                src=sqlite3.connect(str(self.server.db_path)); dest=sqlite3.connect(str(safety))
                try: src.backup(dest)
                finally: dest.close(); src.close()
                src=sqlite3.connect(str(tmp)); dest=sqlite3.connect(str(self.server.db_path))
                try: src.backup(dest); dest.commit()
                finally: dest.close(); src.close()
                restored_files=[]
                for dirname in bundle_assets:
                    source=stage/dirname; destination=self.server.db_path.parent/dirname
                    if destination.exists():
                        previous=backup_dir/('pre_restore_'+dirname+'_'+stamp)
                        shutil.copytree(destination,previous,dirs_exist_ok=True)
                        shutil.rmtree(destination)
                    shutil.copytree(source,destination); restored_files.append(dirname)
                initialize_database(self.server.db_path)
                issues=validate_database(self.server.db_path)
                if issues:
                    src=sqlite3.connect(str(safety)); dest=sqlite3.connect(str(self.server.db_path))
                    try: src.backup(dest); dest.commit()
                    finally: dest.close(); src.close()
                    return self._error(500,'استعادة النسخة لم تجتز فحص قاعدة البيانات؛ أُعيدت نسخة الأمان السابقة.')
                return self._send(200,{'message':'تم التحقق من النسخة واستعادتها وترحيل مخططها عند الحاجة. أُنشئت نسخة أمان لقاعدة البيانات والملفات السابقة.','safety_backup':safety.name,'restored_files':restored_files})
            except Exception: return self._error(500,'فشلت الاستعادة؛ احتفظ بملف النسخة ولا تحذفه.')
            finally:
                tmp.unlink(missing_ok=True)
                if stage.exists(): shutil.rmtree(stage,ignore_errors=True)
        if parsed.path == "/api/institution":
            try:
                data = self._body()
            except ValueError as exc:
                return self._error(400, str(exc))
            official = str(data.get("official_name", "")).strip()
            branch = str(data.get("branch_name", "")).strip()
            supervisor = str(data.get("supervisor_name", "")).strip()
            address = str(data.get("address", "")).strip() or None
            phone = str(data.get("phone", "")).strip() or None
            if not official or not branch:
                return self._error(400, "اسم الجمعية واسم الشعبة حقلان إلزاميان.")
            if any(len(x) > 200 for x in (official, branch, supervisor)) or (address and len(address)>300) or (phone and len(phone)>40):
                return self._error(400, "تجاوز أحد الحقول الحد المسموح لطوله.")
            logo_relative_path = None
            logo_data = data.get("logo_data")
            if logo_data:
                if not isinstance(logo_data, str) or "," not in logo_data:
                    return self._error(400, "صيغة ملف الشعار غير صحيحة.")
                header, encoded = logo_data.split(",", 1)
                formats = {"data:image/png;base64": (".png", b"\x89PNG\r\n\x1a\n"), "data:image/jpeg;base64": (".jpg", b"\xff\xd8\xff"), "data:image/webp;base64": (".webp", b"RIFF")}
                if header not in formats:
                    return self._error(400, "الشعار يجب أن يكون PNG أو JPEG أو WEBP.")
                try:
                    raw_logo = base64.b64decode(encoded, validate=True)
                except (binascii.Error, ValueError):
                    return self._error(400, "تعذر قراءة ملف الشعار.")
                suffix, signature = formats[header]
                valid_image = raw_logo.startswith(signature) and len(raw_logo) <= 512 * 1024 and len(raw_logo) >= 16
                if header == "data:image/png;base64":
                    valid_image = valid_image and len(raw_logo) >= 24 and raw_logo[12:16] == b"IHDR" and int.from_bytes(raw_logo[16:20], "big") > 0 and int.from_bytes(raw_logo[20:24], "big") > 0
                elif header == "data:image/webp;base64":
                    valid_image = valid_image and len(raw_logo) >= 12 and raw_logo[8:12] == b"WEBP"
                if not valid_image:
                    return self._error(400, "ملف الشعار غير صالح أو يتجاوز 512 كيلوبايت.")
                assets = self.server.db_path.parent / "assets"
                assets.mkdir(parents=True, exist_ok=True)
                target = assets / ("association_logo" + suffix)
                target.write_bytes(raw_logo)
                logo_relative_path = str(Path("assets") / target.name)
            with connect(self.server.db_path) as con:
                if logo_relative_path:
                    con.execute("UPDATE institution SET official_name=?,branch_name=?,supervisor_name=?,address=?,phone=?,logo_relative_path=? WHERE id=1", (official,branch,supervisor,address,phone,logo_relative_path))
                else:
                    con.execute("UPDATE institution SET official_name=?,branch_name=?,supervisor_name=?,address=?,phone=? WHERE id=1", (official,branch,supervisor,address,phone))
                con.commit()
            return self._send(200, {"message":"تم حفظ بيانات واجهة الاستقبال.","official_name":official,"branch_name":branch,"supervisor_name":supervisor})
        if parsed.path == "/api/families":
            try:
                data = self._body()
            except ValueError as exc:
                return self._error(400, str(exc))
            fields = {k: str(data.get(k, "")).strip() or None for k in ("father_first_name","father_last_name","father_phone","mother_first_name","mother_last_name","mother_phone","address")}
            if not any(fields[k] for k in ("father_first_name","father_last_name","mother_first_name","mother_last_name")):
                return self._error(400, "أدخل اسمًا واحدًا على الأقل للأب أو الأم لتحديد الأسرة.")
            if any(v and len(v)>300 for v in fields.values()):
                return self._error(400, "تجاوز أحد الحقول الحد المسموح لطوله.")
            names = " ".join(fields[k] or "" for k in ("father_first_name","father_last_name","mother_first_name","mother_last_name"))
            with connect(self.server.db_path) as con:
                con.execute("BEGIN IMMEDIATE")
                next_id = con.execute("SELECT COALESCE(MAX(id),0)+1 FROM families").fetchone()[0]
                family_code = "FAM-{0:06d}".format(next_id)
                try:
                    cur = con.execute("""INSERT INTO families(family_code,father_first_name,father_last_name,father_phone,mother_first_name,mother_last_name,mother_phone,address,search_key,status)
                        VALUES(?,?,?,?,?,?,?,?,?,'active')""", (family_code,fields['father_first_name'],fields['father_last_name'],fields['father_phone'],fields['mother_first_name'],fields['mother_last_name'],fields['mother_phone'],fields['address'],normalize_search(names)))
                    fid = cur.lastrowid
                    if con.execute("SELECT 1 FROM sqlite_master WHERE type='table' AND name='audit_log'").fetchone():
                        con.execute("INSERT INTO audit_log(action,entity_type,entity_id,details) VALUES('create','family',?,?)", (str(fid), json.dumps({"family_code":family_code},ensure_ascii=False)))
                    con.commit()
                except __import__('sqlite3').IntegrityError:
                    con.rollback()
                    return self._error(409, "تعذر إنشاء الأسرة بسبب تعارض في رمزها؛ أعد المحاولة.")
            return self._send(201, {"id":fid,"family_code":family_code,"message":"تم تسجيل الأسرة."})
        if parsed.path.startswith("/api/families/"):
            family_id_text = parsed.path.rsplit("/",1)[-1]
            try:
                family_id = int(family_id_text)
                data = self._body()
            except (ValueError, TypeError) as exc:
                return self._error(400, "معرّف الأسرة أو البيانات غير صحيحة.")
            action = data.get("action", "update")
            with connect(self.server.db_path) as con:
                row = con.execute("SELECT * FROM families WHERE id=?", (family_id,)).fetchone()
                if row is None:
                    return self._error(404, "الأسرة غير موجودة.")
                if action == "archive":
                    con.execute("UPDATE families SET status='archived',updated_at=datetime('now') WHERE id=?", (family_id,))
                    con.commit()
                    return self._send(200, {"message":"تمت أرشفة الأسرة دون حذف بياناتها."})
                if action == "delete":
                    if data.get("confirm") is not True:
                        return self._error(400, "الحذف النهائي يتطلب تأكيدًا صريحًا.")
                    linked = con.execute("SELECT COUNT(*) FROM students WHERE family_id=?", (family_id,)).fetchone()[0]
                    if linked:
                        return self._error(409, "لا يمكن حذف أسرة مرتبطة بطلبة؛ استخدم الأرشفة.")
                    con.execute("DELETE FROM families WHERE id=?", (family_id,))
                    con.commit()
                    return self._send(200, {"message":"تم حذف الأسرة غير المرتبطة بطلبة."})
                fields = {k: str(data.get(k, row[k] or "")).strip() or None for k in ("father_first_name","father_last_name","father_phone","mother_first_name","mother_last_name","mother_phone","address")}
                names = " ".join(fields[k] or "" for k in ("father_first_name","father_last_name","mother_first_name","mother_last_name"))
                con.execute("""UPDATE families SET father_first_name=?,father_last_name=?,father_phone=?,mother_first_name=?,mother_last_name=?,mother_phone=?,address=?,search_key=?,updated_at=datetime('now') WHERE id=?""", (fields['father_first_name'],fields['father_last_name'],fields['father_phone'],fields['mother_first_name'],fields['mother_last_name'],fields['mother_phone'],fields['address'],normalize_search(names),family_id))
                con.commit()
            return self._send(200, {"message":"تم تحديث بيانات الأسرة."})
        # Teacher, level, group and enrollment writes are validated server-side.
        try:
            if parsed.path == "/api/attendance":
                data = self._body()
                try:
                    group_id = int(data.get("group_id", 0))
                    session_date = str(data.get("session_date", "")).strip()
                    datetime.strptime(session_date, "%Y-%m-%d")
                except (TypeError, ValueError):
                    return self._error(400, "اختر حلقة وتاريخًا صحيحين.")
                records = data.get("records", [])
                if not isinstance(records, list) or len(records) > 1000:
                    return self._error(400, "قائمة الحضور غير صالحة أو طويلة جدًا.")
                allowed = {"present", "absent", "excused", "late", "left_early"}
                teacher_raw = data.get("teacher_id")
                try:
                    teacher_id = int(teacher_raw) if str(teacher_raw or "").strip() else None
                except (TypeError, ValueError):
                    return self._error(400, "معرّف المعلم غير صحيح.")
                label = str(data.get("session_label", "")).strip() or None
                notes = str(data.get("notes", "")).strip() or None
                if label and len(label) > 150 or notes and len(notes) > 2000:
                    return self._error(400, "تجاوز عنوان الحصة أو الملاحظات الحد المسموح.")
                seen = set()
                normalized = []
                for record in records:
                    if not isinstance(record, dict):
                        return self._error(400, "يوجد سجل حضور غير صالح.")
                    try:
                        sid = int(record.get("student_id", 0))
                    except (TypeError, ValueError):
                        return self._error(400, "معرّف الطالب غير صحيح.")
                    status = str(record.get("status", "")).strip()
                    reason = str(record.get("reason", "")).strip() or None
                    rec_notes = str(record.get("notes", "")).strip() or None
                    if sid in seen:
                        return self._error(400, "تكرر الطالب أكثر من مرة في قائمة الحضور.")
                    seen.add(sid)
                    if status not in allowed:
                        return self._error(400, "حدد حالة صحيحة لكل طالب قبل الحفظ.")
                    if reason and len(reason) > 300 or rec_notes and len(rec_notes) > 1000:
                        return self._error(400, "تجاوز سبب الغياب أو الملاحظات الحد المسموح.")
                    normalized.append((sid, status, reason, rec_notes))
                with connect(self.server.db_path) as con:
                    group = con.execute("SELECT id,teacher_id,is_active FROM groups WHERE id=?", (group_id,)).fetchone()
                    if not group:
                        return self._error(404, "الحلقة غير موجودة.")
                    session = con.execute("SELECT * FROM attendance_sessions WHERE group_id=? AND session_date=?", (group_id, session_date)).fetchone()
                    action = str(data.get("action", "save"))
                    if session and session["is_closed"]:
                        return self._error(409, "سجل الحضور مغلق ولا يقبل التعديل.")
                    if teacher_id is not None and not con.execute("SELECT 1 FROM teachers WHERE id=? AND is_active=1", (teacher_id,)).fetchone():
                        return self._error(400, "المعلم المحدد غير موجود أو غير نشط.")
                    roster_rows = con.execute("""SELECT e.student_id FROM enrollments e
                        JOIN students s ON s.id=e.student_id
                        WHERE e.group_id=? AND e.start_date<=? AND (e.end_date IS NULL OR e.end_date>=?)""", (group_id, session_date, session_date)).fetchall()
                    roster_ids = {r[0] for r in roster_rows}
                    if not roster_ids:
                        return self._error(409, "لا يوجد طلبة مسجلون في هذه الحلقة خلال التاريخ المحدد.")
                    if seen - roster_ids:
                        return self._error(400, "تحتوي القائمة على طلبة غير مسجلين في الحلقة في هذا التاريخ.")
                    if action == "close" and session is None:
                        return self._error(409, "احفظ سجل الحضور أولًا قبل إغلاقه.")
                    if action == "close":
                        count = con.execute("SELECT COUNT(*) FROM attendance_records WHERE session_id=?", (session["id"],)).fetchone()[0]
                        if count != len(roster_ids):
                            return self._error(409, "لا يمكن إغلاق الحضور قبل تسجيل حالة كل طالب.")
                        con.execute("UPDATE attendance_sessions SET is_closed=1 WHERE id=?", (session["id"],))
                        con.commit()
                        return self._send(200, {"message": "أُغلق سجل الحضور. لن يقبل التعديل بعد الآن."})
                    if not records:
                        return self._error(400, "لا توجد سجلات حضور لحفظها.")
                    if session is None:
                        cur = con.execute("INSERT INTO attendance_sessions(group_id,teacher_id,session_date,session_label,notes) VALUES(?,?,?,?,?)", (group_id, teacher_id or group["teacher_id"], session_date, label, notes))
                        session_id = cur.lastrowid
                    else:
                        session_id = session["id"]
                        con.execute("UPDATE attendance_sessions SET teacher_id=?,session_label=?,notes=? WHERE id=?", (teacher_id or group["teacher_id"], label, notes, session_id))
                    for sid, status, reason, rec_notes in normalized:
                        con.execute("""INSERT INTO attendance_records(session_id,student_id,status,reason,notes)
                            VALUES(?,?,?,?,?) ON CONFLICT(session_id,student_id) DO UPDATE SET
                            status=excluded.status,reason=excluded.reason,notes=excluded.notes,updated_at=datetime('now')""", (session_id,sid,status,reason,rec_notes))
                    if con.execute("SELECT 1 FROM sqlite_master WHERE type='table' AND name='audit_log'").fetchone():
                        con.execute("INSERT INTO audit_log(action,entity_type,entity_id,details) VALUES('save_attendance','attendance_session',?,?)", (str(session_id), json.dumps({"group_id":group_id,"date":session_date,"count":len(normalized)},ensure_ascii=False)))
                    con.commit()
                return self._send(201 if not session else 200, {"id":session_id,"message":"تم حفظ سجل الحضور بنجاح.","saved_records":len(normalized)})
            if parsed.path == "/api/memorization":
                data = self._body()
                try:
                    student_id = int(data.get("student_id", 0))
                    teacher_id = int(data["teacher_id"]) if str(data.get("teacher_id", "")).strip() else None
                    group_id = int(data["group_id"]) if str(data.get("group_id", "")).strip() else None
                    start_surah = int(data.get("start_surah", 0)); start_ayah = int(data.get("start_ayah", 0))
                    end_surah = int(data.get("end_surah", 0)); end_ayah = int(data.get("end_ayah", 0))
                    score = float(data.get("score", -1)); mistakes = int(data.get("mistake_count", -1))
                except (ValueError, TypeError): return self._error(400, "تحقق من الطالب والسورة والآيات والدرجة وعدد الأخطاء.")
                work_type = str(data.get("work_type", "")).strip()
                decision = str(data.get("decision", "")).strip()
                session_date = str(data.get("session_date", datetime.now().date().isoformat())).strip()
                notes = str(data.get("notes", "")).strip() or None
                session_notes = str(data.get("session_notes", "")).strip() or None
                if work_type not in {"new_memorization", "recent_revision", "cumulative_revision"}: return self._error(400, "نوع العمل القرآني غير صحيح.")
                if decision not in {"accepted", "retry", "deferred"}: return self._error(400, "قرار المعلم غير صحيح.")
                if not (0 <= score <= 10) or not (0 <= mistakes <= 10000): return self._error(400, "الدرجة يجب أن تكون من 0 إلى 10 وعدد الأخطاء غير سالب.")
                if any(len(x or "") > 2000 for x in (notes, session_notes)): return self._error(400, "الملاحظات أطول من الحد المسموح.")
                try: datetime.strptime(session_date, "%Y-%m-%d")
                except ValueError: return self._error(400, "تاريخ التسميع غير صحيح.")
                with connect(self.server.db_path) as con:
                    student = con.execute("SELECT id,status FROM students WHERE id=?", (student_id,)).fetchone()
                    if not student or student["status"] != "active": return self._error(400, "الطالب غير موجود أو غير نشط.")
                    start = con.execute("SELECT surah_number,ayah_count FROM quran_surahs WHERE surah_number=?", (start_surah,)).fetchone()
                    end = con.execute("SELECT surah_number,ayah_count FROM quran_surahs WHERE surah_number=?", (end_surah,)).fetchone()
                    if not start or not end: return self._error(400, "رقم السورة خارج النطاق الصحيح (1–114).")
                    if not (1 <= start_ayah <= start["ayah_count"]) or not (1 <= end_ayah <= end["ayah_count"]): return self._error(400, "رقم الآية يتجاوز عدد آيات السورة المحددة.")
                    if end_surah < start_surah or (end_surah == start_surah and end_ayah < start_ayah): return self._error(400, "نهاية المقطع تسبق بدايته.")
                    if teacher_id is not None and not con.execute("SELECT 1 FROM teachers WHERE id=? AND is_active=1", (teacher_id,)).fetchone(): return self._error(400, "المعلم المحدد غير موجود أو غير نشط.")
                    if group_id is not None and not con.execute("SELECT 1 FROM groups WHERE id=? AND is_active=1", (group_id,)).fetchone(): return self._error(400, "الحلقة المحددة غير موجودة أو غير نشطة.")
                    con.execute("BEGIN IMMEDIATE")
                    session = con.execute("SELECT id FROM quran_learning_sessions WHERE student_id=? AND session_date=?", (student_id, session_date)).fetchone()
                    if session:
                        session_id = session["id"]
                        con.execute("UPDATE quran_learning_sessions SET teacher_id=COALESCE(?,teacher_id),group_id=COALESCE(?,group_id),notes=COALESCE(?,notes) WHERE id=?", (teacher_id,group_id,session_notes,session_id))
                    else:
                        cur = con.execute("INSERT INTO quran_learning_sessions(student_id,teacher_id,group_id,session_date,notes) VALUES(?,?,?,?,?)", (student_id,teacher_id,group_id,session_date,session_notes))
                        session_id = cur.lastrowid
                    cur = con.execute("INSERT INTO quran_learning_entries(session_id,work_type,start_surah,start_ayah,end_surah,end_ayah,score,mistake_count,decision,notes) VALUES(?,?,?,?,?,?,?,?,?,?)", (session_id,work_type,start_surah,start_ayah,end_surah,end_ayah,score,mistakes,decision,notes))
                    entry_id = cur.lastrowid
                    con.execute("INSERT INTO audit_log(action,entity_type,entity_id,details) VALUES('create_quran_entry','quran_learning_entry',?,?)", (str(entry_id), json.dumps({"student_id":student_id,"date":session_date,"work_type":work_type,"decision":decision},ensure_ascii=False)))
                    con.commit()
                return self._send(201, {"id": entry_id, "session_id": session_id, "message": "تم حفظ سجل الحفظ/المراجعة والتقييم."})
            if parsed.path == "/api/teachers" or parsed.path.startswith("/api/teachers/"):
                data = self._body()
                suffix = parsed.path.removeprefix("/api/teachers").strip("/")
                with connect(self.server.db_path) as con:
                    if suffix:
                        try: entity_id = int(suffix)
                        except ValueError: return self._error(400, "معرّف المعلم غير صالح.")
                        row = con.execute("SELECT * FROM teachers WHERE id=?", (entity_id,)).fetchone()
                        if not row: return self._error(404, "المعلم غير موجود.")
                        if data.get("action") in ("deactivate", "activate"):
                            active = 0 if data["action"] == "deactivate" else 1
                            con.execute("UPDATE teachers SET is_active=? WHERE id=?", (active, entity_id))
                            con.commit()
                            return self._send(200, {"message": "تم تحديث حالة المعلم."})
                        code = str(data.get("teacher_code", row["teacher_code"])).strip()
                        first = str(data.get("first_name", row["first_name"])).strip()
                        last = str(data.get("last_name", row["last_name"])).strip()
                        phone = str(data.get("phone", row["phone"] or "")).strip() or None
                        specialty = str(data.get("specialty", row["specialty"] or "")).strip() or None
                        notes = str(data.get("notes", row["notes"] or "")).strip() or None
                        active = 1 if data.get("is_active", row["is_active"]) in (1, True, "1", "true") else 0
                        if not code or not first or not last: return self._error(400, "رمز المعلم والاسم واللقب إلزامية.")
                        if max(map(len, (code, first, last, phone or "", specialty or "", notes or ""))) > 200: return self._error(400, "أحد الحقول أطول من الحد المسموح.")
                        try:
                            con.execute("UPDATE teachers SET teacher_code=?,first_name=?,last_name=?,phone=?,specialty=?,notes=?,is_active=? WHERE id=?", (code,first,last,phone,specialty,notes,active,entity_id))
                            con.commit()
                        except __import__('sqlite3').IntegrityError: return self._error(409, "رمز المعلم مستخدم مسبقًا.")
                        return self._send(200, {"id": entity_id, "message": "تم تحديث بيانات المعلم."})
                    code = str(data.get("teacher_code", "")).strip(); first = str(data.get("first_name", "")).strip(); last = str(data.get("last_name", "")).strip()
                    phone = str(data.get("phone", "")).strip() or None; specialty = str(data.get("specialty", "")).strip() or None; notes = str(data.get("notes", "")).strip() or None
                    if not code or not first or not last: return self._error(400, "رمز المعلم والاسم واللقب إلزامية.")
                    if max(map(len, (code, first, last, phone or "", specialty or "", notes or ""))) > 200: return self._error(400, "أحد الحقول أطول من الحد المسموح.")
                    try:
                        cur = con.execute("INSERT INTO teachers(teacher_code,first_name,last_name,phone,specialty,notes) VALUES(?,?,?,?,?,?)", (code,first,last,phone,specialty,notes)); con.commit()
                    except __import__('sqlite3').IntegrityError: return self._error(409, "رمز المعلم مستخدم مسبقًا.")
                    return self._send(201, {"id": cur.lastrowid, "message": "تم تسجيل المعلم."})
            if parsed.path == "/api/levels" or parsed.path.startswith("/api/levels/"):
                data = self._body(); suffix = parsed.path.removeprefix("/api/levels").strip("/")
                with connect(self.server.db_path) as con:
                    if suffix:
                        try: entity_id = int(suffix)
                        except ValueError: return self._error(400, "معرّف المستوى غير صالح.")
                        row = con.execute("SELECT * FROM levels WHERE id=?", (entity_id,)).fetchone()
                        if not row: return self._error(404, "المستوى غير موجود.")
                        if data.get("action") in ("deactivate", "activate"):
                            active = 0 if data["action"] == "deactivate" else 1
                            con.execute("UPDATE levels SET is_active=? WHERE id=?", (active, entity_id)); con.commit()
                            return self._send(200, {"message": "تم تحديث حالة المستوى."})
                        name = str(data.get("name", row["name"])).strip(); description = str(data.get("description", row["description"] or "")).strip() or None
                        try: min_age = int(data.get("min_age")) if str(data.get("min_age", row["min_age"] if row["min_age"] is not None else "")).strip() else None; max_age = int(data.get("max_age")) if str(data.get("max_age", row["max_age"] if row["max_age"] is not None else "")).strip() else None
                        except (ValueError, TypeError): return self._error(400, "العمر يجب أن يكون عددًا صحيحًا.")
                        if not name or len(name)>100 or (min_age is not None and min_age<0) or (max_age is not None and max_age<0) or (min_age is not None and max_age is not None and min_age>max_age): return self._error(400, "بيانات المستوى أو نطاق الأعمار غير صحيحة.")
                        try: con.execute("UPDATE levels SET name=?,description=?,min_age=?,max_age=? WHERE id=?", (name,description,min_age,max_age,entity_id)); con.commit()
                        except __import__('sqlite3').IntegrityError: return self._error(409, "اسم المستوى مستخدم مسبقًا.")
                        return self._send(200, {"id": entity_id, "message": "تم تحديث المستوى."})
                    name = str(data.get("name", "")).strip(); description = str(data.get("description", "")).strip() or None
                    try: min_age = int(data["min_age"]) if str(data.get("min_age", "")).strip() else None; max_age = int(data["max_age"]) if str(data.get("max_age", "")).strip() else None
                    except (ValueError, TypeError): return self._error(400, "العمر يجب أن يكون عددًا صحيحًا.")
                    if not name or len(name)>100 or (min_age is not None and min_age<0) or (max_age is not None and max_age<0) or (min_age is not None and max_age is not None and min_age>max_age): return self._error(400, "اسم المستوى ونطاق الأعمار غير صحيح.")
                    try: cur = con.execute("INSERT INTO levels(name,description,min_age,max_age) VALUES(?,?,?,?)", (name,description,min_age,max_age)); con.commit()
                    except __import__('sqlite3').IntegrityError: return self._error(409, "اسم المستوى مستخدم مسبقًا.")
                    return self._send(201, {"id": cur.lastrowid, "message": "تم تسجيل المستوى."})
            if parsed.path == "/api/groups" or parsed.path.startswith("/api/groups/"):
                data = self._body(); suffix = parsed.path.removeprefix("/api/groups").strip("/")
                with connect(self.server.db_path) as con:
                    if suffix:
                        try: entity_id = int(suffix)
                        except ValueError: return self._error(400, "معرّف الحلقة غير صالح.")
                        row = con.execute("SELECT * FROM groups WHERE id=?", (entity_id,)).fetchone()
                        if not row: return self._error(404, "الحلقة غير موجودة.")
                        if data.get("action") in ("deactivate", "activate"):
                            active = 0 if data["action"] == "deactivate" else 1
                            con.execute("UPDATE groups SET is_active=? WHERE id=?", (active, entity_id)); con.commit()
                            return self._send(200, {"message": "تم تحديث حالة الحلقة."})
                        values = self._group_values(data, row)
                        if isinstance(values, tuple) and values and values[0] == "ERROR": return self._error(values[1], values[2])
                        try: con.execute("UPDATE groups SET group_code=?,name=?,level_id=?,teacher_id=?,target_gender=?,min_age=?,max_age=?,schedule_text=?,is_active=? WHERE id=?", (*values, entity_id)); con.commit()
                        except __import__('sqlite3').IntegrityError: return self._error(409, "رمز الحلقة مستخدم أو توجد علاقة غير صالحة.")
                        return self._send(200, {"id": entity_id, "message": "تم تحديث بيانات الحلقة."})
                    values = self._group_values(data)
                    if isinstance(values, tuple) and values and values[0] == "ERROR": return self._error(values[1], values[2])
                    try: cur = con.execute("INSERT INTO groups(group_code,name,level_id,teacher_id,target_gender,min_age,max_age,schedule_text,is_active) VALUES(?,?,?,?,?,?,?,?,?)", values); con.commit()
                    except __import__('sqlite3').IntegrityError: return self._error(409, "رمز الحلقة مستخدم أو توجد علاقة غير صالحة.")
                    return self._send(201, {"id": cur.lastrowid, "message": "تم تسجيل الحلقة."})
            if parsed.path == "/api/enrollments":
                data = self._body()
                try: student_id = int(data.get("student_id", 0)); group_id = int(data.get("group_id", 0))
                except (TypeError, ValueError): return self._error(400, "اختر طالبًا وحلقة صحيحة.")
                action = data.get("action", "enroll")
                with connect(self.server.db_path) as con:
                    if action == "withdraw":
                        try: enrollment_id = int(data.get("enrollment_id", 0))
                        except (TypeError, ValueError): return self._error(400, "معرّف التسجيل غير صحيح.")
                        row = con.execute("SELECT id FROM enrollments WHERE id=? AND status='active'", (enrollment_id,)).fetchone()
                        if not row: return self._error(404, "التسجيل النشط غير موجود.")
                        con.execute("UPDATE enrollments SET status='withdrawn',end_date=? WHERE id=?", (datetime.now().date().isoformat(), enrollment_id)); con.commit()
                        return self._send(200, {"message": "تم إنهاء تسجيل الطالب في الحلقة مع الاحتفاظ بالسجل."})
                    student = con.execute("SELECT id,status FROM students WHERE id=?", (student_id,)).fetchone()
                    group = con.execute("SELECT id,is_active FROM groups WHERE id=?", (group_id,)).fetchone()
                    if not student or student["status"] != "active": return self._error(400, "الطالب غير موجود أو غير نشط.")
                    if not group or not group["is_active"]: return self._error(400, "الحلقة غير موجودة أو غير نشطة.")
                    existing = con.execute("SELECT id,group_id FROM enrollments WHERE student_id=? AND status='active'", (student_id,)).fetchone()
                    if existing: return self._error(409, "للطالب تسجيل نشط بالفعل في حلقة؛ أنهِ التسجيل السابق أولًا.")
                    start_date = str(data.get("start_date", datetime.now().date().isoformat())).strip()
                    try: datetime.strptime(start_date, "%Y-%m-%d")
                    except ValueError: return self._error(400, "تاريخ بداية التسجيل غير صحيح.")
                    notes = str(data.get("notes", "")).strip() or None
                    if notes and len(notes)>1000: return self._error(400, "الملاحظات طويلة أكثر من المسموح.")
                    cur = con.execute("INSERT INTO enrollments(student_id,group_id,start_date,status,notes) VALUES(?,?,?,'active',?)", (student_id,group_id,start_date,notes)); con.commit()
                    return self._send(201, {"id": cur.lastrowid, "message": "تم ربط الطالب بالحلقة."})
        except Exception:
            return self._error(500, "تعذر تنفيذ العملية بسبب خطأ داخلي؛ لم يتم تأكيد الحفظ.")
        if parsed.path == "/api/backup":
            try: backup_request = self._body()
            except ValueError as exc: return self._error(400, str(exc))
            stamp = datetime.now().strftime("%Y%m%d_%H%M%S")
            destination_type = str(backup_request.get("destination_type", "local"))
            if destination_type not in ("local", "usb", "external_drive"):
                return self._error(400, "اختر وجهة محلية أو USB أو قرصًا خارجيًا.")
            raw_destination = str(backup_request.get("destination_path", "")).strip()
            if raw_destination:
                destination = Path(raw_destination).expanduser()
                if not destination.is_absolute(): return self._error(400, "مسار النسخ يجب أن يكون مسارًا كاملًا.")
                backup_dir = destination
            else:
                if destination_type != "local": return self._error(400, "اختر مسار USB أو القرص الخارجي صراحةً.")
                backup_dir = self.server.db_path.parent / "backups"
            try: backup_dir.mkdir(parents=True, exist_ok=True)
            except OSError: return self._error(400, "تعذر الوصول إلى وجهة النسخ المختارة.")
            if not backup_dir.is_dir(): return self._error(400, "وجهة النسخ ليست مجلدًا.")
            target = backup_dir / f"school_backup_{stamp}.sqlite3"
            if target.exists() or target.with_suffix('.zip').exists():
                return self._error(409, "ملف النسخة الاحتياطية موجود مسبقًا؛ لم يتم استبداله.")
            try:
                with connect(self.server.db_path) as con:
                    result = con.execute("PRAGMA integrity_check").fetchone()[0]
                    fk = con.execute("PRAGMA foreign_key_check").fetchall()
                    if result != "ok" or fk:
                        return self._error(409, "قاعدة البيانات لم تجتز فحص السلامة؛ لم يتم إنشاء نسخة.")
                    dest = __import__('sqlite3').connect(str(target))
                    try:
                        con.backup(dest)
                    finally:
                        dest.close()
                # Verify the produced backup before reporting success.
                test = __import__('sqlite3').connect(str(target))
                try:
                    check = test.execute("PRAGMA integrity_check").fetchone()[0]
                finally:
                    test.close()
                if check != "ok":
                    target.unlink(missing_ok=True)
                    return self._error(500, "فشل التحقق من النسخة؛ حُذف الملف غير السليم.")
                bundle_target = target.with_suffix('.zip')
                if bundle_target.exists(): return self._error(409, "ملف حزمة النسخة موجود مسبقًا؛ لم يتم استبداله.")
                with zipfile.ZipFile(bundle_target, 'w', compression=zipfile.ZIP_DEFLATED) as archive:
                    archive.write(target, arcname='school.sqlite3')
                    for dirname in ('assets','documents'):
                        folder=self.server.db_path.parent/dirname
                        if folder.exists():
                            for child in folder.rglob('*'):
                                if child.is_file(): archive.write(child,arcname=str(Path(dirname)/child.relative_to(folder)))
                # The standalone SQLite file is retained alongside the portable bundle.
                with connect(self.server.db_path) as con:
                    if con.execute("SELECT 1 FROM sqlite_master WHERE type='table' AND name='backup_history'").fetchone():
                        con.execute("INSERT INTO backup_history(destination_type,destination_path,size_bytes,result,details) VALUES(?,?,?,?,?)", (destination_type, str(bundle_target), bundle_target.stat().st_size, "verified", "حزمة تتضمن قاعدة SQLite والملفات المحلية assets/documents؛ نوع الوجهة اختاره المستخدم."))
                return self._send(201, {"message": "تم إنشاء حزمة احتياطية والتحقق من قاعدة البيانات. تتضمن الشعار والوثائق المحلية عند وجودها.", "filename": bundle_target.name, "path": str(bundle_target), "database_file": target.name})
            except Exception:
                target.unlink(missing_ok=True)
                return self._error(500, "تعذر إنشاء النسخة الاحتياطية. راجع صلاحيات مجلد البيانات.")
        if parsed.path != "/api/students":
            return self._error(404, "المسار المطلوب غير موجود.")
        try:
            data = self._body()
        except ValueError as exc:
            return self._error(400, str(exc))
        first = str(data.get("first_name", "")).strip()
        last = str(data.get("last_name", "")).strip()
        code = str(data.get("student_code", "")).strip()
        birth = str(data.get("birth_date", "")).strip() or None
        gender = data.get("gender")
        category = data.get("student_category", "child")
        status = data.get("status", "active")
        notes = str(data.get("notes", "")).strip() or None
        family_id_raw = str(data.get("family_id", "")).strip()
        family_id = None
        if family_id_raw:
            try:
                family_id = int(family_id_raw)
            except ValueError:
                return self._error(400, "اختيار الأسرة غير صحيح.")
        if not first or not last or not code:
            return self._error(400, "الاسم واللقب ورقم التسجيل حقول إلزامية.")
        if len(first) > 100 or len(last) > 100 or len(code) > 40 or (notes and len(notes) > 2000):
            return self._error(400, "تجاوز أحد الحقول الحد المسموح لطوله.")
        if gender not in GENDERS or category not in CATEGORIES or status not in STATUSES - {"archived"}:
            return self._error(400, "قيمة الجنس أو الفئة أو الحالة غير صحيحة.")
        if birth:
            try:
                datetime.strptime(birth, "%Y-%m-%d")
            except ValueError:
                return self._error(400, "تاريخ الميلاد غير صحيح.")
        key = normalize_search(first + " " + last)
        with connect(self.server.db_path) as con:
            dup = con.execute("SELECT id,student_code,first_name,last_name,birth_date FROM students WHERE search_key=? ORDER BY id DESC LIMIT 10", (key,)).fetchall()
            if dup and self.headers.get("X-Confirm-Duplicate", "").lower() != "yes":
                # A known different birth date is not considered the same person (e.g. twins or namesakes).
                plausible = [r for r in dup if not (birth and r["birth_date"] and birth != r["birth_date"])]
                if plausible:
                    return self._send(409, {"code": "duplicate_student", "error": "يوجد طالب باسم مشابه؛ يلزم تأكيد التسجيل.", "matches": [{"student_code": r["student_code"], "first_name": r["first_name"], "last_name": r["last_name"]} for r in plausible]})
            try:
                family_row = con.execute("SELECT * FROM families WHERE id=? AND status='active'", (family_id,)).fetchone() if family_id is not None else None
                if family_id is not None and family_row is None:
                    return self._error(400, "الأسرة المحددة غير موجودة أو مؤرشفة.")
                cur = con.execute("INSERT INTO students(student_code,first_name,last_name,birth_date,gender,family_id,student_category,status,notes,search_key) VALUES(?,?,?,?,?,?,?,?,?,?)", (code, first, last, birth, gender, family_id, category, status, notes, key))
                sid = cur.lastrowid
                if family_row is not None:
                    relationships = []
                    if family_row["father_first_name"] or family_row["father_last_name"] or family_row["father_phone"]: relationships.append("father")
                    if family_row["mother_first_name"] or family_row["mother_last_name"] or family_row["mother_phone"]: relationships.append("mother")
                    if not relationships and category == "child": relationships.append("guardian")
                    for i, rel in enumerate(relationships):
                        con.execute("INSERT OR IGNORE INTO student_guardians(student_id,family_id,relationship,is_primary_contact) VALUES(?,?,?,?)", (sid,family_id,rel,1 if i==0 else 0))
                if con.execute("SELECT 1 FROM sqlite_master WHERE type='table' AND name='audit_log'").fetchone():
                    con.execute("INSERT INTO audit_log(action,entity_type,entity_id,details) VALUES('create','student',?,?)", (sid, json.dumps({"student_code": code, "name": first + " " + last}, ensure_ascii=False)))
                con.commit()
            except __import__('sqlite3').IntegrityError as exc:
                con.rollback()
                if "student_code" in str(exc) or "UNIQUE constraint failed: students.student_code" in str(exc):
                    return self._error(409, "رقم التسجيل مستخدم مسبقًا. اختر رقمًا آخر.", code="duplicate_code")
                return self._error(400, "تعذر حفظ السجل بسبب تعارض في البيانات.")
        return self._send(201, {"id": sid, "message": "تم حفظ الطالب في قاعدة البيانات المحلية."})


def run_server(host="127.0.0.1", port=0, db_path=None, open_browser=True):
    db_path = Path(db_path or default_database_path()).expanduser().resolve()
    initialize_database(db_path)
    issues = validate_database(db_path)
    if issues:
        raise RuntimeError("فشل فحص قاعدة البيانات: " + "; ".join(issues))
    httpd = ThreadingHTTPServer((host, port), MishkatHandler)
    httpd.daemon_threads = True
    httpd.db_path = db_path
    # Do not accept remote connections: this service is local-only by design.
    url = f"http://127.0.0.1:{httpd.server_address[1]}/"
    print("\nمِشكاة HTML — تشغيل محلي دون إنترنت")
    print("الرابط: " + url)
    print("قاعدة البيانات: " + str(db_path))
    print("أوقف التطبيق بإغلاق هذه النافذة أو الضغط على Ctrl+C.\n")
    if open_browser:
        threading.Timer(0.8, lambda: webbrowser.open(url)).start()
    try:
        httpd.serve_forever(poll_interval=0.3)
    except KeyboardInterrupt:
        print("\nتم إيقاف مِشكاة.")
    finally:
        httpd.server_close()


def main():
    import argparse
    parser = argparse.ArgumentParser(description="تشغيل واجهة مِشكاة HTML محليًا")
    parser.add_argument("--db", help="مسار اختياري لقاعدة بيانات الاختبار أو النقل")
    parser.add_argument("--port", type=int, default=0)
    parser.add_argument("--no-browser", action="store_true")
    args = parser.parse_args()
    run_server(port=args.port, db_path=args.db, open_browser=not args.no_browser)

if __name__ == "__main__":
    main()
