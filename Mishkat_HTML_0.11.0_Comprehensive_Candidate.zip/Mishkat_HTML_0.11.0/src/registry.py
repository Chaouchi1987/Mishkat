"""Student and family registration services with Arabic-aware search."""
from datetime import date
import re
import sqlite3
import unicodedata
from typing import Optional, Dict, Any, List

from .db import connect


class RegistryError(ValueError):
    pass


class DuplicateStudentWarning(RegistryError):
    """Potential duplicate found; UI must ask the operator before proceeding."""
    def __init__(self, matches):
        self.matches = matches
        summary = "\n".join("• {} — {} {} ({}، {})".format(
            item["student_code"], item["first_name"], item["last_name"],
            item.get("birth_date") or "دون تاريخ ميلاد", item.get("status", "")) for item in matches[:5])
        super().__init__("عُثر على سجلات قد تكون مكررة. راجعها قبل المتابعة:\n{}\n\nإذا تأكدت أنه تسجيل جديد، أعد المحاولة وأكّد ذلك.".format(summary))


def _clean(value):
    return value.strip() if isinstance(value, str) else value


def normalize_search(value):
    """Normalize Arabic text for matching while preserving original display values."""
    value = unicodedata.normalize("NFKC", str(value or ""))
    value = "".join(ch for ch in value if ch != "ـ" and unicodedata.category(ch) != "Mn")
    replacements = str.maketrans({
        "أ": "ا", "إ": "ا", "آ": "ا", "ٱ": "ا",
        "ؤ": "و", "ئ": "ي", "ى": "ي", "ة": "ه",
    })
    value = value.translate(replacements)
    value = re.sub(r"\s+", " ", value).strip().casefold()
    return value


def _valid_date(value):
    value = _clean(value)
    if not value:
        return None
    try:
        parsed = date.fromisoformat(value)
    except (ValueError, TypeError):
        raise RegistryError("تاريخ الميلاد غير صحيح. استخدم الصيغة YYYY-MM-DD.")
    if parsed > date.today():
        raise RegistryError("تاريخ الميلاد لا يمكن أن يكون في المستقبل.")
    return parsed.isoformat()


def _audit(con, action, entity_type, entity_id=None, details=None):
    if "audit_log" in {r[0] for r in con.execute("SELECT name FROM sqlite_master WHERE type='table'")}:
        con.execute("INSERT INTO audit_log(action, entity_type, entity_id, details) VALUES (?, ?, ?, ?)",
                    (action, entity_type, str(entity_id) if entity_id is not None else None, details))


def list_families(db_path):
    with connect(db_path) as con:
        rows = con.execute("""SELECT id, family_code, father_first_name, father_last_name,
                   father_phone, mother_first_name, mother_last_name, mother_phone, address
            FROM families WHERE status='active' ORDER BY id DESC""").fetchall()
        return [dict(row) for row in rows]


def find_duplicate_students(db_path, student):
    first = normalize_search(_clean((student or {}).get("first_name", "")))
    last = normalize_search(_clean((student or {}).get("last_name", "")))
    birth = _clean((student or {}).get("birth_date")) or None
    if not first or not last:
        return []
    with connect(db_path) as con:
        rows = con.execute("""SELECT id, student_code, first_name, last_name, birth_date, status, search_key
            FROM students ORDER BY id DESC LIMIT 1000""").fetchall()
        matches = []
        for row in rows:
            parts = normalize_search(row["first_name"]), normalize_search(row["last_name"])
            if parts == (first, last):
                # If both dates are known and differ, treat as distinct people (e.g. twins).
                if birth and row["birth_date"] and birth != row["birth_date"]:
                    continue
                item = dict(row)
                item["same_birth_date"] = bool(birth and row["birth_date"] == birth)
                matches.append(item)
        return matches[:10]


def search_students(db_path, query=""):
    query = _clean(query or "")
    with connect(db_path) as con:
        if query:
            raw_like = "%" + query.replace("%", "\\%").replace("_", "\\_") + "%"
            normalized_like = "%" + normalize_search(query).replace("%", "\\%").replace("_", "\\_") + "%"
            rows = con.execute("""SELECT s.id, s.student_code, s.first_name, s.last_name,
                       s.birth_date, s.gender, s.student_category, s.status,
                       f.family_code, f.father_phone, f.mother_phone
                FROM students s LEFT JOIN families f ON f.id=s.family_id
                WHERE s.student_code LIKE ? ESCAPE '\\'
                   OR s.first_name LIKE ? ESCAPE '\\'
                   OR s.last_name LIKE ? ESCAPE '\\'
                   OR s.search_key LIKE ? ESCAPE '\\'
                   OR f.father_phone LIKE ? ESCAPE '\\'
                   OR f.mother_phone LIKE ? ESCAPE '\\'
                   OR f.search_key LIKE ? ESCAPE '\\'
                ORDER BY s.id DESC LIMIT 500""",
                (raw_like, raw_like, raw_like, normalized_like, raw_like, raw_like, normalized_like)).fetchall()
        else:
            rows = con.execute("""SELECT s.id, s.student_code, s.first_name, s.last_name,
                       s.birth_date, s.gender, s.student_category, s.status,
                       f.family_code, f.father_phone, f.mother_phone
                FROM students s LEFT JOIN families f ON f.id=s.family_id
                ORDER BY s.id DESC LIMIT 500""").fetchall()
        return [dict(row) for row in rows]


def register_student(db_path, student, family=None, family_id=None, allow_duplicate=False):
    student = {key: _clean(value) for key, value in (student or {}).items()}
    family = {key: _clean(value) for key, value in (family or {}).items()}
    first_name, last_name = student.get("first_name", ""), student.get("last_name", "")
    if not first_name or not last_name:
        raise RegistryError("الاسم واللقب إجباريان.")
    if student.get("gender", "") not in ("male", "female"):
        raise RegistryError("يرجى تحديد الجنس.")
    category = student.get("student_category", "child")
    if category not in ("child", "adult"):
        raise RegistryError("فئة الطالب غير صحيحة.")
    birth_date = _valid_date(student.get("birth_date"))
    status = student.get("status", "active")
    if status not in ("active", "paused", "withdrawn", "completed", "archived"):
        raise RegistryError("حالة الطالب غير صحيحة.")

    matches = find_duplicate_students(db_path, student)
    if matches and not allow_duplicate:
        raise DuplicateStudentWarning(matches)

    family_fields = ("father_first_name", "father_last_name", "father_phone", "mother_first_name", "mother_last_name", "mother_phone", "address")
    has_family_data = any(family.get(field) for field in family_fields)
    if family_id not in (None, "") and has_family_data:
        raise RegistryError("اخترت أسرة مسجلة وكتبت بيانات أسرة جديدة في الوقت نفسه. أفرغ بيانات الأسرة أو اختر إنشاء أسرة جديدة؛ لم تُحفظ هذه البيانات.")

    with connect(db_path) as con:
        con.execute("BEGIN IMMEDIATE")
        selected_family_id = None
        if family_id not in (None, ""):
            try:
                selected_family_id = int(family_id)
            except (ValueError, TypeError):
                raise RegistryError("اختيار الأسرة غير صحيح.")
            family_row = con.execute("SELECT * FROM families WHERE id=?", (selected_family_id,)).fetchone()
            if not family_row:
                raise RegistryError("الأسرة المحددة غير موجودة.")
        elif has_family_data:
            max_id = con.execute("SELECT COALESCE(MAX(id), 0) FROM families").fetchone()[0]
            family_code = "FAM-{0:06d}".format(max_id + 1)
            family_names = " ".join(filter(None, (family.get("father_first_name"), family.get("father_last_name"), family.get("mother_first_name"), family.get("mother_last_name"))))
            cur = con.execute("""INSERT INTO families (family_code, father_first_name, father_last_name,
                father_phone, mother_first_name, mother_last_name, mother_phone, address, search_key)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)""",
                (family_code,) + tuple(family.get(field) or None for field in family_fields) + (normalize_search(family_names),))
            selected_family_id = cur.lastrowid

        year = date.today().year
        prefix = "BM-{0}-".format(year)
        latest = con.execute("SELECT student_code FROM students WHERE student_code LIKE ? ORDER BY student_code DESC LIMIT 1", (prefix + "%",)).fetchone()
        serial = 1
        if latest:
            match = re.match(r"^BM-\d{4}-(\d{6})$", latest[0])
            if match:
                serial = int(match.group(1)) + 1
        student_code = prefix + "{0:06d}".format(serial)
        key = normalize_search("{} {}".format(first_name, last_name))
        cur = con.execute("""INSERT INTO students (student_code, first_name, last_name, birth_date,
            gender, family_id, student_category, status, notes, search_key)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)""",
            (student_code, first_name, last_name, birth_date, student["gender"], selected_family_id, category, status, student.get("notes") or None, key))
        student_id = cur.lastrowid
        if selected_family_id is not None:
            family_row = con.execute("SELECT * FROM families WHERE id=?", (selected_family_id,)).fetchone()
            relationships = []
            if family_row["father_first_name"] or family_row["father_last_name"] or family_row["father_phone"]:
                relationships.append("father")
            if family_row["mother_first_name"] or family_row["mother_last_name"] or family_row["mother_phone"]:
                relationships.append("mother")
            if not relationships and category == "child":
                relationships.append("guardian")
            for index, relationship in enumerate(relationships):
                con.execute("INSERT OR IGNORE INTO student_guardians(student_id, family_id, relationship, is_primary_contact) VALUES (?, ?, ?, ?)",
                            (student_id, selected_family_id, relationship, 1 if index == 0 else 0))
        if matches and allow_duplicate:
            _audit(con, "duplicate_registration_confirmed", "student", student_id,
                   "تم تأكيد التسجيل رغم وجود تشابه محتمل مع السجلات: {}".format(",".join(str(m["id"]) for m in matches)))
        _audit(con, "student_registered", "student", student_id, "تم تسجيل طالب جديد")
        return {"id": student_id, "student_code": student_code, "family_id": selected_family_id}


def get_student(db_path, student_id):
    with connect(db_path) as con:
        row = con.execute("""SELECT s.*, f.family_code, f.father_first_name, f.father_last_name,
            f.father_phone, f.mother_first_name, f.mother_last_name, f.mother_phone, f.address
            FROM students s LEFT JOIN families f ON f.id=s.family_id WHERE s.id=?""", (student_id,)).fetchone()
        return dict(row) if row else None


def update_student(db_path, student_id, changes):
    allowed = {"first_name", "last_name", "birth_date", "gender", "student_category", "status", "notes"}
    values = {key: _clean(value) for key, value in (changes or {}).items() if key in allowed}
    with connect(db_path) as con:
        row = con.execute("SELECT * FROM students WHERE id=?", (student_id,)).fetchone()
        if row is None:
            raise RegistryError("الطالب غير موجود.")
        first = values.get("first_name", row["first_name"])
        last = values.get("last_name", row["last_name"])
        birth = _valid_date(values.get("birth_date", row["birth_date"]))
        gender = values.get("gender", row["gender"])
        category = values.get("student_category", row["student_category"])
        status = values.get("status", row["status"])
        if not first or not last or gender not in ("male", "female") or category not in ("child", "adult") or status not in ("active", "paused", "withdrawn", "completed", "archived"):
            raise RegistryError("بيانات الطالب غير صحيحة.")
        con.execute("""UPDATE students SET first_name=?, last_name=?, birth_date=?, gender=?,
            student_category=?, status=?, notes=?, search_key=?, updated_at=datetime('now') WHERE id=?""",
            (first, last, birth, gender, category, status, values.get("notes", row["notes"]), normalize_search(first + " " + last), student_id))
        _audit(con, "student_updated", "student", student_id, "تم تعديل بيانات الطالب")


def archive_student(db_path, student_id):
    update_student(db_path, student_id, {"status": "archived"})


def delete_student(db_path, student_id, confirm=False):
    if not confirm:
        raise RegistryError("الحذف النهائي يتطلب تأكيدًا صريحًا.")
    with connect(db_path) as con:
        row = con.execute("SELECT id FROM students WHERE id=?", (student_id,)).fetchone()
        if row is None:
            raise RegistryError("الطالب غير موجود.")
        linked = con.execute("SELECT (SELECT COUNT(*) FROM attendance_records WHERE student_id=?) + (SELECT COUNT(*) FROM memorization_sessions WHERE student_id=?)", (student_id, student_id)).fetchone()[0]
        if linked:
            raise RegistryError("لا يمكن حذف طالب له سجلات حضور أو حفظ مرتبطة؛ استخدم الأرشفة.")
        _audit(con, "student_deleted", "student", student_id, "حذف نهائي مؤكد لطالب بلا سجلات حضور أو حفظ")
        con.execute("DELETE FROM students WHERE id=?", (student_id,))


def update_family(db_path, family_id, changes):
    allowed = {"father_first_name", "father_last_name", "father_phone", "mother_first_name", "mother_last_name", "mother_phone", "address", "status"}
    values = {key: _clean(value) for key, value in (changes or {}).items() if key in allowed}
    with connect(db_path) as con:
        row = con.execute("SELECT * FROM families WHERE id=?", (family_id,)).fetchone()
        if row is None:
            raise RegistryError("الأسرة غير موجودة.")
        if values.get("status", row["status"] if "status" in row.keys() else "active") not in ("active", "archived"):
            raise RegistryError("حالة الأسرة غير صحيحة.")
        merged = {key: values.get(key, row[key]) for key in ("father_first_name", "father_last_name", "mother_first_name", "mother_last_name")}
        search_key = normalize_search(" ".join(filter(None, merged.values())))
        con.execute("""UPDATE families SET father_first_name=?, father_last_name=?, father_phone=?,
            mother_first_name=?, mother_last_name=?, mother_phone=?, address=?, search_key=?,
            status=?, updated_at=datetime('now') WHERE id=?""",
            (values.get("father_first_name", row["father_first_name"]), values.get("father_last_name", row["father_last_name"]),
             values.get("father_phone", row["father_phone"]), values.get("mother_first_name", row["mother_first_name"]),
             values.get("mother_last_name", row["mother_last_name"]), values.get("mother_phone", row["mother_phone"]),
             values.get("address", row["address"]), search_key, values.get("status", row["status"] if "status" in row.keys() else "active"), family_id))
        _audit(con, "family_updated", "family", family_id, "تم تعديل بيانات الأسرة")


def archive_family(db_path, family_id):
    update_family(db_path, family_id, {"status": "archived"})


def delete_family(db_path, family_id, confirm=False):
    if not confirm:
        raise RegistryError("حذف الأسرة نهائيًا يتطلب تأكيدًا صريحًا.")
    with connect(db_path) as con:
        row = con.execute("SELECT id FROM families WHERE id=?", (family_id,)).fetchone()
        if row is None:
            raise RegistryError("الأسرة غير موجودة.")
        linked = con.execute("SELECT COUNT(*) FROM students WHERE family_id=?", (family_id,)).fetchone()[0]
        if linked:
            raise RegistryError("لا يمكن حذف أسرة مرتبطة بتلاميذ؛ استخدم الأرشفة.")
        _audit(con, "family_deleted", "family", family_id, "حذف نهائي مؤكد لأسرة غير مرتبطة")
        con.execute("DELETE FROM families WHERE id=?", (family_id,))
