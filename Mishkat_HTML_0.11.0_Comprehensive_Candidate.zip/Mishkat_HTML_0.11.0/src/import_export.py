"""Offline import/export helpers for CSV, XLSX and DOCX. No network or third-party runtime dependency."""
from __future__ import annotations
import csv, io, zipfile, xml.etree.ElementTree as ET
from pathlib import PurePosixPath

MAX_IMPORT_BYTES = 8 * 1024 * 1024

def _cell_text(cell, shared):
    typ = cell.attrib.get('t')
    value = cell.find('{http://schemas.openxmlformats.org/spreadsheetml/2006/main}v')
    if typ == 's' and value is not None:
        try: return shared[int(value.text)]
        except (ValueError, IndexError, TypeError): return ''
    if typ == 'inlineStr':
        return ''.join(t.text or '' for t in cell.findall('.//{http://schemas.openxmlformats.org/spreadsheetml/2006/main}t'))
    return value.text if value is not None and value.text is not None else ''

def read_xlsx(raw: bytes):
    ns = {'m':'http://schemas.openxmlformats.org/spreadsheetml/2006/main','r':'http://schemas.openxmlformats.org/officeDocument/2006/relationships'}
    with zipfile.ZipFile(io.BytesIO(raw)) as z:
        if len(z.infolist()) > 5000 or sum(x.file_size for x in z.infolist()) > 50 * 1024 * 1024: raise ValueError('محتوى ملف Excel بعد فك الضغط كبير جدًا أو يحتوي ملفات كثيرة.')
        names = set(z.namelist())
        if 'xl/workbook.xml' not in names: raise ValueError('ملف XLSX لا يحتوي على بنية مصنف صحيحة.')
        shared=[]
        if 'xl/sharedStrings.xml' in names:
            root=ET.fromstring(z.read('xl/sharedStrings.xml'))
            shared=[''.join(t.text or '' for t in si.findall('.//m:t',ns)) for si in root.findall('m:si',ns)]
        wb=ET.fromstring(z.read('xl/workbook.xml')); sheets=wb.find('m:sheets',ns)
        if sheets is None or not list(sheets): raise ValueError('المصنف لا يحتوي على أوراق عمل.')
        first=list(sheets)[0]; rel=first.attrib.get('{http://schemas.openxmlformats.org/officeDocument/2006/relationships}id')
        relroot=ET.fromstring(z.read('xl/_rels/workbook.xml.rels'))
        relns={'p':'http://schemas.openxmlformats.org/package/2006/relationships'}
        target=next((x.attrib['Target'] for x in relroot.findall('p:Relationship',relns) if x.attrib.get('Id')==rel),None)
        if not target: raise ValueError('تعذر تحديد ورقة العمل الأولى.')
        path=str(PurePosixPath('xl') / target) if not target.startswith('/') else target.lstrip('/')
        path=path.replace('xl/xl/','xl/')
        root=ET.fromstring(z.read(path)); rows=[]
        for row in root.findall('.//m:sheetData/m:row',ns):
            vals=[]
            for c in row.findall('m:c',ns):
                ref=c.attrib.get('r','A1'); letters=''.join(ch for ch in ref if ch.isalpha()).upper(); idx=0
                for ch in letters: idx=idx*26+ord(ch)-64
                idx=max(1,idx)-1
                while len(vals)<=idx: vals.append('')
                vals[idx]=_cell_text(c,shared)
            rows.append(vals)
        return rows

def read_docx(raw: bytes):
    ns={'w':'http://schemas.openxmlformats.org/wordprocessingml/2006/main'}
    with zipfile.ZipFile(io.BytesIO(raw)) as z:
        if len(z.infolist()) > 5000 or sum(x.file_size for x in z.infolist()) > 50 * 1024 * 1024: raise ValueError('محتوى ملف Word بعد فك الضغط كبير جدًا أو يحتوي ملفات كثيرة.')
        if 'word/document.xml' not in z.namelist(): raise ValueError('ملف DOCX غير صالح.')
        root=ET.fromstring(z.read('word/document.xml'))
        tables=root.findall('.//w:tbl',ns)
        if not tables: raise ValueError('لم أجد جدولًا قابلًا للاستيراد في ملف Word. حوّل القائمة إلى جدول ثم أعد المحاولة.')
        table=tables[0]; rows=[]
        for tr in table.findall('w:tr',ns):
            vals=[]
            for tc in tr.findall('w:tc',ns):
                vals.append(' '.join(''.join(t.text or '' for t in p.findall('.//w:t',ns)) for p in tc.findall('w:p',ns)).strip())
            rows.append(vals)
        return rows

def read_tabular(filename: str, raw: bytes):
    if len(raw)>MAX_IMPORT_BYTES: raise ValueError('حجم الملف يتجاوز 8 ميغابايت.')
    ext=filename.lower().rsplit('.',1)[-1] if '.' in filename else ''
    if ext in ('csv','tsv'):
        text=raw.decode('utf-8-sig')
        dialect='excel-tab' if ext=='tsv' else 'excel'
        return list(csv.reader(io.StringIO(text), dialect=dialect))
    if ext=='xlsx': return read_xlsx(raw)
    if ext=='docx': return read_docx(raw)
    if ext in ('xls','doc'): raise ValueError('الصيغة القديمة .xls/.doc غير مدعومة دون تحويل. احفظ الملف بصيغة .xlsx أو .docx أو CSV ثم أعد المحاولة.')
    raise ValueError('الصيغ المدعومة: .xlsx و.docx و.csv و.tsv.')

def table_to_csv(headers, rows):
    buf=io.StringIO(newline=''); w=csv.writer(buf); w.writerow(headers)
    for row in rows: w.writerow([row.get(h,'') for h in headers])
    return ('\ufeff'+buf.getvalue()).encode('utf-8')
