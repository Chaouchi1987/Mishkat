# سياسة توافق Windows — مِشكاة

## الهدف الأولي
- Windows 10/11 x64، بعد بناء الحزمة على Windows واختبارها فعليًا.
- نسخة المصدر تستهدف Python 3.8+، لكن مسار البناء الموصى به يثبت Python 3.11 x64 لتحقيق نتائج قابلة للتكرار.
- يستخدم التطبيق Tkinter وSQLite محليًا؛ لا يعتمد التشغيل اليومي على الإنترنت أو API خارجي.

## ما لا ندّعيه
- لا نضمن العمل على كل إصدارات Windows أو الأجهزة دون اختبار.
- لم يتم إثبات دعم Windows 7 أو 8 أو الأنظمة الأقدم.
- نجاح الاختبارات على Linux لا يثبت صحة اتجاه RTL أو الخطوط أو سلوك النوافذ على Windows.
- نجاح بناء EXE لا يثبت وحده صحة النسخ والاستعادة أو عدم فقد البيانات.

## متطلبات التحقق قبل الإصدار
نفّذ قائمة `WINDOWS_ACCEPTANCE_CHECKLIST_AR.md` وسجّل إصدار Windows، ونتيجة كل اختبار، وأي خطأ وصورة شاشة. لا تصف الإصدار بأنه جاهز للإنتاج قبل إكمال ذلك.


Current candidate: 0.11.0 HTML local. Automated API/database tests are available. The actual Windows installer, visual RTL, offline first-run and physical USB workflow have not been certified in this environment. Do not describe it as production-certified until the acceptance checklist passes on a clean Windows x64 machine.
